var BASE_URL1 = "https://api-sandbox.pitneybowes.com/oauth/token";

//var BASE_URL2 = "https://api-sandbox.pitneybowes.com/shippingservices/v1/tracking/70180360000213168419?packageIdentifierType=TrackingNumber&carrier=USPS";

var BASE_URL2_part1 = "https://api-sandbox.pitneybowes.com/shippingservices/v1/tracking/";

var BASE_URL2_part2 = "?packageIdentifierType=TrackingNumber&carrier=USPS";

var BASE_URL = "https://httpbin.org/";

function displayStatus(type, message) {
  client.interface.trigger('showNotify', { type: type, message: message});
}


$(document).ready( function() {
  app.initialized()
  .then(function(_client) {
    window.client = _client;
    client.events.on('app.activated', function() {
      jQuery(".request-btn").click(function(e) {
        //var method = e.target.getAttribute('method');
        //var url = BASE_URL + method;
		var url = BASE_URL1;
        var options = {
          "headers" : {
            //"Content-Type": "application/json"
			"Authorization" : "Basic VGFGN3g4UjN1MEY5NlBFckdzRWl0VXA0SzRHY3FxOU06TEp3RndkcGRoMzk3MWR0dg=="
          },
		  "body" : "grant_type=client_credentials"
        };
        client.request.post(url, options)
        .then(function(data) {
			var access_token = JSON.parse(data.response)['access_token'];	
			var options1 = {
          "headers" : {    
			"Authorization" : "Bearer "+ access_token
          }		  
        };
		
		//70180360000213168419
			
		var trackingUrl = BASE_URL2_part1 + "70180360000213168419" + BASE_URL2_part2 ;
			
	    var url2 = BASE_URL2;
	    client.request.get(trackingUrl, options1)
        .then(function(data) {
			
			var status1 = JSON.parse(data.response)['status'];
			
			$("#mytable").append('');
			var tbl=$("<table/>").attr("id","mytable"); 
	$("#div1").append(tbl);	
	var tr1="<tr>";
	var td="<td><b>Status</b></td>";
	var td0="<td>"+ status1 +"</td></tr>";
	$("#mytable").append(tr1+td+td0);
		
    $("#div1").append(tbl);	
	var tr2="<tr>";
	var td1="<td><b>Ship Date</b></td>";
	var td2="<td>2018-06-06</td></tr>";
	$("#mytable").append(tr2+td1+td2);

	$("#div1").append(tbl);	
	var tr3="<tr>";
	var td3="<td><b>Delivery Date</b></td>";
	var td4="<td>2018-06-13</td></tr>";
	$("#mytable").append(tr3+td3+td4);

    $("#div1").append(tbl);	
	var tr3="<tr>";
	var td5="<td><b>Delivery Time</b></td>";
	var td6="<td>05:24:00</td></tr>";
	$("#mytable").append(tr3+td5+td6);
    $("#div1").append(tbl);	
	var tr4="<tr>";
	var td7="<td><b>Package Count</b></td>";
	var td8="<td>1</td></tr>";
	$("#mytable").append(tr4+td7+td8);
    $("#div1").append(tbl);	
	var tr5="<tr>";
	var td9="<td><b>Carrier</b></td>";
	var td10="<td>USPS</td></tr>";
	$("#mytable").append(tr5+td9+td10);		
			
			
			displayStatus('success', ' Fetched tracking details successfully.');
        }, function() {
          displayStatus('danger', method.toUpperCase() + ' 11 failed.');
        });
			
	 
          //displayStatus('success', ' Fetched  successfully.');
        }, function() {
          displayStatus('danger', method.toUpperCase() + ' request failed.');
        });
      });
    });
  });
});


/*

1.We created new shipment in sandbox , which is not possible to track as that wasn’t actual shipment. 
Hence as suggested by Pitney Bowes Team we have mocked/hardcoded the response to mimic Production behavior.
2.This is MVP , hence we covered only few scenarios , more scenarios are in future scope.
 

$(document).ready( function() {
  app.initialized()
  .then(function(_client) {
    window.client = _client;
    client.events.on('app.activated', function() {
      jQuery(".request-btn").click(function(e) {
        var method = e.target.getAttribute('method');
        var url = BASE_URL1;
        var options = {
          "headers" : {
            "Authorization": "Bearer ovzQvlxYgbgLpF95e9PhPKKVAWId"
          }
        };
        client.request.get(url, options)
        .then(function(data) {
			var access_token = JSON.parse(data.response)['access_token'];			
			var options = {
          "headers" : {
            "Authorization": "Basic " +access_token
          }
        };
        client.request.get(BASE_URL2, options)
        .then(function(data) {
			var access_token = JSON.parse(data.response);
               	var tbl=$("<table/>").attr("id","mytable"); 
	$("#div1").append(tbl);	
	var tr1="<tr>";
	var td="<td align=center>Column 1</td>";
	var td0="<td align=center>Column 2</td></tr>";
	$("#mytable").append(tr1+td+td0); 
	var arrayListt = new Array();
    for(var i=0;i<Object.keys(data).length;i++)
    {		
		arrayListt.push(Object.values(data)[i] + '-' +Object.keys(data)[i]);    
    } 	
	arrayListt.sort();
	arrayListt.reverse();	
	for(var i=0;i<5;i++)
    {		
	var splitArray = arrayListt[i].split('-');
    var tr="<tr>";
    var td1="<td align=center>"+ (i+1) +"</td>";	
    var td2="<td align=center>"+splitArray[1]+"</td></tr>";	
     $("#mytable").append(tr+td1+td2); 
    } 			
			});
          displayStatus('success', ' Fetched tracking details successfully.');
        }, function() {
          displayStatus('danger', method.toUpperCase() + ' Could not fetch tracking details.');
        });
      });
    });
  });
});

*/
