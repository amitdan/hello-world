/*
 * COPYRIGHT (c) 2015 DIGITAL RIVER, INC. ALL RIGHTS RESERVED.
 */
package com.digitalriver.integration.util;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

/**
 * Utility class with static methods for doing XML to Json & vice versa conversion. Uses Json Org library
 * (http://www.json.org/java/) to do the conversion.
 *
 * @author <a href="mailto:vtiwari@digitalriver.com">Vineet Tiwari</a>
 */
public class JsonUtil {

    /**
     * Converts passed Json string into equivalent XML String.
     *
     * @param jsonData - String in Json format.
     * @return String - XML format.
     *
     * @throws JSONException - In case of error while conversion.
     */
    public static String toXML(final String jsonData) throws JSONException {
        final JSONObject obj = new JSONObject(jsonData);
        return JsonUtil.toXML(obj);
    }

    /**
     * Converts passed Json instance into equivalent XML String.
     *
     * @param obj - Json instance.
     * @return String - XML format.
     *
     * @throws JSONException - In case of error while conversion.
     */
    public static String toXML(final JSONObject obj) throws JSONException {
        return XML.toString(obj);
    }

    /**
     * Converts passed XML string into equivalent Json String.
     *
     * @param xmlData - String in XML format.
     * @param indentFactor - Indentation factor.
     *
     * @return String - Json format.
     *
     * @throws JSONException - In case of error while conversion.
     */
    public static String toJson(final String xmlData, final int indentFactor) throws JSONException {
        final JSONObject jsonObj = XML.toJSONObject(xmlData);
        return jsonObj.toString(indentFactor);
    }

    /**
     * Converts passed XML string into equivalent Json String.
     *
     * @param xmlData - String in XML format.
     * @return String - Json format.
     *
     * @throws JSONException - In case of error while conversion.
     */
    public static String toJson(final String xmlData) throws JSONException {
        return JsonUtil.toJson(xmlData, 0);
    }
}
