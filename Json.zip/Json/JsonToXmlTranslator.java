/*
 * COPYRIGHT (c) 2015 DIGITAL RIVER, INC. ALL RIGHTS RESERVED.
 */
package com.digitalriver.integration.layout.adapter.json;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;

import com.digitalriver.integration.layout.BaseTranslator;
import com.digitalriver.integration.layout.TranslateFailException;
import com.digitalriver.integration.layout.TranslateRequest;
import com.digitalriver.integration.layout.TranslateResponse;
import com.digitalriver.integration.util.JsonUtil;
import com.digitalriver.util.StringUtil;

/**
 * Translates JSON request to XML. This translator should be used for inbound communication only.
 *
 * @author <a href="mailto:adandawate@digitalriver.com">Amit Dandawate</a>
 */
public class JsonToXmlTranslator extends BaseTranslator {

    /**
     * String constant for NAMESPACE_PREFIX_WITH_COLON
     */
    static final String NAMESPACE_PREFIX_WITH_COLON = "ns:";

    /**
     * String constant for NAMESPACE_DECLARATION
     */
    static final String NAMESPACE_DECLARATION = "xmlns:ns=";

    /**
     * String constant for LESS_THAN_CHARACTER
     */
    static final String LESS_THAN_CHARACTER = "<";

    /**
     * String constant for GREATER_THAN_CHARACTER
     */
    static final String GREATER_THAN_CHARACTER = ">";

    /**
     * String constant for DOUBLE_QUOTE_CHARACTER
     */
    static final String DOUBLE_QUOTE_CHARACTER = "\"";

    /**
     * String constant for SINGLE_SPACE_CHARACTER
     */
    static final String SINGLE_SPACE_CHARACTER = " ";

    /**
     * String constant for XML_HEADER
     */
    static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";

    /**
     * String constant for default root element start tag - <Root> 
     */
    static final String DEFAULT_ROOT_ELEMENT_START_TAG = "<Root>";
    
    /**
     * String constant for default root element end tag - </Root> 
     */
    static final String DEFAULT_ROOT_ELEMENT_END_TAG = "</Root>";
    
    /**
     * String constant for JSON_TO_XML_TRANSFORMATION_ERROR
     */
    static final String JSON_TO_XML_TRANSFORMATION_ERROR = "JSON_TO_XML_TRANSFORMATION_ERROR";

    /**
     * JsonLayout instance
     */
    private final JsonLayout layout;

    /**
     * The JsonToXmlTranslator logger instance.
     */
    private static final Logger LOGGER = Logger.getLogger(JsonToXmlTranslator.class.getName());

    /**
     * Construct a JsonToXmlTranslator.
     *
     * @param layout - json layout instance.
     */
    public JsonToXmlTranslator(final JsonLayout layout) {
        this.layout = layout;
    }

    /**
     * Translates Json information to Xml format.
     *
     * @param request - TranslateRequest contains Json data.
     * @return response - TranslateResponse containing Xml data.
     * @throws TranslateFailException - In an event of error while translating Jsom to Xml.
     */
    @Override
    public TranslateResponse translate(final TranslateRequest request) throws TranslateFailException {

        final int direction = request.getTranslateDirection();
        final String charEncoding = request.getCharacterEncoding();
        final String jsonInput = request.getSourceAsString();
        final long startTimeMillis = System.currentTimeMillis();
        JsonToXmlTranslator.LOGGER.finest("Input Json : \n" + jsonInput);

        String xmlOutput = convertToXml(jsonInput);
        
        if (this.layout.addDefaultRootElementEnabled()) {
            xmlOutput = addDefaultRootElement(xmlOutput);
        } else if (!StringUtil.isBlank(this.layout.getParentElementNamespace())) {
            xmlOutput = qualifyParentTag(xmlOutput, this.layout.getParentElementNamespace());
        }
        
        xmlOutput = addXMLHeader(xmlOutput);

        final long endTimeMillis = System.currentTimeMillis();

        JsonToXmlTranslator.LOGGER.fine("Time spent in conversion: " + (endTimeMillis - startTimeMillis));
        JsonToXmlTranslator.LOGGER.finest("Converted Xml : \n" + xmlOutput);

        return super.translate(BaseTranslator.createTranslateRequest(xmlOutput, direction, charEncoding, this.layout));
    }

    /**
     * Adds Xml header at beginning of converted Xml.
     *
     * @param xmlString - Xml data without header.
     * @return String - Xml data with header.
     */
    protected String addXMLHeader(final String xmlString) {
        final StringBuilder sBuilder = new StringBuilder();
        sBuilder.append(JsonToXmlTranslator.XML_HEADER);        
        sBuilder.append(xmlString);
        return sBuilder.toString();
    }

    /**
     * Converts Json information to Xml during Json to Xml translation.
     *
     * @param jsonData - Json data to be converted.
     * @return output - Converted Xml output
     * @throws JsonTranslationException - In an event of error while translating XML into json.
     */
    protected String convertToXml(final String jsonData) throws JsonTranslationException {
        final String output;
        try {
            output = JsonUtil.toXML(jsonData);
        } catch (final JSONException exception) {
            JsonToXmlTranslator.LOGGER.log(Level.SEVERE, "Exception while translating XML into json : ", exception);
            throw new JsonTranslationException(exception, JsonToXmlTranslator.JSON_TO_XML_TRANSFORMATION_ERROR);
        }
        return output;
    }

    /**
     * Qualifies namespace for parent tag during Json to Xml conversion.
     *
     * Gets parent tag name, which is between first occurrence of less than and greater than sign. Then
     * qualifies parent tag name with ns: Then prepares namespace by appending inputed namespace to xmlns:ns=
     * Then prepares new xml by replacing parent tag with ns: and parent tag name Then replaces first
     * occurrence of parent tag with namespace. Then returns Xml with namespace.
     *
     * @param xmlString - Xml content.
     * @param namespaceForParentTag - namespace to add to parent tag.
     * @return String - xml output with parent namespace.
     */
    protected String qualifyParentTag(final String xmlString, final String namespaceForParentTag) {
        final String parentTagName = StringUtils.substringBetween(xmlString, JsonToXmlTranslator.LESS_THAN_CHARACTER, JsonToXmlTranslator.GREATER_THAN_CHARACTER);
        final String qualifiedParentTagName = JsonToXmlTranslator.NAMESPACE_PREFIX_WITH_COLON + parentTagName;
        final String namespace = JsonToXmlTranslator.NAMESPACE_DECLARATION + JsonToXmlTranslator.DOUBLE_QUOTE_CHARACTER + namespaceForParentTag + JsonToXmlTranslator.DOUBLE_QUOTE_CHARACTER;
        final String newXml = StringUtils.replace(xmlString, parentTagName, qualifiedParentTagName);
        return StringUtils.replaceOnce(newXml, qualifiedParentTagName, qualifiedParentTagName + JsonToXmlTranslator.SINGLE_SPACE_CHARACTER + namespace);
    }
    
    /**
     * Adds default root element to Xml, if add default root element check box is enabled.
     *  
     * @param xmlString - xml data to be processed
     * @return sBuilder - Xml with default root element
     */
    protected String addDefaultRootElement(final String xmlString) {
        final StringBuilder sBuilder = new StringBuilder();
        sBuilder.append(JsonToXmlTranslator.DEFAULT_ROOT_ELEMENT_START_TAG);        
        sBuilder.append(xmlString);
        sBuilder.append(JsonToXmlTranslator.DEFAULT_ROOT_ELEMENT_END_TAG); 
        return sBuilder.toString();
    }
}