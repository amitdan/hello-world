/*
 * COPYRIGHT (c) 2015 DIGITAL RIVER, INC. ALL RIGHTS RESERVED.
 */
package com.digitalriver.integration.layout.adapter.json;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;

import com.digitalriver.integration.layout.BaseTranslator;
import com.digitalriver.integration.layout.TranslateFailException;
import com.digitalriver.integration.layout.TranslateRequest;
import com.digitalriver.integration.layout.TranslateResponse;
import com.digitalriver.integration.util.JsonUtil;
import com.digitalriver.util.StringUtil;

/**
 * Translates XML request to JSON. This translator should be used for outbound communication only.
 *
 * @author <a href="mailto:adandawate@digitalriver.com">Amit Dandawate</a>
 */
public class XmlToJsonTranslator extends BaseTranslator {

    /**
     * String constant for QUESTION_MARK
     */
    static final String QUESTION_MARK = "?";

    /**
     * String constant for XML_TO_JSON_TRANSFORMATION_ERROR
     */
    static final String XML_TO_JSON_TRANSFORMATION_ERROR = "XML_TO_JSON_TRANSFORMATION_ERROR";

    /**
     * The XmlToJsonTranslator logger instance.
     */
    private static final Logger LOGGER = Logger.getLogger(XmlToJsonTranslator.class.getName());

    /**
     * JsonLayout instance
     */
    private final JsonLayout layout;

    /**
     * Construct a new XmlToJsonTranslator.
     *
     * @param layout - json layout instance.
     */
    public XmlToJsonTranslator(final JsonLayout layout) {
        this.layout = layout;
    }

    /**
     * Translates Xml elements to json format.
     *
     * @param request - TranslateRequest containing Xml data.
     * @return TranslateResponse - response containing Json data.
     * @throws TranslateFailException - In an event of error while translating XML to json.
     */
    @Override
    public TranslateResponse translate(final TranslateRequest request) throws TranslateFailException {

        final int direction = request.getTranslateDirection();
        final String charEncoding = request.getCharacterEncoding();
        final String xmlRequest = request.getSourceAsString();

        final long startTimeMillis = System.currentTimeMillis();

        final String inputXml = (String) super.translate(BaseTranslator.createTranslateRequest(xmlRequest, direction, charEncoding, this.layout)).getResult();
        
        XmlToJsonTranslator.LOGGER.finest("Input Xml: \n" + inputXml);

        String jsonOutput = "";
        if (this.layout.isDynamicEndpointEnabled()) {
            jsonOutput = convertToJsonAndAddEndpoint(request);
        } else {
            jsonOutput = convertToJson(inputXml);
        }

        final long endTimeMillis = System.currentTimeMillis();

        XmlToJsonTranslator.LOGGER.finest("Converted Json: \n" + jsonOutput);
        XmlToJsonTranslator.LOGGER.fine("Time spent in conversion: " + (endTimeMillis - startTimeMillis));

        return BaseTranslator.createTranslateResponse(jsonOutput, charEncoding);
    }

    /**
     * Converts Xml data to Json and adds end point at beginning of json output.
     *
     * @param request - TranslateRequest containing Xml data..
     * @return String - Converted json output.
     * @throws JsonTranslationException - In an event of error while translating XML into json.
     */
    protected String convertToJsonAndAddEndpoint(final TranslateRequest request) throws JsonTranslationException {
        final String inputXml = getData(request);
        final String dynamicPathToPreserve = getDynamicPath(request);
        String jsonOutput = convertToJson(inputXml);
        jsonOutput = addEndpoint(jsonOutput, dynamicPathToPreserve);
        return jsonOutput;
    }

    /**
     * Adds end point at beginning of converted json during Xml to Json Conversion.
     *
     * @param jsonString - Converted json data.
     * @param dynamicPathToPreserve - dynamic path to add at beginning of json output.
     *
     * @return String - jsonOutput with end point if dynamic path is not blank <br>
     *         json data without dynamic path otherwise
     */
    protected String addEndpoint(final String jsonString, final String dynamicPathToPreserve) {
        String jsonOutput = jsonString;
        if (StringUtil.isNotBlank(dynamicPathToPreserve)) {
            final StringBuffer buffer = new StringBuffer();
            buffer.append(dynamicPathToPreserve);
            buffer.append(XmlToJsonTranslator.QUESTION_MARK);
            buffer.append(jsonString);
            jsonOutput = buffer.toString();
        }
        return jsonOutput;
    }

    /**
     * Get xml data from translate request.
     *
     * @param request - TranslateRequest having Xml data.
     *
     * @return String having Xml data.
     */
    protected String getData(final TranslateRequest request) {
        final String data = StringUtils.substringAfter(request.getSourceAsString(), XmlToJsonTranslator.QUESTION_MARK);
        return StringUtil.trim(data);
    }

    /**
     * Get dynamic path from translate request.
     *
     * @param request - TranslateRequest having Xml data.
     * @return String having dynamic path.
     */
    protected String getDynamicPath(final TranslateRequest request) {
        final String dynamicPath = StringUtil.substringBefore(request.getSourceAsString(), XmlToJsonTranslator.QUESTION_MARK);
        return StringUtil.trim(dynamicPath);
    }

    /**
     * Converts Xml data to Json during Xml to Json translation.
     *
     * @param xmlData - Xml message to be translated.
     * @return String - Converted json output
     *
     * @throws JsonTranslationException - In an event of error while translating XML into json.
     */
    protected String convertToJson(final String xmlData) throws JsonTranslationException {
        String jsonOutput = "";
        try {
            jsonOutput = JsonUtil.toJson(xmlData, 2);
        } catch (final JSONException e) {
            XmlToJsonTranslator.LOGGER.log(Level.SEVERE, "Exception while translating XML to json : ", e);
            throw new JsonTranslationException(e, XmlToJsonTranslator.XML_TO_JSON_TRANSFORMATION_ERROR);
        }
        return jsonOutput;
    }
}