package com.cybage.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.model.Fileinfo;
import com.cybage.service.Database;
import com.cybage.service.DownloadFileByUser;
import com.cybage.service.UploadExcelFile;

@Service
public class UserDAOImpl implements UserDAO {
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();

	@Override
	public String uploadExcelFile(HttpServletRequest request,
			HttpServletResponse response, ModelMap model) {
		UploadExcelFile uploadExcelFile = new UploadExcelFile();
		return uploadExcelFile.uploadExcelFile(request, response, model);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Fileinfo> viewExcel() {
		EntityManager entityManagerObject = Database.getEntityManager();

		ArrayList<Fileinfo> fileList = (ArrayList<Fileinfo>) entityManagerObject
				.createQuery(
						"select s from Fileinfo s where s.status =:chrName")
				.setParameter("chrName", "Unprocessed").getResultList();

		entityManagerObject.close();
		return fileList;
	}

	@Override
	public String updateExcelFile(HttpServletRequest request,
			HttpServletResponse response, ModelMap model, String fileToUpdate) {
		UploadExcelFile uploadExcelFile = new UploadExcelFile();
		return uploadExcelFile.updateExcelFile(request, response, model,
				uploadExcelFile, fileToUpdate);
	}

	@Override
	public boolean downloadFileByuser(String filename,
			HttpServletResponse response) {
		DownloadFileByUser downloadFileByUser = new DownloadFileByUser();
		return downloadFileByUser.downloadFileByuser(filename, response);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Aggregateinvoiceinfo> heldbackQueries() {
		ArrayList<Aggregateinvoiceinfo> heldBackList;
		EntityManager entityManagerObject = Database.getEntityManager();

		heldBackList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"select s from Aggregateinvoiceinfo s where s.invoiceStatus =:chrName")
				.setParameter("chrName", "Heldback").getResultList();

		entityManagerObject.close();
		return heldBackList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Aggregateinvoiceinfo> getVendorAmountMonthwise(
			int vendorCode, java.sql.Date startDate, java.sql.Date endDate) {
		ArrayList<Aggregateinvoiceinfo> vendorAmount;
		EntityManager entityManagerObject = Database.getEntityManager();
		vendorAmount = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"SELECT i FROM Aggregateinvoiceinfo i WHERE i.invoiceDate BETWEEN '"
								+ endDate + "' AND '" + startDate
								+ "' and i.vendorCode=" + vendorCode
								+ " and i.invoiceStatus='Approved'")
				.getResultList();
		loggerInstance.logger.info(vendorAmount.toString());
		entityManagerObject.close();
		return vendorAmount;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Aggregateinvoiceinfo> getVendorAmountHeldback(
			int vendorCode, java.sql.Date startDate, java.sql.Date endDate) {
		ArrayList<Aggregateinvoiceinfo> vendorAmount;
		EntityManager entityManagerObject = Database.getEntityManager();
		vendorAmount = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"SELECT i FROM Aggregateinvoiceinfo i WHERE i.invoiceDate BETWEEN '"
								+ endDate + "' AND '" + startDate
								+ "' and i.vendorCode=" + vendorCode
								+ " and i.invoiceStatus='Heldback'")
				.getResultList();
		loggerInstance.logger.info(vendorAmount.toString());
		entityManagerObject.close();
		return vendorAmount;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Aggregateinvoiceinfo> getVendorAmountExceptional(
			int vendorCode, java.sql.Date startDate, java.sql.Date endDate) {
		ArrayList<Aggregateinvoiceinfo> vendorAmount;
		EntityManager entityManagerObject = Database.getEntityManager();
		vendorAmount = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"SELECT i FROM Aggregateinvoiceinfo i WHERE i.invoiceDate BETWEEN '"
								+ endDate + "' AND '" + startDate
								+ "' and i.vendorCode=" + vendorCode
								+ " and i.pane='Satisfied Exception Criteria'"
								+ "and i.invoiceStatus='Approved'")
				.getResultList();
		loggerInstance.logger.info(vendorAmount.toString());
		entityManagerObject.close();
		return vendorAmount;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Aggregateinvoiceinfo> getVendorAmountAllInvoices(
			int vendorCode, java.sql.Date startDate, java.sql.Date endDate) {
		ArrayList<Aggregateinvoiceinfo> vendorAmount;
		EntityManager entityManagerObject = Database.getEntityManager();
		vendorAmount = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"SELECT i FROM Aggregateinvoiceinfo i WHERE i.invoiceDate BETWEEN '"
								+ endDate + "' AND '" + startDate
								+ "' and i.vendorCode=" + vendorCode
								+ "and i.invoiceStatus='Approved'")
				.getResultList();
		loggerInstance.logger.info(vendorAmount.toString());
		entityManagerObject.close();
		return vendorAmount;
	}
}
