package com.cybage.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.model.Fileinfo;
import com.cybage.service.AddInvoiceToDB;
import com.cybage.service.AddToDB;
import com.cybage.service.Database;
import com.cybage.service.DownloadFileByUser;
import com.cybage.service.HistoricalDataVarianceCriteria;
import com.cybage.service.ManualLimitCriteria;
import com.cybage.service.Messages;
import com.cybage.service.UploadExcelFile;
import com.cybage.service.VendorHistory;

// TODO: Auto-generated Javadoc
/**
 * The Class AdminDAOImpl.
 * 
 */
@Service
public class AdminDAOImpl implements AdminDAO {

	/** The Constant logger. */
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cybage.dao.AdminDAO#viewExcelFiles()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Fileinfo> viewExcelFiles() {
		ArrayList<Fileinfo> fileList;
		EntityManager entityManagerObject = Database.getEntityManager();
		fileList = (ArrayList<Fileinfo>) entityManagerObject
				.createQuery(
						"select s from Fileinfo s where s.status =:chrName")
				.setParameter("chrName", "Unprocessed").getResultList();
		entityManagerObject.close();
		return fileList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cybage.dao.AdminDAO#processFile(java.lang.String,
	 * java.lang.String, org.springframework.ui.ModelMap)
	 */
	@Override
	public String processFile(String ID, String createdBy, ModelMap model) {
		AddInvoiceToDB addInvoiceToDB = new AddInvoiceToDB();
		String message = null;
		
		AddToDB addToDB = new AddToDB();
		String addDb = addToDB.addExcelToDb(ID, model,createdBy);
		if (addDb.contains("successfully")) {
			String updateFileinfo = addInvoiceToDB.updateFileinfo(ID, model);
			if (updateFileinfo.contains("successfully"))
				message = Messages.ADDTODB;
		} else
			message = "Probelm in adding file data to database";
		return message;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cybage.dao.AdminDAO#getPaymentDetails()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ModelAndView getPaymentDetails() {
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		EntityManager entityManagerObject = Database.getEntityManager();
		invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"select s from Aggregateinvoiceinfo s where s.invoiceStatus =:chrName")
				.setParameter("chrName", "Unprocessed").getResultList();

		for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator
				.hasNext();) {
			Aggregateinvoiceinfo aggregateinvoiceinfo = iterator.next();
			loggerInstance.logger.info(aggregateinvoiceinfo.getVendorCode()
					+ " " + aggregateinvoiceinfo.getPaymentAmount());
		}	
		
		ModelAndView modelObject = new ModelAndView("processPaymentbyAdmin");
		modelObject.addObject("file", checkForAveragePaymentCriteria(invoiceList));
		entityManagerObject.close();
		return modelObject;
	}

	public static ArrayList<Aggregateinvoiceinfo> checkForAveragePaymentCriteria(
		ArrayList<Aggregateinvoiceinfo> invoiceList) {
		HashMap<Integer,Double> vendorCodeMap = new HashMap<Integer, Double>();
		HashMap<Integer,Integer> vendorOccuranceMap = new HashMap<Integer, Integer>();
		ArrayList<Aggregateinvoiceinfo> existingPaymentRequestList = (ArrayList<Aggregateinvoiceinfo>) Database.getProcessedRequestVendor();
		
		for(int index=0;index<existingPaymentRequestList.size();index++){
			Aggregateinvoiceinfo aggregateObject = existingPaymentRequestList.get(index);
			int vendorCode = aggregateObject.getVendorCode();
			double paymentAmount = aggregateObject.getPaymentAmount();
			loggerInstance.logger.info("Payment id = "+aggregateObject.getId()+"Vendor Code ="+vendorCode+"\tPayment Amount ="+paymentAmount);
			if(vendorCodeMap.containsKey(vendorCode)){
				double existingAmount = vendorCodeMap.get(vendorCode);
				vendorCodeMap.put(vendorCode,(paymentAmount+existingAmount));
				int occurance = vendorOccuranceMap.get(vendorCode);
				occurance++;
				vendorOccuranceMap.put(vendorCode,occurance);
			}
			else{
				vendorCodeMap.put(vendorCode,paymentAmount);
				vendorOccuranceMap.put(vendorCode, 1);
			}
		}
		
		loggerInstance.logger.info("Processed payment map = "+vendorCodeMap.toString()+"\n"+vendorCodeMap.size());
		loggerInstance.logger.info("vendor Occurance Map = "+vendorOccuranceMap.toString()+"\n"+vendorOccuranceMap.size());
		for(int index = 0;index<invoiceList.size();index++){
			Aggregateinvoiceinfo object = invoiceList.get(index);
			int vendorCode = object.getVendorCode();
		if(vendorCodeMap.containsKey(vendorCode)){
			double averagePaymentAmount = 0;
			loggerInstance.logger.info("Average payment amount before procedure call = "+averagePaymentAmount);
			double approvedAmount = vendorCodeMap.get(vendorCode);
			int approvedRequest = vendorOccuranceMap.get(vendorCode);
		averagePaymentAmount = approvedAmount/approvedRequest;
		loggerInstance.logger.info("Vendor Code = "+vendorCode+"\t averagePaymentAmount: "
				+ averagePaymentAmount);
		if(averagePaymentAmount>0 && object.getPaymentAmount()<=averagePaymentAmount){
			object.setPane("Satisfied Average Payment Criteria");
			loggerInstance.logger.info("Satisfied Average Payment Criteria"+object.getVendorCode());
		}
		else{
			object.setPane("Average Payment Criteria Not Satisfied");
		}
		}
		else{
			object.setPane("New Vendor");
		}
	}
	return invoiceList;	
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cybage.dao.AdminDAO#getVariance(java.lang.String, int, int,
	 * java.lang.String)
	 */
	@Override
	public ModelAndView getVariance(String variance, int vendorID, double payment,
			String invoiceNum, String invoiceDate) {
		ArrayList<String> result = new ArrayList<String>();
		loggerInstance.logger.info("Varience percentage:" + variance);
		int percentVariance = Integer.parseInt(variance);

		HistoricalDataVarianceCriteria object = new HistoricalDataVarianceCriteria();
		result = object.applyCriteria(percentVariance, vendorID, payment,
				invoiceDate);

		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<String> name;

		result.add(invoiceNum);

		if (result.get(2).equals("success")) {
			invoiceList = AddInvoiceToDB.returnUnprocessedInvoiceList();
			name = AddInvoiceToDB.returnUnprocessedVendorName();
			ModelAndView modelObject = new ModelAndView("paneProcessing");
			modelObject.addObject("file", invoiceList);
			AddInvoiceToDB.updateStatus(invoiceNum,
					"Satisfied Variance Criteria");

			modelObject.addObject("message", "success");
			modelObject.addObject("vendorName", name);

			VendorHistory.updateAggregateInvoiceRequest(invoiceNum,
					"Processed", "Pane2");

			Map<String, String> historyMap = VendorHistory
					.getVendorHistory(vendorID);
			ArrayList<String> historyList = new ArrayList<String>();
			ArrayList<String> historyListPeriod = new ArrayList<String>();

			for (Entry<String, String> entry : historyMap.entrySet()) {
				String[] splittingMonth = entry.getKey().split("/");

				historyListPeriod.add(getMonthName(splittingMonth[1]) + "-"
						+ splittingMonth[0]);
				historyList.add(entry.getValue());
			}

			modelObject.addObject("vendorHistoryPeriod", historyListPeriod);
			modelObject.addObject("vendorHistory", historyList);
			return modelObject;
		}

		else {
			// calculate min max value here
			result.add(invoiceDate);

			ModelAndView modelObject = new ModelAndView("paneProcessing");
			modelObject.addObject("result", result);
			modelObject.addObject("message", "fail");
			modelObject.addObject("paneNumber", "pane3");

			Map<String, String> historyMap = VendorHistory
					.getVendorHistory(vendorID);
			ArrayList<String> historyList = new ArrayList<String>();
			ArrayList<String> historyListPeriod = new ArrayList<String>();

			for (Entry<String, String> entry : historyMap.entrySet()) {
				String[] splittingMonth = entry.getKey().split("/");

				historyListPeriod.add(getMonthName(splittingMonth[1]) + "-"
						+ splittingMonth[0]);
				historyList.add(entry.getValue());
			}

			modelObject.addObject("vendorHistoryPeriod", historyListPeriod);
			modelObject.addObject("vendorHistory", historyList);

			EntityManager entityManagerObject1 = Database.getEntityManager();

			StoredProcedureQuery storedProcedure = entityManagerObject1
					.createStoredProcedureQuery("computeMinMax");

			storedProcedure.registerStoredProcedureParameter("venID",
					Integer.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("minimum",
					Integer.class, ParameterMode.OUT);
			storedProcedure.registerStoredProcedureParameter("maximum",
					Integer.class, ParameterMode.OUT);
			storedProcedure.setParameter("venID", vendorID);

			storedProcedure.execute();

			int minValue = (Integer) storedProcedure
					.getOutputParameterValue("minimum");
			int maxValue = (Integer) storedProcedure
					.getOutputParameterValue("maximum");

			loggerInstance.logger.info("minValue" + minValue);
			loggerInstance.logger.info("maxValue" + maxValue);

			if (minValue == maxValue || minValue <= 0 || maxValue <= 0) {
				modelObject.addObject("minimum", "");
				modelObject.addObject("maximum", "");
			} else {
				modelObject.addObject("minimum", String.valueOf(minValue));
				modelObject.addObject("maximum", String.valueOf(maxValue));
			}
			entityManagerObject1.close();
			return modelObject;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cybage.dao.AdminDAO#manualLimit(java.lang.String, int,
	 * java.lang.String, int)
	 */
	@Override
	public ModelAndView manualLimit(int minimumLimit, int maximumLimit,
			int vendorID, String invoiceNum, double payment, String invoiceDate) {
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<String> name;
		ArrayList<String> resultList = new ArrayList<String>();
		resultList.add(String.valueOf(vendorID));
		resultList.add(String.valueOf(payment));
		resultList.add(invoiceNum);
		resultList.add(invoiceDate);
		loggerInstance.logger.info("Maximum Limit:" + maximumLimit);
		loggerInstance.logger.info("vendorID:" + vendorID);
		loggerInstance.logger.info("amount:" + payment);
		loggerInstance.logger.info("invoiceNum:" + invoiceNum);

		ManualLimitCriteria object = new ManualLimitCriteria();
		boolean result = object.applyCriteria(minimumLimit, maximumLimit,
				vendorID, payment);

		if (result) {
			AddInvoiceToDB.updateStatus(invoiceNum,
					"Satisfied Manual Limit Criteria");

			VendorHistory.updateAggregateInvoiceRequest(invoiceNum,
					"Processed", "Satisfied Manual Limit Criteria");
			invoiceList = AddInvoiceToDB.returnUnprocessedInvoiceList();
			name = AddInvoiceToDB.returnUnprocessedVendorName();
			ModelAndView modelObject = new ModelAndView("paneProcessing");

			modelObject.addObject("file", invoiceList);
			modelObject.addObject("vendorName", name);
			modelObject.addObject("message", "success");

			return modelObject;
		} else {

			AddInvoiceToDB.updateStatus(invoiceNum, "Satisfied no Criteria");
			invoiceList = AddInvoiceToDB.returnUnprocessedInvoiceList();
			name = AddInvoiceToDB.returnUnprocessedVendorName();

			ModelAndView modelObject = new ModelAndView("paneProcessing");
			modelObject.addObject("file", invoiceList);
			modelObject.addObject("vendorName", name);
			modelObject.addObject("message", "fail");
			modelObject.addObject("vendorInfo", resultList);
			modelObject.addObject("paneNumber", "pane4");

			Map<String, String> historyMap = VendorHistory
					.getVendorHistory(vendorID);
			ArrayList<String> historyList = new ArrayList<String>();
			ArrayList<String> historyListPeriod = new ArrayList<String>();

			for (Entry<String, String> entry : historyMap.entrySet()) {
				String[] splittingMonth = entry.getKey().split("/");

				historyListPeriod.add(getMonthName(splittingMonth[1]) + "-"
						+ splittingMonth[0]);
				historyList.add(entry.getValue());
			}

			modelObject.addObject("vendorHistoryPeriod", historyListPeriod);
			modelObject.addObject("vendorHistory", historyList);

			return modelObject;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cybage.dao.AdminDAO#updateStatus(java.lang.String)
	 */
	@Override
	public ArrayList<Aggregateinvoiceinfo> updateStatus(String invoiceNum) {
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		AddInvoiceToDB.updateStatus(invoiceNum,
				"Satisfied Average Payment Criteria");
		invoiceList = AddInvoiceToDB.returnUnprocessedInvoiceList();

		return invoiceList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.cybage.dao.AdminDAO#updateExcelFile(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse,
	 * org.springframework.ui.ModelMap, java.lang.String)
	 */
	@Override
	public String updateExcelFile(HttpServletRequest request,
			HttpServletResponse response, ModelMap model, String fileToUpdate) {
		UploadExcelFile uploadExcelFile = new UploadExcelFile();
		return uploadExcelFile.updateExcelFile(request, response, model,
				uploadExcelFile, fileToUpdate);
	}

	private static String getMonthName(String splittingMonth) {
		String monthString;
		int month = Integer.parseInt(splittingMonth);
		switch (month) {
		case 0:
			monthString = "0";
			break;
		case 1:
			monthString = "Jan";
			break;
		case 2:
			monthString = "Feb";
			break;
		case 3:
			monthString = "Mar";
			break;
		case 4:
			monthString = "Apr";
			break;
		case 5:
			monthString = "May";
			break;
		case 6:
			monthString = "June";
			break;
		case 7:
			monthString = "July";
			break;
		case 8:
			monthString = "Aug";
			break;
		case 9:
			monthString = "Sep";
			break;
		case 10:
			monthString = "Oct";
			break;
		case 11:
			monthString = "Nov";
			break;
		case 12:
			monthString = "Dec";
			break;
		default:
			monthString = "Invalid month";
			break;
		}
		return monthString;
	}

	@Override
	public boolean downloadFileByAdmin(String filename,
			HttpServletResponse response) {
		DownloadFileByUser downloadFileByUser = new DownloadFileByUser();
		return downloadFileByUser.downloadFileByuser(filename, response);	
	}
	
	public  static int getAverageAmount(int vendorCode){
		EntityManager entityManagerObject = Database.getEntityManager();
		StoredProcedureQuery storedProcedure = entityManagerObject
				.createStoredProcedureQuery("computeAverage");
		loggerInstance.logger.info("Created procedure");
		storedProcedure.registerStoredProcedureParameter(0,
				Integer.class, ParameterMode.IN);
		loggerInstance.logger.info("Set IN Parameter");
		storedProcedure.registerStoredProcedureParameter(1,
				Integer.class, ParameterMode.OUT);
		loggerInstance.logger.info("Set OUT Parameter");
		storedProcedure.setParameter(0,vendorCode);
		loggerInstance.logger.info("Vendor code = "+vendorCode);
		storedProcedure.execute();
		loggerInstance.logger.info("Executed procedure "+storedProcedure
				.getOutputParameterValue(1));
		int averagePaymentAmount = (Integer) storedProcedure.getOutputParameterValue(1);
		storedProcedure.setFlushMode(FlushModeType.AUTO);
		//entityManagerObject.clear();
		//entityManagerObject.flush();
		entityManagerObject.close();
		return averagePaymentAmount;
	}
}