package com.cybage.dao;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

@Service
public interface LoginDAO {

	boolean validate(String username, byte[] encryptedPassword,
			HttpServletRequest request, SecretKey secretKey);
	
	String checkRole(String username);

}
