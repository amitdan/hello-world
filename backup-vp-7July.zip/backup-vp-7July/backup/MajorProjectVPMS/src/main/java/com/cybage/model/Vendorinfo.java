package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the vendorinfo database table.
 * 
 */
@Entity
@NamedQuery(name="Vendorinfo.findAll", query="SELECT v FROM Vendorinfo v")
public class Vendorinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private int maximumPayment;

	private int minimumPayment;

	@Lob
	private String purchaseOrder;

	private int vendorCode;

	private String vendorName;

	public Vendorinfo() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMaximumPayment() {
		return this.maximumPayment;
	}

	public void setMaximumPayment(int maximumPayment) {
		this.maximumPayment = maximumPayment;
	}

	public int getMinimumPayment() {
		return this.minimumPayment;
	}

	public void setMinimumPayment(int minimumPayment) {
		this.minimumPayment = minimumPayment;
	}

	public String getPurchaseOrder() {
		return this.purchaseOrder;
	}

	public void setPurchaseOrder(String purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public int getVendorCode() {
		return this.vendorCode;
	}

	public void setVendorCode(int vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getVendorName() {
		return this.vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

}