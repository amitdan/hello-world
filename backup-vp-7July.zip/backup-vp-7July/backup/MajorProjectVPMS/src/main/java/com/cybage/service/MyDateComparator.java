package com.cybage.service;

import java.util.Comparator;

import com.cybage.configuration.LoggerClass;

public class MyDateComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		int result = 0;
		LoggerClass.logger.info("String 1"+o1+"\t String 2"+o2);
		String[] myArray1 =  o1.split("/");
		
		int monthOfFirstString = Integer.parseInt(myArray1[1]);
		
		String[] myArray2 = o2.split("/");
		int monthOfSecondString = Integer.parseInt(myArray2[1]);
		
		if(monthOfFirstString < monthOfSecondString)
			result=-1;
		
		if(monthOfFirstString > monthOfSecondString)
			result=1;
		if(monthOfFirstString == monthOfSecondString)
		result = myArray1[0].compareTo(myArray2[0]);
		
		LoggerClass.logger.info(result);
		
	return result;
	}
}
