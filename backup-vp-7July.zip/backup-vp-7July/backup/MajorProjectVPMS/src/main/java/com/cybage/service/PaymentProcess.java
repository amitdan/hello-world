package com.cybage.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.ui.ModelMap;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.Aggregateinvoiceinfo;

public class PaymentProcess {
	private static final LoggerClass loggerInstance = LoggerClass
			.getLoggerInstance();

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Aggregateinvoiceinfo> listofProcessed(ModelMap model) {
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		EntityManager entityManagerObject = Database.getEntityManager();
		invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"select s from Aggregateinvoiceinfo s where s.invoiceStatus =:chrName")
				.setParameter("chrName", "Processed").getResultList();
		entityManagerObject.close();
		return invoiceList;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void approveInvoiceinfo(int invoiceId, ModelMap model)
			throws IOException {

		EntityManager entityManagerObject = Database.getEntityManager();

		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<String> dataList = new ArrayList<String>();
		EntityTransaction updateTransaction = entityManagerObject
				.getTransaction();
		updateTransaction.begin();
		Query query = entityManagerObject
				.createQuery("UPDATE Aggregateinvoiceinfo SET invoiceStatus = 'Approved' "
						+ "WHERE id= :invoiceid");
		query.setParameter("invoiceid", invoiceId);
		int updateCount = query.executeUpdate();
		loggerInstance.logger.info(updateCount);
		invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"select s from Aggregateinvoiceinfo s where s.id =:chrName ")
				.setParameter("chrName", invoiceId).getResultList();
		updateTransaction.commit();

		dataList.add(String.valueOf(invoiceList.get(0).getVendorCode()));
		dataList.add(invoiceList.get(0).getVendorName());
		dataList.add(String.valueOf(invoiceList.get(0).getPaymentAmount()));
		dataList.add(invoiceList.get(0).getPane());
		dataList.add(invoiceList.get(0).getInvoiceStatus());
		dataList.add(invoiceList.get(0).getRemark());
		dataList.add(String.valueOf(invoiceList.get(0).getPendingPayment()));
		dataList.add(String.valueOf(invoiceId));
		entityManagerObject.close();
		// sending mail
		//SendMail.sendMail(dataList);
			}

	@Transactional
	public void heldbackInvoiceinfo(int invoiceId, ModelMap model) {

		EntityManager entityManagerObject = Database.getEntityManager();
		EntityTransaction updateTransaction = entityManagerObject
				.getTransaction();
		updateTransaction.begin();
		loggerInstance.logger.info("My invoice Id:" + invoiceId);
		Query query = entityManagerObject
				.createQuery("UPDATE Aggregateinvoiceinfo SET invoiceStatus = 'Heldback' "
						+ "WHERE id= :invoiceid");
		query.setParameter("invoiceid", invoiceId);
		int updateCount = query.executeUpdate();
		loggerInstance.logger.info("" + updateCount);
		updateTransaction.commit();
		entityManagerObject.close();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void updateRemark(int invoiceId, ModelMap model, String remark)
			throws IOException {

		EntityManager entityManagerObject = Database.getEntityManager();
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<String> dataList = new ArrayList<String>();

		loggerInstance.logger.info(remark + invoiceId + "hello");

		EntityTransaction updateTransaction = entityManagerObject
				.getTransaction();
		updateTransaction.begin();
		Query query = entityManagerObject
				.createQuery("UPDATE Aggregateinvoiceinfo SET remark = ?1 "
						+ "WHERE id= :invoiceid");
		query.setParameter(1, remark);
		query.setParameter("invoiceid", invoiceId);
		int updateCount = query.executeUpdate();
		loggerInstance.logger.info(updateCount);
		invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"select s from Aggregateinvoiceinfo s where s.id =:chrName ")
				.setParameter("chrName", invoiceId).getResultList();
		updateTransaction.commit();
		loggerInstance.logger.info("Inside serviceimpl.ExportToExcel method");
		dataList.add(String.valueOf(invoiceList.get(0).getVendorCode()));
		dataList.add(invoiceList.get(0).getVendorName());
		dataList.add(String.valueOf(invoiceList.get(0).getPaymentAmount()));
		dataList.add(invoiceList.get(0).getPane());
		dataList.add(invoiceList.get(0).getInvoiceStatus());
		dataList.add(invoiceList.get(0).getRemark());
		dataList.add(String.valueOf(invoiceList.get(0).getPendingPayment()));
		dataList.add(String.valueOf(invoiceId));
		entityManagerObject.close();
		// sending mail
		//SendMail.sendMail(dataList);

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Aggregateinvoiceinfo> listInvoice(int invoiceId, ModelMap model) {
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		EntityManager entityManagerObject = Database.getEntityManager();

		invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"select s from Aggregateinvoiceinfo s where s.id =:chrName")
				.setParameter("chrName", invoiceId).getResultList();
		loggerInstance.logger.info("" + invoiceList);
		entityManagerObject.close();
		return invoiceList;
	}
}
