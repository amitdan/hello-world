package com.cybage.controller;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.dao.SuperAdminDAO;
import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.service.Database;
import com.cybage.service.Description;
import com.cybage.service.Messages;
import com.cybage.service.PaymentProcess;
import com.cybage.service.ReportGeneration;
import com.cybage.service.ValidateExcelFile;
import com.fasterxml.jackson.core.JsonProcessingException;


/**
 * Handles requests for the application super admin page.
 */

@Controller
public class SuperAdminController {
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	@Autowired
    private SuperAdminDAO superadminDao;
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/viewPaymentDetails" , method = RequestMethod.GET)
	public ModelAndView viewPaymentDetails( ModelMap model){		
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		 EntityManager entityManagerObject=Database.getEntityManager();
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery("select s from Aggregateinvoiceinfo s where s.invoiceStatus =:chrName")
		  			.setParameter("chrName","Processed").getResultList();
		  	
		 for (int index=0;index<invoiceList.size();index++) {
			   Aggregateinvoiceinfo aggregateinvoiceinfo = invoiceList.get(index);
			   loggerInstance.logger.info(aggregateinvoiceinfo.getVendorCode()+" "+aggregateinvoiceinfo.getPaymentAmount());
		  	}
		 
	  	 ModelAndView modelObject = new ModelAndView("processPaymentBySuperAdmin");
			modelObject.addObject("file",invoiceList);	
			entityManagerObject.close();
		return modelObject;
	}
		
// approve the request	
	@RequestMapping(value="/approve" , method = RequestMethod.GET)
	public ModelAndView approve(@RequestParam ("invoiceID")int invoiceId, ModelMap model){
			
		PaymentProcess paymentprocess =new PaymentProcess();
		loggerInstance.logger.info("VALUE::  "+invoiceId );
		try {
			paymentprocess.approveInvoiceinfo(invoiceId,model);
		} catch (IOException e) {
			loggerInstance.logger.error(e);	
		}
		List<Aggregateinvoiceinfo> listofInvoice=paymentprocess.listofProcessed(model);
		ModelAndView modelObject = new ModelAndView("processPaymentBySuperAdmin");
 		//Send to pay page
 		 modelObject.addObject("file",listofInvoice);
 		modelObject.addObject("message",Messages.PAYMENT_APPROVED);
 		 return modelObject;
	}
	
	// approve the request	
		@RequestMapping(value="/approveAndPay" , method = RequestMethod.GET)
		public ModelAndView approveAndPay(@RequestParam ("invoiceID")int invoiceId, ModelMap model){
				
			PaymentProcess paymentprocess =new PaymentProcess();
			loggerInstance.logger.info("VALUE::  "+invoiceId );
			try {
				paymentprocess.approveInvoiceinfo(invoiceId,model);
			} catch (IOException e) {
				loggerInstance.logger.error(e);	
			}
			
			List<Aggregateinvoiceinfo> listofInvoice = paymentprocess.listInvoice(
					invoiceId, model);
			ModelAndView modelObject = new ModelAndView("paymentRequest");
			modelObject.addObject("file", listofInvoice);
			modelObject.addObject("message",Messages.PAYMENT_APPROVED);
			return modelObject;
		}
	
	// heldback the request	
	@RequestMapping(value = "/heldback", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam ("invoiceID")int invoiceId, ModelMap model){
		return superadminDao.viewheldback(invoiceId,model);		
	}
	
	// heldback the request	
		@RequestMapping(value = "/payment", method = RequestMethod.GET)
		public ModelAndView pay(@RequestParam ("invoiceID")int invoiceId, ModelMap model){
			return superadminDao.doPayment(invoiceId,model);		
		}
	
	@RequestMapping(value ="/addHeldbackComment", method = RequestMethod.GET)
	public ModelAndView computeManualLimit( ModelMap model,@RequestParam("invoiceId")int invoiceId,@RequestParam("remark")String remark) {
	
		
		PaymentProcess paymentprocess =new PaymentProcess();
		loggerInstance.logger.info("VALUE Manual Limit::  "+invoiceId );
		loggerInstance.logger.info("Mnual"+remark);
		paymentprocess.heldbackInvoiceinfo(invoiceId, model);
		try {
			paymentprocess.updateRemark(invoiceId,model,remark);
		} catch (IOException e) {
			loggerInstance.logger.error(e);
		}
		List<Aggregateinvoiceinfo> listofInvoice=paymentprocess.listofProcessed(model);
		ModelAndView modelObject = new ModelAndView("processPaymentBySuperAdmin");
		 modelObject.addObject("file",listofInvoice);
		modelObject.addObject("message",Messages.PAYMENT_HELDBACK);
		 return modelObject;
		}
	
	@RequestMapping(value="/adminhome" , method = RequestMethod.GET)
	public ModelAndView useradmin( ModelMap model){
		ModelAndView modelObject = new ModelAndView("adminHome");
		modelObject.addObject("value", "superadmin");
		return modelObject;
	}
	
	@RequestMapping(value="/userhome" , method = RequestMethod.GET)
	public ModelAndView userhome( ModelMap model){		
		ModelAndView modelObject = new ModelAndView("userHome");
		modelObject.addObject("value", "superadmin");
		return modelObject;
	
	}
	
	@RequestMapping(value = "/superAdminHome", method = RequestMethod.GET)
	public String superAdminMainu() {
		return "superAdminHome";
	}
	@RequestMapping(value = "/superAdminReport", method = RequestMethod.GET)
	public ModelAndView superAdminReportf() {
		return ReportGeneration.getMonthlyPayment();	
	}
	@RequestMapping(value = "/getApproveReport", method = RequestMethod.GET)
	public ModelAndView getApproveReport(Locale locale, Model model,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {
		
		loggerInstance.logger.info("fromDate :"+fromDate);
		loggerInstance.logger.info("toDate :"+toDate);
		return ReportGeneration.getPercentApprovedData( fromDate, toDate);	
	}
	@RequestMapping(value = "/getHeldbackReport", method = RequestMethod.GET)
	public ModelAndView getHeldbackReport(Locale locale, Model model,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {

	
		loggerInstance.logger.info("fromDate :"+fromDate);
		loggerInstance.logger.info("toDate :"+toDate);		
		
		return ReportGeneration.getPercentHeldbackData( fromDate, toDate);	
	}
	@RequestMapping(value = "/getPaymentReport", method = RequestMethod.GET)
	public ModelAndView getPaymentReport(Locale locale, Model model,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {

		
		loggerInstance.logger.info("fromDate :"+fromDate);
		loggerInstance.logger.info("toDate :"+toDate);

		return ReportGeneration.getPercentPaymentData( fromDate, toDate);	
	}
	@RequestMapping(value = "/getExceptionalReport", method = RequestMethod.GET)
	public ModelAndView getExceptionalReport(Locale locale, Model model,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {

		loggerInstance.logger.info("fromDate :"+fromDate);
		loggerInstance.logger.info("toDate :"+toDate);
		return ReportGeneration.getExceptionalReport( fromDate, toDate);	
	}
	
	@RequestMapping(value="/addColumn" , method = RequestMethod.GET)
	public ModelAndView addColumnHeader(){
		loggerInstance.logger.info("Request for adding column in table");
		ModelAndView modelAndView = new ModelAndView("addColumn");
		ArrayList<String> headerNames = ValidateExcelFile.getTableHeader();
		loggerInstance.logger.info("Size of table headers = "+headerNames.size());
		modelAndView.addObject("databaseHeader",headerNames);
			return modelAndView;
	}
	
	@RequestMapping(value="/insertColumn" , method = RequestMethod.GET)
	public ModelAndView insertColumn(HttpServletRequest request){
		String columnName = request.getParameter("columnName");
		loggerInstance.logger.info("Got request for insert column");
		ModelAndView modelAndView = new ModelAndView("addColumn");
		loggerInstance.logger.info("Column Name = "+columnName);
		Database.addColumn(columnName);
		ArrayList<String> headerNames = ValidateExcelFile.getTableHeader();
		loggerInstance.logger.info("Size of table headers = "+headerNames.size());
		modelAndView.addObject("databaseHeader",headerNames);
			return modelAndView;				
	}
	

	@RequestMapping(value = "/getDescriptionApproved", method = RequestMethod.GET)
	public ModelAndView getDescription(Locale locale, Model model,@RequestParam("vendorCode")String vendorCode,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getDescriptionApproved(vendorCode, fromDate, toDate);	
	}
	
	@RequestMapping(value = "/getDescriptionHeldback", method = RequestMethod.GET)
	public ModelAndView getDescriptionHeldback(Locale locale, Model model,@RequestParam("vendorCode")String vendorCode,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getDescriptionHeldback(vendorCode, fromDate, toDate);	
	}
	
	@RequestMapping(value = "/getDescriptionAll", method = RequestMethod.GET)
	public ModelAndView getDescriptionAll(Locale locale, Model model,@RequestParam("vendorCode")String vendorCode,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getDescriptionAll(vendorCode, fromDate, toDate);	
	}
	
	@RequestMapping(value = "/getDescriptionException", method = RequestMethod.GET)
	public ModelAndView getDescriptionException(Locale locale, Model model,@RequestParam("vendorCode")String vendorCode,@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getDescriptionException(vendorCode, fromDate, toDate);	
	}
	
	
	@RequestMapping(value = "/getHistory", method = RequestMethod.GET)
	public ModelAndView getHistory(@RequestParam("vendorCode")String vendorCode) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getHistory(vendorCode);	
	}
	
	@RequestMapping(value = "/getHistoryForHeldback", method = RequestMethod.GET)
	public ModelAndView getHistoryForHeldback(@RequestParam("vendorCode")String vendorCode) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getHistoryForHeldback(vendorCode);	
	}
	
	@RequestMapping(value = "/getHistoryForExceptional", method = RequestMethod.GET)
	public ModelAndView getHistoryForExceptional(@RequestParam("vendorCode")String vendorCode) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getHistoryForExceptional(vendorCode);	
	}
	
	@RequestMapping(value = "/getHistoryForAllInvoices", method = RequestMethod.GET)
	public ModelAndView getHistoryForAllInvoices(@RequestParam("vendorCode")String vendorCode) throws JsonProcessingException {

		loggerInstance.logger.info("vendorCode :"+vendorCode);
		
		return Description.getHistoryForAllInvoices(vendorCode);	
	}
	
	
}
