package com.cybage.service;

import java.io.File;
import java.util.List;

import javax.persistence.*;
import javax.servlet.http.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.*;

import org.apache.commons.fileupload.*;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

public class UploadExcelFile {
	private static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	private static final String UPLOAD_DIRECTORY = System.getProperty("user.dir")+"\\Files";
	private static final String TEMP_DIRECTORY = System.getProperty("user.dir")+"\\TEMPFiles\\";
	
	public String uploadExcelFile( HttpServletRequest request,HttpServletResponse response,ModelMap model){
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		Fileinfo fileinfo=new Fileinfo();	
		boolean flag=true;
		String message=null;
		String name1=null;
		try{
        // process only if its multipart content
        if (isMultipart) {
                // Create a factory for disk-based file items
                FileItemFactory factory = new DiskFileItemFactory();

                // Create a new file upload handler
                ServletFileUpload upload = new ServletFileUpload(factory);
               
                    // Parse the request
                    List<FileItem> multiparts = upload.parseRequest(request);
                   
                   for (FileItem item : multiparts) {
                   if (!item.isFormField()) {                  	   
                	   
                	   String fileName = FilenameUtils.getName(item.getName());
                	   String name = new File(fileName).getName();
                	   loggerInstance.logger.info("File name = "+name);
                	   if((name.contains(".xlsx"))||(name.contains(".xls"))){
                		   item.write(new File(TEMP_DIRECTORY + File.separator + name));
                           String path=TEMP_DIRECTORY + File.separator + name;
                           loggerInstance.logger.info("File path for temp directory = "+path);
                    	   //checked file validation
                           ValidateExcelFile validateExcelFile=new ValidateExcelFile();
                   			boolean validFile=validateExcelFile.validateExcelFile(path);               			             			
                   			loggerInstance.logger.info("Valid File = "+validFile);
                   			if(validFile){
                   				java.util.Date utilDate = new java.util.Date();                	   
                         	    java.sql.Timestamp sq = new java.sql.Timestamp(utilDate.getTime());
                         	    fileinfo.setDateCreated(sq);   
                         	    String a[]=sq.toString().split(" ");
                         	    loggerInstance.logger.info(""+ fileinfo.getDateCreated());
                         	   loggerInstance.logger.info(fileinfo.getFilename());
                         	   loggerInstance.logger.info("Adding file entry to Table");
                         	    String n="NEFT_"+a[0]+"_"+a[1].replaceAll(":",".");
                         	    fileinfo.setFilename(n);
                         	    fileinfo.setStatus("Unprocessed");
                         	    HttpSession session=request.getSession();                     	 
                         	    fileinfo.setCreatedBy(session.getAttribute("username").toString());
                         	   loggerInstance.logger.info( fileinfo.getFilename());
                         	  loggerInstance.logger.info(""+fileinfo.getDateCreated());
                         	    model.addAttribute("filename", fileinfo.getFilename());
                         	    model.addAttribute("datecreated", fileinfo.getDateCreated());
                         	    model.addAttribute("createdby", fileinfo.getCreatedBy());
                         	    model.addAttribute("status", fileinfo.getStatus());                         	   	   
                         	    name1 = new File(n).getName();
                         	   loggerInstance.logger.info("File path ="+name1);
                         		FileUtils.copyFile(new File(path),new File(UPLOAD_DIRECTORY + File.separator + name1+".xlsx"));
                         		loggerInstance.logger.info("Your file has been uploaded!");
                   				flag=true;
                   				message=Messages.FILE_UPLOADED;
                   			}else{
                   				loggerInstance.logger.debug("Your file not uploaded!");
                   			 flag=false;
                   			 message=Messages.FILE_TEMPLATE;
                   			}
                	   }
                	   else{
                		  message=Messages.FILE_EXTENSIONS; 
                	   }                           	  
                   }
                }       
      
        }else 
        {
        	loggerInstance.logger.info("This Servlet only handles file upload request");
        message="Problem in handling file upload request";
        }
		
		}
		catch(Exception e){
			loggerInstance.logger.error(e);
			flag=false;
            message=Messages.FILE_PROBLEM;
            loggerInstance.logger.info("File path in exception="+name1);
		} 
		if(message.contains("successfully")){
			 EntityManager entityManagerObject=Database.getEntityManager();	 		
			 entityManagerObject.getTransaction().begin();
			 entityManagerObject.persist(fileinfo);
			 entityManagerObject.getTransaction().commit(); 
			 entityManagerObject.close();
		}
		return message;
	}
	
	public String updateExcelFile(HttpServletRequest request, HttpServletResponse response, ModelMap model,UploadExcelFile uploadExcelFile,String fileToUpdate) {
		//upload file
		String message=uploadExcelFile.uploadExcelFile(request, response, model);
		if(message.contains("successfully")){
		EntityManager entityManagerObject=Database.getEntityManager();	
			
		EntityTransaction updateTransaction = entityManagerObject.getTransaction();
		updateTransaction.begin();
		Query query = entityManagerObject.createQuery("DELETE from Fileinfo fileinfo WHERE fileinfo.filename= :filename");
		query.setParameter("filename", fileToUpdate);
		query.executeUpdate();
				
		updateTransaction.commit();
		File f=new File(UPLOAD_DIRECTORY + File.separator +fileToUpdate+".xlsx"); 
		boolean result = f.delete();
		loggerInstance.logger.info("FILE DELETED "+result);
		message=Messages.FILE_REPLACED;
		entityManagerObject.close();
		}
		return message;
	}
}
