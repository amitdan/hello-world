package com.cybage.service;

import java.util.ArrayList;

import javax.persistence.*;
import javax.transaction.Transactional;

import org.springframework.ui.ModelMap;

import javax.persistence.EntityTransaction;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.*;


public class AddInvoiceToDB {
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	@Transactional
	public String updateFileinfo(String iD, ModelMap model) {
		
		EntityManager entityManagerObject=Database.getEntityManager();
				EntityTransaction updateTransaction = entityManagerObject.getTransaction();
				updateTransaction.begin();
				Query query = entityManagerObject.createQuery("UPDATE Fileinfo fileinfo SET fileinfo.status = 'Processed' "
				+ "WHERE fileinfo.filename= :filename");
				query.setParameter("filename", iD);
				query.executeUpdate();
				
				updateTransaction.commit();
				entityManagerObject.close();
				
		return "database modified successfully";
	}
	
	public static void updateStatus(String invoiceNum,String status){
			  	   
		EntityManager entityManagerObject=Database.getEntityManager();
					EntityTransaction updateTransaction = entityManagerObject.getTransaction();
					updateTransaction.begin();
					Query query = entityManagerObject.createQuery("UPDATE Aggregateinvoiceinfo invoiceinfo SET invoiceinfo.invoiceStatus = ?1 "
					+ "WHERE invoiceinfo.id= :num");
					query.setParameter(1, status);
					query.setParameter("num", Integer.parseInt(invoiceNum));
					int updateCount = query.executeUpdate();
					loggerInstance.logger.info(updateCount);
					updateTransaction.commit();
					entityManagerObject.close();
	}
	//redirect to process pay view
	
	@SuppressWarnings("unchecked")
	public static ArrayList<Aggregateinvoiceinfo> returnUnprocessedInvoiceList(){
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		EntityManager entityManagerObject=Database.getEntityManager();
		
	  	 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery("select s from Aggregateinvoiceinfo s where s.invoiceStatus =:chrName")
	  			.setParameter("chrName","Unprocessed").getResultList();
	  	entityManagerObject.close();
	  	   return invoiceList;
	}
	
	
	//return Vendor names where status is unprocessed
	@SuppressWarnings("unchecked")
	public static ArrayList<String> returnUnprocessedVendorName(){
ArrayList<Aggregateinvoiceinfo> invoiceList;	
		
		ArrayList<Vendorinfo> vendorList;		
		ArrayList<String> name=new ArrayList<String>();
		
		EntityManager entityManagerObject=Database.getEntityManager();
		
	  	 vendorList = (ArrayList<Vendorinfo>) entityManagerObject.createQuery("select s from Vendorinfo s").getResultList();

	  	 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery("select s from Aggregateinvoiceinfo s where s.invoiceStatus =:chrName")
	  			.setParameter("chrName","Unprocessed").getResultList();
	  	
	  	 
	  	for (Aggregateinvoiceinfo invoiceObject : invoiceList) {
	  		for (Vendorinfo vendorObject : vendorList) {
  	 		 	if(vendorObject.getVendorCode()==invoiceObject.getVendorCode())
  	 		 		name.add(vendorObject.getVendorName());
  	 	    }
		}
	  	entityManagerObject.close();
		return name;		
	}
}
