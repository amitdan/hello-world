package com.cybage.dao;

import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.model.Fileinfo;

@Service
public interface UserDAO {

	String uploadExcelFile(HttpServletRequest request,
			HttpServletResponse response, ModelMap model);

	ArrayList<Fileinfo> viewExcel();

	String updateExcelFile(HttpServletRequest request,
			HttpServletResponse response, ModelMap model, String fileToUpdate);

	boolean downloadFileByuser(String filename, HttpServletResponse response);

	ArrayList<Aggregateinvoiceinfo> heldbackQueries();

	ArrayList<Aggregateinvoiceinfo> getVendorAmountMonthwise(int vendorCode,
			java.sql.Date startDate, java.sql.Date endDate);

	ArrayList<Aggregateinvoiceinfo> getVendorAmountHeldback(int vendorCode, Date startDate, Date endDate);

	ArrayList<Aggregateinvoiceinfo> getVendorAmountExceptional(int vendorCode, Date startDate, Date endDate);

	ArrayList<Aggregateinvoiceinfo> getVendorAmountAllInvoices(int vendorCode, Date startDate, Date endDate);

}
