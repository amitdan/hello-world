
package com.cybage.configuration;


import java.io.InputStream;

import org.apache.log4j.*;

/**
 * The Class LoggerClass.
 @author akashpuri
 */
public class LoggerClass {
		
		/** The logger. */
		public static Logger logger;
		
		/**
		 * Instantiates a new logger class.
		 */
		private LoggerClass(){
			logger=Logger.getLogger(LoggerClass.class);
			//PropertyConfigurator.configure(System.getProperty("user.dir")+"\\config\\log4j.properties");
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream("log4j.properties");
			PropertyConfigurator.configure(inputStream);
		}
		
		/**
		 * Gets the logger instance.
		 *
		 * @return the logger instance
		 */
		public static LoggerClass getLoggerInstance(){
			return new LoggerClass();
		}
	}
