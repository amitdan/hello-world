package com.cybage.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.ui.ModelMap;

import com.cybage.service.*;
public class PaymentProcessTest {
	PaymentProcess paymentProcess=new PaymentProcess();
	@Test
	public void testListofProcessed() {
		
		ModelMap model=new ModelMap();
		
		List plist=paymentProcess.listofProcessed(model);
		
		assertNotNull(plist);
	}
	@Test
	public void testListofInvoice() {
		ModelMap model=new ModelMap();
		String invoiceId="ERS-17180200326-8534";
		//List inlist=paymentProcess.listInvoice(invoiceId, model);
		
		//assertNotNull(inlist);
	}
}
