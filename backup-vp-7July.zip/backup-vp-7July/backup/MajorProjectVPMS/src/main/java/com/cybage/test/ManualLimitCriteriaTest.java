package com.cybage.test;

import static org.junit.Assert.*;

import org.junit.Test;
import com.cybage.service.*;
public class ManualLimitCriteriaTest {

	@Test
	public void testApplycriteria() {
		ManualLimitCriteria manualLimitCriteria=new ManualLimitCriteria();
		
		
		int maxLimit=2000;
		int vendorCode=200164;
		int paymentAmount=1000;
		
		//assertEquals(true,manualLimitCriteria.applyCriteria(maxLimit, vendorCode, paymentAmount));
	}

}