package com.cybage.service;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;

import java.util.Calendar;
import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
import javax.persistence.EntityManager;
import javax.persistence.TemporalType;
import org.springframework.web.servlet.ModelAndView;
import com.cybage.configuration.LoggerClass;
import com.cybage.dao.UserDAOImpl;
import com.cybage.model.Aggregateinvoiceinfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
public class Description {
	static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();

	public static ModelAndView getDescriptionApproved(String vendorCode,Date fromDate,Date toDate) {
		ModelAndView modelObject=new ModelAndView("description");
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<Aggregateinvoiceinfo> vendorList=new ArrayList<Aggregateinvoiceinfo>();	
		ArrayList<String> descriptionList=new ArrayList<String>();
		ArrayList<String> description=new ArrayList<String>();
		ArrayList<String> payment=new ArrayList<String>();
		String descriptionlist[];
		String paymentlist[];
		String name=null;
		double pay=0;
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))||(invoiceinfo.getPane().equals("Satisfied Exception Criteria"))||(invoiceinfo.getInvoiceStatus().equals("Heldback"))){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(invoiceinfo.getVendorCode()!=Integer.parseInt(vendorCode)){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for(int i=0;i<invoiceList.size();i++){
			 if(invoiceList.get(i).getVendorCode()==Integer.parseInt(vendorCode)){
				 vendorList.add(invoiceList.get(i));
				 name=invoiceList.get(i).getVendorName();
				 pay+=invoiceList.get(i).getPaymentAmount();
			 }
		 }
		 for(int i=0;i<vendorList.size();i++){
			 String descriptionArray=vendorList.get(i).getDescription();				 
			 descriptionlist=descriptionArray.split("[$$]");	
			 for(int j=0;j<descriptionlist.length;j+=2){				 
					 descriptionList.add(descriptionlist[j]);				
			 }
			 
		 }
		 for(int i=0;i<descriptionList.size();i++){
			 paymentlist=descriptionList.get(i).split("[|]");
			 
			 payment.add(paymentlist[0]);
			 description.add(paymentlist[1]);

		 }
		 
		 modelObject.addObject("vendorCode",vendorCode);
		 modelObject.addObject("fromDate",fromDate);
		 modelObject.addObject("toDate",toDate);
		 modelObject.addObject("name",name);
		 modelObject.addObject("pay",pay);
		modelObject.addObject("payment",payment);
	  	modelObject.addObject("description",description);
		return modelObject;
	}
	
	public static ModelAndView getDescriptionHeldback(String vendorCode, Date fromDate, Date toDate) {
		ModelAndView modelObject=new ModelAndView("description");
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<Aggregateinvoiceinfo> vendorList=new ArrayList<Aggregateinvoiceinfo>();	
		ArrayList<String> descriptionList=new ArrayList<String>();
		ArrayList<String> description=new ArrayList<String>();
		ArrayList<String> payment=new ArrayList<String>();
		String descriptionlist[];
		String paymentlist[];
		String name=null;
		double pay=0;
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))||(invoiceinfo.getPane().equals("Satisfied Exception Criteria"))||(invoiceinfo.getInvoiceStatus().equals("Approved"))){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(invoiceinfo.getVendorCode()!=Integer.parseInt(vendorCode)){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for(int i=0;i<invoiceList.size();i++){
			 if(invoiceList.get(i).getVendorCode()==Integer.parseInt(vendorCode)){
				 vendorList.add(invoiceList.get(i));
				 name=invoiceList.get(i).getVendorName();
				 pay+=invoiceList.get(i).getPaymentAmount();
			 }
		 }
		 for(int i=0;i<vendorList.size();i++){
			 String descriptionArray=vendorList.get(i).getDescription();				 
			 descriptionlist=descriptionArray.split("[$$]");	
			 for(int j=0;j<descriptionlist.length;j+=2){				 
					 descriptionList.add(descriptionlist[j]);				
			 }
			 
		 }
		 for(int i=0;i<descriptionList.size();i++){
			 paymentlist=descriptionList.get(i).split("[|]");
			 
			 payment.add(paymentlist[0]);
			 description.add(paymentlist[1]);

		 }
		 
		 modelObject.addObject("vendorCode",vendorCode);
		 modelObject.addObject("fromDate",fromDate);
		 modelObject.addObject("toDate",toDate);
		 modelObject.addObject("name",name);
		 modelObject.addObject("pay",pay);
		modelObject.addObject("payment",payment);
	  	modelObject.addObject("description",description);
		return modelObject;
	}
	
	public static ModelAndView getDescriptionAll(String vendorCode, Date fromDate, Date toDate) {
		ModelAndView modelObject=new ModelAndView("description");
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<Aggregateinvoiceinfo> vendorList=new ArrayList<Aggregateinvoiceinfo>();	
		ArrayList<String> descriptionList=new ArrayList<String>();
		ArrayList<String> description=new ArrayList<String>();
		ArrayList<String> payment=new ArrayList<String>();
		String descriptionlist[];
		String paymentlist[];
		String name=null;
		double pay=0;
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))||(invoiceinfo.getInvoiceStatus().equals("Heldback"))){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(invoiceinfo.getVendorCode()!=Integer.parseInt(vendorCode)){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for(int i=0;i<invoiceList.size();i++){
			 if(invoiceList.get(i).getVendorCode()==Integer.parseInt(vendorCode)){
				 vendorList.add(invoiceList.get(i));
				 name=invoiceList.get(i).getVendorName();
				 pay+=invoiceList.get(i).getPaymentAmount();
			 }
		 }
		 for(int i=0;i<vendorList.size();i++){
			 String descriptionArray=vendorList.get(i).getDescription();				 
			 descriptionlist=descriptionArray.split("[$$]");	
			 for(int j=0;j<descriptionlist.length;j+=2){				 
					 descriptionList.add(descriptionlist[j]);				
			 }
			 
		 }
		 for(int i=0;i<descriptionList.size();i++){
			 paymentlist=descriptionList.get(i).split("[|]");
			 
			 payment.add(paymentlist[0]);
			 description.add(paymentlist[1]);

		 }
		 
		 modelObject.addObject("vendorCode",vendorCode);
		 modelObject.addObject("fromDate",fromDate);
		 modelObject.addObject("toDate",toDate);
		 modelObject.addObject("name",name);
		 modelObject.addObject("pay",pay);
		modelObject.addObject("payment",payment);
	  	modelObject.addObject("description",description);
		return modelObject;
	}

	public static ModelAndView getDescriptionException(String vendorCode, Date fromDate, Date toDate) {
		ModelAndView modelObject=new ModelAndView("description");
		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<Aggregateinvoiceinfo> vendorList=new ArrayList<Aggregateinvoiceinfo>();	
		ArrayList<String> descriptionList=new ArrayList<String>();
		ArrayList<String> description=new ArrayList<String>();
		ArrayList<String> payment=new ArrayList<String>();
		String descriptionlist[];
		String paymentlist[];
		String name=null;
		double pay=0;
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(invoiceinfo.getVendorCode()!=Integer.parseInt(vendorCode)){
	  	 		 	iterator.remove();
	  	 	    }
			}
		 
		 for(int i=0;i<invoiceList.size();i++){
			 if(invoiceList.get(i).getVendorCode()==Integer.parseInt(vendorCode)){
				 vendorList.add(invoiceList.get(i));
				 name=invoiceList.get(i).getVendorName();
				 pay+=invoiceList.get(i).getPaymentAmount();
			 }
		 }
		 for(int i=0;i<vendorList.size();i++){
			 String descriptionArray=vendorList.get(i).getDescription();				 
			 descriptionlist=descriptionArray.split("[$$]");	
			 for(int j=0;j<descriptionlist.length;j+=2){				 
					 descriptionList.add(descriptionlist[j]);				
			 }
			 
		 }
		 for(int i=0;i<descriptionList.size();i++){
			 paymentlist=descriptionList.get(i).split("[|]");
			 
			 payment.add(paymentlist[0]);
			 description.add(paymentlist[1]);

		 }
		 
		 modelObject.addObject("vendorCode",vendorCode);
		 modelObject.addObject("fromDate",fromDate);
		 modelObject.addObject("toDate",toDate);
		 modelObject.addObject("name",name);
		 modelObject.addObject("pay",pay);
		modelObject.addObject("payment",payment);
	  	modelObject.addObject("description",description);
		return modelObject;
	}
	
	
	//for approved status history
	
	public static ModelAndView getHistory(String vendorCode) throws JsonProcessingException {
		ModelAndView modelObject=new ModelAndView("historicalData");
		ArrayList<String> historyList = new ArrayList<String>();
		ArrayList<String> historyListPeriod = new ArrayList<String>();
		Map<String, String> historyMap = VendorHistory.getVendorHistory(Integer.parseInt(vendorCode));
		for (Entry<String, String> entry : historyMap.entrySet()) {
			String[] splittingMonth = entry.getKey().split("/");
			historyListPeriod.add(HistoricalDataCriteria.getMonthName(splittingMonth[1]) + "-"
					+ splittingMonth[0]);
			historyList.add(entry.getValue());
		}
	
		ObjectMapper objectMapper = new ObjectMapper();
  	 	
		modelObject.addObject("vendorCode", vendorCode);
		modelObject.addObject("vendorHistoryPeriod", objectMapper.writeValueAsString(historyListPeriod));
		modelObject.addObject("vendorHistory",objectMapper.writeValueAsString( historyList));
		modelObject.addObject("vendorCode", vendorCode);
		modelObject.addObject("vendorHistoryPeriod1", historyListPeriod);
		modelObject.addObject("vendorHistory1", historyList);

		return modelObject;
	}
	
	//for heldback status history
	
	public static ModelAndView getHistoryForHeldback(String vendorCode) throws JsonProcessingException {
		ModelAndView modelObject=new ModelAndView("historicalData");
		ArrayList<String> historyList = new ArrayList<String>();
		ArrayList<String> historyListPeriod = new ArrayList<String>();
		Map<String, String> historyMap = getVendorHistoryHeldback(Integer.parseInt(vendorCode));
		for (Entry<String, String> entry : historyMap.entrySet()) {
			String[] splittingMonth = entry.getKey().split("/");
			historyListPeriod.add(HistoricalDataCriteria.getMonthName(splittingMonth[1]) + "-"
					+ splittingMonth[0]);
			historyList.add(entry.getValue());
		}
	
		ObjectMapper objectMapper = new ObjectMapper();
  	 	
		modelObject.addObject("vendorCode", vendorCode);
		modelObject.addObject("vendorHistoryPeriod", objectMapper.writeValueAsString(historyListPeriod));
		modelObject.addObject("vendorHistory",objectMapper.writeValueAsString( historyList));
		modelObject.addObject("vendorCode", vendorCode);
		modelObject.addObject("vendorHistoryPeriod1", historyListPeriod);
		modelObject.addObject("vendorHistory1", historyList);

		return modelObject;
	}
	//for heldback status history
	public static Map<String,String> getVendorHistoryHeldback(int vendorCode) {
		java.sql.Date datePreviousYear = null;
		Map<String, String> monthAmountMap = new TreeMap<String, String>(new MyDateComparator());
		try {
			Calendar cal = Calendar.getInstance();
			Date today = cal.getTime();
			int currentYear = cal.get(Calendar.YEAR);
			int currentMonth = today.getMonth()+1;
			loggerInstance.logger.info("Current month = "+currentMonth);
			loggerInstance.logger.info("Current Year = "+currentYear);
			cal.add(Calendar.YEAR, -1); // to get previous year add -1
			Date dateYearBack = cal.getTime();
			java.sql.Date dateToday = getSqlDate(getDateStringFormatted(today.toString()));
			datePreviousYear = getSqlDate(getDateStringFormatted(dateYearBack.toString()));
			loggerInstance.logger.info(dateToday + " " + datePreviousYear);
			UserDAOImpl object = new UserDAOImpl();
			List<Aggregateinvoiceinfo> list = object.getVendorAmountHeldback(vendorCode, dateToday, datePreviousYear);
			loggerInstance.logger.info("Monthwise result size "+list.size());
			
			if (list.isEmpty()) {
					monthAmountMap.put("NEW VENDOR/00", "00");
			} else {
				for (int i = 0; i < list.size(); i++) {
					Aggregateinvoiceinfo o = list.get(i);
					double amount = o.getPaymentAmount();
					int monthNumber = o.getInvoiceDate().getMonth() + 1;
					int year = o.getInvoiceDate().getYear()+1900;
						if (monthAmountMap.containsKey(year+"/"+monthNumber)) {
							loggerInstance.logger.info(monthAmountMap.toString());
							double amountInMap = Double.parseDouble(monthAmountMap.get(year+"/"+monthNumber));
							amountInMap=amountInMap+amount;
							monthAmountMap.put(year+"/"+monthNumber, String.valueOf(amountInMap));
							}
						else{
							loggerInstance.logger.info("NEW AMOUNT ADDED"+amount);
							monthAmountMap.put((year)+"/"+(monthNumber), String.valueOf(amount));
						}
					}
				for (int index = currentMonth-1; index >0; index--) {
					if (!monthAmountMap.containsKey(currentYear+"/"+index)) {
						monthAmountMap.put((currentYear)+"/"+(index), "00");
					}
				}
				for (int index = currentMonth; index <= 12; index++) {
					if (!monthAmountMap.containsKey(currentYear-1+"/"+index)) {
						monthAmountMap.put((currentYear-1)+"/"+(index),"00");	
					}
				}
			}
			loggerInstance.logger.info(monthAmountMap.toString());
		}

		catch (Exception e) {
			loggerInstance.logger.error(e);
		}
				
		return monthAmountMap;
	}
	
	
	//for Exceptional Criteria history
	
		public static ModelAndView getHistoryForExceptional(String vendorCode) throws JsonProcessingException {
			ModelAndView modelObject=new ModelAndView("historicalData");
			ArrayList<String> historyList = new ArrayList<String>();
			ArrayList<String> historyListPeriod = new ArrayList<String>();
			Map<String, String> historyMap = getVendorHistoryExceptional(Integer.parseInt(vendorCode));
			for (Entry<String, String> entry : historyMap.entrySet()) {
				String[] splittingMonth = entry.getKey().split("/");
				historyListPeriod.add(HistoricalDataCriteria.getMonthName(splittingMonth[1]) + "-"
						+ splittingMonth[0]);
				historyList.add(entry.getValue());
			}
		
			ObjectMapper objectMapper = new ObjectMapper();
	  	 	
			modelObject.addObject("vendorCode", vendorCode);
			modelObject.addObject("vendorHistoryPeriod", objectMapper.writeValueAsString(historyListPeriod));
			modelObject.addObject("vendorHistory",objectMapper.writeValueAsString( historyList));
			modelObject.addObject("vendorCode", vendorCode);
			modelObject.addObject("vendorHistoryPeriod1", historyListPeriod);
			modelObject.addObject("vendorHistory1", historyList);

			return modelObject;
		}
		//for Exceptional status history
		public static Map<String,String> getVendorHistoryExceptional(int vendorCode) {
			java.sql.Date datePreviousYear = null;
			Map<String, String> monthAmountMap = new TreeMap<String, String>(new MyDateComparator());
			try {
				Calendar cal = Calendar.getInstance();
				Date today = cal.getTime();
				int currentYear = cal.get(Calendar.YEAR);
				int currentMonth = today.getMonth()+1;
				loggerInstance.logger.info("Current month = "+currentMonth);
				loggerInstance.logger.info("Current Year = "+currentYear);
				cal.add(Calendar.YEAR, -1); // to get previous year add -1
				Date dateYearBack = cal.getTime();
				java.sql.Date dateToday = getSqlDate(getDateStringFormatted(today.toString()));
				datePreviousYear = getSqlDate(getDateStringFormatted(dateYearBack.toString()));
				loggerInstance.logger.info(dateToday + " " + datePreviousYear);
				UserDAOImpl object = new UserDAOImpl();
				List<Aggregateinvoiceinfo> list = object.getVendorAmountExceptional(vendorCode, dateToday, datePreviousYear);
				loggerInstance.logger.info("Monthwise result size "+list.size());
				
				if (list.isEmpty()) {
						monthAmountMap.put("NEW VENDOR/00", "00");
				} else {
					for (int i = 0; i < list.size(); i++) {
						Aggregateinvoiceinfo o = list.get(i);
						double amount = o.getPaymentAmount();
						int monthNumber = o.getInvoiceDate().getMonth() + 1;
						int year = o.getInvoiceDate().getYear()+1900;
							if (monthAmountMap.containsKey(year+"/"+monthNumber)) {
								loggerInstance.logger.info(monthAmountMap.toString());
								double amountInMap = Double.parseDouble(monthAmountMap.get(year+"/"+monthNumber));
								amountInMap=amountInMap+amount;
								monthAmountMap.put(year+"/"+monthNumber, String.valueOf(amountInMap));
								}
							else{
								loggerInstance.logger.info("NEW AMOUNT ADDED"+amount);
								monthAmountMap.put((year)+"/"+(monthNumber), String.valueOf(amount));
							}
						}
					for (int index = currentMonth-1; index >0; index--) {
						if (!monthAmountMap.containsKey(currentYear+"/"+index)) {
							monthAmountMap.put((currentYear)+"/"+(index), "00");
						}
					}
					for (int index = currentMonth; index <= 12; index++) {
						if (!monthAmountMap.containsKey(currentYear-1+"/"+index)) {
							monthAmountMap.put((currentYear-1)+"/"+(index),"00");	
						}
					}
				}
				loggerInstance.logger.info(monthAmountMap.toString());
			}

			catch (Exception e) {
				loggerInstance.logger.error(e);
			}
					
			return monthAmountMap;
		}
		
		
		
		//for All report Criteria history
		
			public static ModelAndView getHistoryForAllInvoices(String vendorCode) throws JsonProcessingException {
				ModelAndView modelObject=new ModelAndView("historicalData");
				ArrayList<String> historyList = new ArrayList<String>();
				ArrayList<String> historyListPeriod = new ArrayList<String>();
				Map<String, String> historyMap = getVendorHistoryAllInvoices(Integer.parseInt(vendorCode));
				for (Entry<String, String> entry : historyMap.entrySet()) {
					String[] splittingMonth = entry.getKey().split("/");
					historyListPeriod.add(HistoricalDataCriteria.getMonthName(splittingMonth[1]) + "-"
							+ splittingMonth[0]);
					historyList.add(entry.getValue());
				}
			
				ObjectMapper objectMapper = new ObjectMapper();
		  	 	
				modelObject.addObject("vendorCode", vendorCode);
				modelObject.addObject("vendorHistoryPeriod", objectMapper.writeValueAsString(historyListPeriod));
				modelObject.addObject("vendorHistory",objectMapper.writeValueAsString( historyList));
				modelObject.addObject("vendorCode", vendorCode);
				modelObject.addObject("vendorHistoryPeriod1", historyListPeriod);
				modelObject.addObject("vendorHistory1", historyList);

				return modelObject;
			}
			//for all report(approved) history
			public static Map<String,String> getVendorHistoryAllInvoices(int vendorCode) {
				java.sql.Date datePreviousYear = null;
				Map<String, String> monthAmountMap = new TreeMap<String, String>(new MyDateComparator());
				try {
					Calendar cal = Calendar.getInstance();
					Date today = cal.getTime();
					int currentYear = cal.get(Calendar.YEAR);
					int currentMonth = today.getMonth()+1;
					loggerInstance.logger.info("Current month = "+currentMonth);
					loggerInstance.logger.info("Current Year = "+currentYear);
					cal.add(Calendar.YEAR, -1); // to get previous year add -1
					Date dateYearBack = cal.getTime();
					java.sql.Date dateToday = getSqlDate(getDateStringFormatted(today.toString()));
					datePreviousYear = getSqlDate(getDateStringFormatted(dateYearBack.toString()));
					loggerInstance.logger.info(dateToday + " " + datePreviousYear);
					UserDAOImpl object = new UserDAOImpl();
					List<Aggregateinvoiceinfo> list = object.getVendorAmountAllInvoices(vendorCode, dateToday, datePreviousYear);
					loggerInstance.logger.info("Monthwise result size "+list.size());
					
					if (list.isEmpty()) {
							monthAmountMap.put("NEW VENDOR/00", "00");
					} else {
						for (int i = 0; i < list.size(); i++) {
							Aggregateinvoiceinfo o = list.get(i);
							double amount = o.getPaymentAmount();
							int monthNumber = o.getInvoiceDate().getMonth() + 1;
							int year = o.getInvoiceDate().getYear()+1900;
								if (monthAmountMap.containsKey(year+"/"+monthNumber)) {
									loggerInstance.logger.info(monthAmountMap.toString());
									double amountInMap = Double.parseDouble(monthAmountMap.get(year+"/"+monthNumber));
									amountInMap=amountInMap+amount;
									monthAmountMap.put(year+"/"+monthNumber, String.valueOf(amountInMap));
									}
								else{
									loggerInstance.logger.info("NEW AMOUNT ADDED"+amount);
									monthAmountMap.put((year)+"/"+(monthNumber), String.valueOf(amount));
								}
							}
						for (int index = currentMonth-1; index >0; index--) {
							if (!monthAmountMap.containsKey(currentYear+"/"+index)) {
								monthAmountMap.put((currentYear)+"/"+(index), "00");
							}
						}
						for (int index = currentMonth; index <= 12; index++) {
							if (!monthAmountMap.containsKey(currentYear-1+"/"+index)) {
								monthAmountMap.put((currentYear-1)+"/"+(index),"00");	
							}
						}
					}
					loggerInstance.logger.info(monthAmountMap.toString());
				}

				catch (Exception e) {
					loggerInstance.logger.error(e);
				}
						
				return monthAmountMap;
			}
	
	//common function to all
	
	public static String getDateStringFormatted(String inputDate) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.US);
		Date date = (Date) formatter.parse(inputDate);
		loggerInstance.logger.info(date);

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		String formatedDate = cal.get(Calendar.DATE) + "/" + (cal.get(Calendar.MONTH) + 1) + "/"
				+ cal.get(Calendar.YEAR);
		loggerInstance.logger.info("formatedDate : " + formatedDate);
		return formatedDate;
	}
	public static java.sql.Date getSqlDate(String startDate) {
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date date;
		java.sql.Date sqlDate = null;
		try {
			date = sdf1.parse(startDate);
			sqlDate = new java.sql.Date(date.getTime());

		} catch (ParseException e) {
			loggerInstance.logger.error("Exception in invoice date parsing" + e);
		}
		return sqlDate;
	}
	

}