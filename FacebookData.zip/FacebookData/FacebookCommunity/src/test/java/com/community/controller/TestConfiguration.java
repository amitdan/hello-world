package com.community.controller;


import org.junit.Test;

import com.community.configuration.DatabaseConfiguration;

public class TestConfiguration {

	@Test
	public void test() {
		DatabaseConfiguration.getEntityManager();
	}
}
