package com.community.service;

import javax.persistence.EntityManager;

import com.community.configuration.DatabaseConfiguration;
import com.community.configuration.LoggerClass;
import com.community.model.Question;

public class QuestionServices {
	
public static boolean addNewQuestion(Question question){
	boolean result=false;
	try{
		EntityManager entityManager = DatabaseConfiguration.getEntityManager();
		LoggerClass.logger.info("Created Entity Manager");
		entityManager.getTransaction().begin();
		LoggerClass.logger.info("Started Transaction");
		entityManager.persist(question);
		LoggerClass.logger.info("Persisted Question");
		entityManager.getTransaction().commit();
		LoggerClass.logger.info("Transaction Commited");
		entityManager.close();
		LoggerClass.logger.info("Closed Entity Manager");
		result=true;
		LoggerClass.logger.info("Question Saved Successfully");
	}
	catch(Exception e){
		LoggerClass.logger.error(e);
	}
	return result;
}
}