package com.community.service;

import javax.persistence.EntityManager;

import com.community.configuration.DatabaseConfiguration;
import com.community.configuration.LoggerClass;
import com.community.model.Answer;

public class AnswerServices {
	public static boolean addNewAnswer(Answer answer){
		boolean result=false;
		try{
			EntityManager entityManager = DatabaseConfiguration.getEntityManager();
			LoggerClass.logger.info("Created Entity Manager");
			entityManager.getTransaction().begin();
			LoggerClass.logger.info("Started Transaction");
			entityManager.persist(answer);
			LoggerClass.logger.info("Persisted Answer");
			entityManager.getTransaction().commit();
			LoggerClass.logger.info("Transaction Commited");
			entityManager.close();
			LoggerClass.logger.info("Closed Entity Manager");
			result=true;
			LoggerClass.logger.info("Answer Saved Successfully");
		}
		catch(Exception e){
			LoggerClass.logger.error(e);
		}
		return result;
	}
}
