package com.community.services;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.community.configuration.DatabaseConfiguration;
import com.community.configuration.LoggerClass;
import com.community.model.Answer;
import com.community.model.Question;

public class AnswerServices {
	public static boolean addNewAnswer(Answer answer){
		boolean result=false;
		try{
			EntityManager entityManager = DatabaseConfiguration.getEntityManager();
			LoggerClass.logger.info("Created Entity Manager");
			entityManager.getTransaction().begin();
			LoggerClass.logger.info("Started Transaction");
			entityManager.persist(answer);
			LoggerClass.logger.info("Persisted Answer");
			entityManager.getTransaction().commit();
			LoggerClass.logger.info("Transaction Commited");
			entityManager.close();
			LoggerClass.logger.info("Closed Entity Manager");
			result=true;
			LoggerClass.logger.info("Answer Saved Successfully");
		}
		catch(Exception e){
			LoggerClass.logger.error(e);
		}
		return result;
	}

	public static ArrayList<Answer> getAnswers(int questionId) {
		EntityManager entityManager = DatabaseConfiguration.getEntityManager();
		Query query = entityManager.createQuery("Select answer from Answer answer where answer.questionid="+questionId);
		ArrayList<Answer> answerList = (ArrayList<Answer>) query.getResultList();
		LoggerClass.logger.info("Answer list size = "+answerList.size());
		return answerList;
	}
}
