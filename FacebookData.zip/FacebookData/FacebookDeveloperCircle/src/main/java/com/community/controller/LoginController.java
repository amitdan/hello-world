package com.community.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.community.configuration.DatabaseConfiguration;
import com.community.model.Answer;
import com.community.services.AnswerServices;

/**
 * Handles requests for the application home page.
 */
@Controller
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String login(Locale locale, Model model,HttpServletRequest request) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		logger.info(request.getParameter("username"));
		model.addAttribute("serverTime", formattedDate );
		DatabaseConfiguration.getEntityManager();
		return "userHome";
	}
	
	@RequestMapping(value = "joinUs", method = RequestMethod.POST)
	public String joinUs(Locale locale, Model model,HttpServletRequest request) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		logger.info(request.getParameter("username"));
		logger.info(request.getParameter("email"));
		logger.info(request.getParameter("password"));
		model.addAttribute("serverTime", formattedDate );
		
		return "userHome";
	}
	
	@RequestMapping(value="answersOfQuestion",method=RequestMethod.GET,params = {"id","question"})
	public String answersForQuestion(@RequestParam("id") String id,@RequestParam("question") String question,Model model){
	int questionId = Integer.parseInt(id);
	logger.info("Question ID = "+questionId);
	logger.info("Question Statement = "+question);
	ArrayList<Answer> answerList = AnswerServices.getAnswers(questionId);
	model.addAttribute("answerList",answerList);
	model.addAttribute("question",question);
	return "answers";
	}	
}