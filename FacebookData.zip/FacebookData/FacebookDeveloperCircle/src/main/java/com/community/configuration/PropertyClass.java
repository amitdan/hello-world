/*
 * 
 */
package com.community.configuration;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * The Class PropertyClass.
@author akashpuri
 */
public class PropertyClass {
	
	/** The prop. */
	Properties prop = new Properties();
	
	/** The input reader. */
	InputStream inputReader = null;
	
	/** The logger instance. */
	LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	
	/**
	 * Instantiates a new property class.
	 */
	public PropertyClass() {
		try {
			System.out.println("#################"+System.getProperty("user.dir"));
			inputReader = new FileInputStream(System.getProperty("user.dir")+"\\config\\ApplicationProperties.properties");
			prop.load(inputReader);
			
		} catch (IOException e) {
			 loggerInstance.logger.error(e);
		}
	}
	
	/**
	 * Gets the database username.
	 *
	 * @return the database username
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getDatabaseUsername() throws IOException{
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("databaseUsername");
			inputReader.close();
		}
		loggerInstance.logger.debug("Username = "+result);
		return result;
	}
	
	/**
	 * Gets the database driver.
	 *
	 * @return the database driver
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getDatabaseDriver() throws IOException{
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("databaseDriver");
			inputReader.close();

		}
		loggerInstance.logger.debug("Driver = "+result);
		return result;
	}
	
	/**
	 * Gets the database connection URL.
	 *
	 * @return the database connection URL
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getDatabaseConnectionURL() throws IOException{
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("databaseConnectionURL");
			inputReader.close();

		}
		loggerInstance.logger.debug("Connection URL = "+result);
		return result;
	}
	
	/**
	 * Gets the hibernate connection.
	 *
	 * @return the hibernate connection
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHibernateConnection() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("hibernateConnection");
			inputReader.close();

		}
		loggerInstance.logger.debug("hibernateConnection = "+result);
		return result;
	}
	
	/**
	 * Gets the hibernate driver class.
	 *
	 * @return the hibernate driver class
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHibernateDriverClass() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("hibernateDriverClass");
			inputReader.close();
		}
		loggerInstance.logger.debug("hibernateDriverClass = "+result);
		return result;
	}
	
	/**
	 * Gets the hibernate username.
	 *
	 * @return the hibernate username
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHibernateUsername() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("hibernateUsername");
			inputReader.close();

		}
		loggerInstance.logger.debug("hibernateUsername = "+result);
		return result;
	}
	
	/**
	 * Gets the hibernate password.
	 *
	 * @return the hibernate password
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHibernatePassword() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("hibernatePassword");
			inputReader.close();

		}
		loggerInstance.logger.info("hibernatePassword"+result);
		return result;
	}
	
	/**
	 * Gets the database password.
	 *
	 * @return the database password
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getDatabasePassword() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("databasePassword");
			inputReader.close();

		}
		return result;
	}
	
	/**
	 * Gets the database autodetect.
	 *
	 * @return the database autodetect
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getDatabaseAutodetect() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("databaseAutodetect");
			inputReader.close();

		}
		loggerInstance.logger.debug("databaseAutodetect = "+result);
		return result;
	}
	
	/**
	 * Gets the hibernate autodetect.
	 *
	 * @return the hibernate autodetect
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHibernateAutodetect() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("hibernateAutodetect");
			inputReader.close();

		}
		loggerInstance.logger.debug("hibernateAutodetect = "+result);
		return result;
	}
	
	/**
	 * Gets the database show sql.
	 *
	 * @return the database show sql
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getDatabaseShowSql() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("databaseShowSql");
			inputReader.close();

		}
		loggerInstance.logger.debug("databaseShowSql = "+result);
		return result;
	}
	
	/**
	 * Gets the hibernate show sql.
	 *
	 * @return the hibernate show sql
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHibernateShowSql() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("hibernateShowSql");
			inputReader.close();

		}
		loggerInstance.logger.debug("hibernateShowSql = "+result);
		return result;
	}
	
	/**
	 * Gets the hibernate format sql.
	 *
	 * @return the hibernate format sql
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHibernateFormatSql() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("hibernateFormatSql");
			inputReader.close();

		}
		loggerInstance.logger.debug("hibernateFormatSql = "+result);
		return result;
	}
	
	/**
	 * Gets the database format sql.
	 *
	 * @return the database format sql
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getDatabaseFormatSql() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("databaseFormatSql");
			inputReader.close();

		}
		loggerInstance.logger.debug("databaseFormatSql = "+result);
		return result;
	}
	
	/**
	 * Gets the batch size.
	 *
	 * @return the batch size
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public int getBatchSize() throws IOException {
		int result = 0;
		if(inputReader!=null){
			result = Integer.parseInt(prop.getProperty("batchSize"));
			inputReader.close();
		}
		loggerInstance.logger.debug("batch size = "+result);
		return result;
	}
	
	/**
	 * Gets the approved subject.
	 *
	 * @return the approved subject
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getApprovedSubject() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("RequestApprovedSubject");
			inputReader.close();

		}
		loggerInstance.logger.debug("RequestApprovedSubject = "+result);
		return result;
	}
	
	/**
	 * Gets the heldback subject.
	 *
	 * @return the heldback subject
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String getHeldbackSubject() throws IOException {
		String result = null;
		if(inputReader!=null){
			result = prop.getProperty("RequestHeldbackSubject");
			inputReader.close();
		}
		loggerInstance.logger.debug("RequestHeldbackSubject = "+result);
		return result;
	}
	
}
