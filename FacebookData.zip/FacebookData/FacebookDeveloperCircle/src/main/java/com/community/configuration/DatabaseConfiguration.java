package com.community.configuration;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.community.configuration.LoggerClass;
import com.community.configuration.PropertyClass;

public class DatabaseConfiguration {

	/** The property. */
	static PropertyClass property;
	
	/** The logger instance. */
	static LoggerClass loggerInstance;
	
	static Map<String,String> jpaProperties = new HashMap<String, String>();
	static{
		property = new PropertyClass();
		loggerInstance = LoggerClass.getLoggerInstance();
		try {
			loggerInstance.logger.info(property.getDatabasePassword());
			jpaProperties.put(property.getHibernateConnection(),
					property.getDatabaseConnectionURL());
			jpaProperties.put(property.getHibernateDriverClass(),
					property.getDatabaseDriver());
			jpaProperties.put(property.getHibernateUsername(),
					property.getDatabaseUsername());
			jpaProperties.put(property.getHibernatePassword(),
					property.getDatabasePassword());
			jpaProperties.put(property.getHibernateAutodetect(),
					property.getDatabaseAutodetect());
			jpaProperties.put(property.getHibernateShowSql(),
					property.getDatabaseShowSql());
			jpaProperties.put(property.getHibernateFormatSql(),
					property.getDatabaseFormatSql());
			jpaProperties.put("hbm2ddl.auto", "update");
			jpaProperties.put("connection.release_mode", "auto");
		} catch (IOException e) {
			loggerInstance.logger.error(e);
		}
	}
	
	private static EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("FacebookDeveloperCircle",jpaProperties);
	public static EntityManager getEntityManager() {
		EntityManager entityManager=emFactory.createEntityManager();
		return entityManager;
	}
}
