{
	"body": {
		"version": "1.0",
		"response": {
			"outputSpeech": {
				"type": "SSML",
				"ssml": "<speak>Hang on, here is vaccine schedule as per your request  </speak>"
			},
			"card": {
				"type": "Simple",
				"title": "Amit's Vaccine Schedule",
				"content": "<break time='1s'/>1 <break time='1s'/>: DTaP-HB-IPV-Hib\n<break time='1s'/>2 <break time='1s'/>: Pneumococcal Conjugate\n<break time='1s'/>3 <break time='1s'/>: Rotavirus\n<break time='1s'/>4 <break time='1s'/>: Meningococcal C Conjugate\n  and its recommended to take within  two  months. Do you want to set reminder ? "
			},
			"directives": [
				{
					"type": "Display.RenderTemplate",
					"template": {
						"type": "BodyTemplate3",
						"token": "ItemDetailsView",
						"image": {
							"sources": [
								{
									"url": "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/720x400/CA._TTH_.png",
									"size": "SMALL",
									"widthPixels": 0,
									"heightPixels": 0
								},
								{
									"url": "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/1200x800/CA._TTH_.png",
									"size": "LARGE",
									"widthPixels": 0,
									"heightPixels": 0
								}
							]
						},
						"title": "Amit's Vaccine Schedule",
						"textContent": {
							"primaryText": {
								"type": "RichText",
								"text": "<font size = '5'><break time='1s'/>1 <break time='1s'/>: DTaP-HB-IPV-Hib\n<break time='1s'/>2 <break time='1s'/>: Pneumococcal Conjugate\n<break time='1s'/>3 <break time='1s'/>: Rotavirus\n<break time='1s'/>4 <break time='1s'/>: Meningococcal C Conjugate\n  and its recommended to take within  two  months. Do you want to set reminder ? </font>"
							}
						},
						"backButton": "HIDDEN"
					}
				}
			],
			"reprompt": {
				"outputSpeech": {
					"type": "SSML",
					"ssml": "<speak>What other help do you want ?</speak>"
				}
			},
			"shouldEndSession": false
		},
		"sessionAttributes": {
			"STATE": "_START"
		}
	}
}



//
{
    "interactionModel": {
        "languageModel": {
            "invocationName": "vaccine buddy",
            "intents": [
                {
                    "name": "AMAZON.CancelIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.HelpIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.StopIntent",
                    "samples": []
                },
                {
                    "name": "CreateScheduleIntent",
                    "slots": [
                        {
                            "name": "nameOfKid",
                            "type": "AMAZON.US_FIRST_NAME"
                        }
                    ],
                    "samples": [
                        "create schedule for {nameOfKid}",
                        "new vaccine schedule please",
                        "want to create new schedule",
                        "add new schedule",
                        "new schedule",
                        "new schedule please",
                        "please create schedule"
                    ]
                },
                {
                    "name": "ShowScheduleIntent",
                    "slots": [
                        {
                            "name": "duration",
                            "type": "AMAZON.DURATION"
                        },
                        {
                            "name": "nameOfKid",
                            "type": "AMAZON.US_FIRST_NAME"
                        }
                    ],
                    "samples": [
                        "tell me upcoming vaccine schedule ",
                        "{nameOfKid} vaccine schedule please ",
                        "show vaccine schedule of {nameOfKid}",
                        "Please show vaccine schedule of this {duration}",
                        "show vaccine schedule please",
                        "show vaccine schedule",
                        "Please show vaccine schedule"
                    ]
                },
                {
                    "name": "UpdateScheduleIntent",
                    "slots": [
                        {
                            "name": "nameOfKid",
                            "type": "AMAZON.US_FIRST_NAME"
                        },
                        {
                            "name": "duration",
                            "type": "AMAZON.DURATION"
                        }
                    ],
                    "samples": [
                        "please change schedule of this {duration}",
                        "update schedule of {nameOfKid}",
                        "please update schedule of {nameOfKid} ",
                        "please update schedule",
                        "Please update vaccination schedule"
                    ]
                },
                {
                    "name": "AnswerIntent",
                    "slots": [
                        {
                            "name": "yesNo",
                            "type": "AMAZON.US_FIRST_NAME"
                        }
                    ],
                    "samples": [
                        "please {yesNo}",
                        "{yesNo}",
                        "{yesNo} please"
                    ]
                },
                {
                    "name": "AMAZON.MoreIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.NavigateHomeIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.NavigateSettingsIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.NextIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.PageUpIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.PageDownIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.PreviousIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.ScrollRightIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.ScrollDownIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.ScrollLeftIntent",
                    "samples": []
                },
                {
                    "name": "AMAZON.ScrollUpIntent",
                    "samples": []
                }
            ],
            "types": []
        },
        "dialog": {
            "intents": [
                {
                    "name": "UpdateScheduleIntent",
                    "confirmationRequired": true,
                    "prompts": {
                        "confirmation": "Confirm.Intent.873612674141"
                    },
                    "slots": [
                        {
                            "name": "nameOfKid",
                            "type": "AMAZON.US_FIRST_NAME",
                            "confirmationRequired": false,
                            "elicitationRequired": false,
                            "prompts": {}
                        },
                        {
                            "name": "duration",
                            "type": "AMAZON.DURATION",
                            "confirmationRequired": false,
                            "elicitationRequired": false,
                            "prompts": {}
                        }
                    ]
                }
            ]
        },
        "prompts": [
            {
                "id": "Confirm.Intent.873612674141",
                "variations": [
                    {
                        "type": "PlainText",
                        "value": "Do you want to continue ?"
                    },
                    {
                        "type": "PlainText",
                        "value": "You want to update schedule of {nameOfKid} of this {duration} , please say yes to continue and no to ignore "
                    }
                ]
            }
        ]
    }
}
//

Hi Team,

Please use below phrase to test my skil:

Alexa ask vaccine buddy to create new schedule for Jemmy
Alexa start vaccine buddy
Alexa ask vaccine buddy to show vaccine schedule 
Create new schedule for Jemmy
Show vaccine schedule

Thanks,
Amit 

 
//

/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';

const Alexa = require('alexa-sdk');

const APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

const languageStrings = {
    'en': {
        translation: {
            FACTS: [
                'A year on Mercury is just 88 days long.',
                'Despite being farther from the Sun, Venus experiences higher temperatures than Mercury.',
                'Venus rotates anti-clockwise, possibly because of a collision in the past with an asteroid.',
                'On Mars, the Sun appears about half the size as it does on Earth.',
                'Earth is the only planet not named after a god.',
                'Jupiter has the shortest day of all the planets.',
                'The Milky Way galaxy will collide with the Andromeda Galaxy in about 5 billion years.',
                'The Sun contains 99.86% of the mass in the Solar System.',
                'The Sun is an almost perfect sphere.',
                'A total solar eclipse can happen once every 1 to 2 years. This makes them a rare event.',
                'Saturn radiates two and a half times more energy into space than it receives from the sun.',
                'The temperature inside the Sun can reach 15 million degrees Celsius.',
                'The Moon is moving approximately 3.8 cm away from our planet every year.',
            ],
            SKILL_NAME: 'Space Facts',
            GET_FACT_MESSAGE: "Here's your fact: ",
            HELP_MESSAGE: 'You can say tell me a space fact, or, you can say exit... What can I help you with?',
            HELP_REPROMPT: 'What can I help you with?',
            STOP_MESSAGE: 'Goodbye!',
        },
    },
    'en-US': {
        translation: {
            FACTS: [
                'A year on Mercury is just 88 days long.',
                'Despite being farther from the Sun, Venus experiences higher temperatures than Mercury.',
                'Venus rotates counter-clockwise, possibly because of a collision in the past with an asteroid.',
                'On Mars, the Sun appears about half the size as it does on Earth.',
                'Earth is the only planet not named after a god.',
                'Jupiter has the shortest day of all the planets.',
                'The Milky Way galaxy will collide with the Andromeda Galaxy in about 5 billion years.',
                'The Sun contains 99.86% of the mass in the Solar System.',
                'The Sun is an almost perfect sphere.',
                'A total solar eclipse can happen once every 1 to 2 years. This makes them a rare event.',
                'Saturn radiates two and a half times more energy into space than it receives from the sun.',
                'The temperature inside the Sun can reach 15 million degrees Celsius.',
                'The Moon is moving approximately 3.8 cm away from our planet every year.',
            ],
            SKILL_NAME: 'American Space Facts',
        },
    },
    'en-GB': {
        translation: {
            FACTS: [
                'A year on Mercury is just 88 days long.',
                'Despite being farther from the Sun, Venus experiences higher temperatures than Mercury.',
                'Venus rotates anti-clockwise, possibly because of a collision in the past with an asteroid.',
                'On Mars, the Sun appears about half the size as it does on Earth.',
                'Earth is the only planet not named after a god.',
                'Jupiter has the shortest day of all the planets.',
                'The Milky Way galaxy will collide with the Andromeda Galaxy in about 5 billion years.',
                'The Sun contains 99.86% of the mass in the Solar System.',
                'The Sun is an almost perfect sphere.',
                'A total solar eclipse can happen once every 1 to 2 years. This makes them a rare event.',
                'Saturn radiates two and a half times more energy into space than it receives from the sun.',
                'The temperature inside the Sun can reach 15 million degrees Celsius.',
                'The Moon is moving approximately 3.8 cm away from our planet every year.',
            ],
            SKILL_NAME: 'British Space Facts',
        },
    },
    'de': {
        translation: {
            FACTS: [
                'Ein Jahr dauert auf dem Merkur nur 88 Tage.',
                'Die Venus ist zwar weiter von der Sonne entfernt, hat aber h�here Temperaturen als Merkur.',
                'Venus dreht sich entgegen dem Uhrzeigersinn, m�glicherweise aufgrund eines fr�heren Zusammensto�es mit einem Asteroiden.',
                'Auf dem Mars erscheint die Sonne nur halb so gro� wie auf der Erde.',
                'Die Erde ist der einzige Planet, der nicht nach einem Gott benannt ist.',
                'Jupiter hat den k�rzesten Tag aller Planeten.',
                'Die Milchstra�engalaxis wird in etwa 5 Milliarden Jahren mit der Andromeda-Galaxis zusammensto�en.',
                'Die Sonne macht rund 99,86 % der Masse im Sonnensystem aus.',
                'Die Sonne ist eine fast perfekte Kugel.',
                'Eine Sonnenfinsternis kann alle ein bis zwei Jahre eintreten. Sie ist daher ein seltenes Ereignis.',
                'Der Saturn strahlt zweieinhalb mal mehr Energie in den Weltraum aus als er von der Sonne erh�lt.',
                'Die Temperatur in der Sonne kann 15 Millionen Grad Celsius erreichen.',
                'Der Mond entfernt sich von unserem Planeten etwa 3,8 cm pro Jahr.',
            ],
            SKILL_NAME: 'Weltraumwissen auf Deutsch',
            GET_FACT_MESSAGE: 'Hier sind deine Fakten: ',
            HELP_MESSAGE: 'Du kannst sagen, �Nenne mir einen Fakt �ber den Weltraum�, oder du kannst �Beenden� sagen... Wie kann ich dir helfen?',
            HELP_REPROMPT: 'Wie kann ich dir helfen?',
            STOP_MESSAGE: 'Auf Wiedersehen!',
        },
    },
};

const handlers = {
    'LaunchRequest': function () {
        this.emit('GetFact');
    },
    'GetNewFactIntent': function () {
        this.emit('GetFact');
    },
    'GetFact': function () {
        // Get a random space fact from the space facts list
        // Use this.t() to get corresponding language data
        const factArr = this.t('FACTS');
        const factIndex = Math.floor(Math.random() * factArr.length);
        const randomFact = factArr[factIndex];

        // Create speech output
        var speechOutput = this.t('GET_FACT_MESSAGE') + randomFact;

        //check to see if the device we're working with supports display directives
        //enable the simulator if you're testing
        if(supportsDisplay.call(this)||isSimulator.call(this)) {
          console.log("has display:"+ supportsDisplay.call(this));
          console.log("is simulator:"+isSimulator.call(this));
          var content = {
             "hasDisplaySpeechOutput" : speechOutput,
             "hasDisplayRepromptText" : randomFact,
             "simpleCardTitle" : this.t('SKILL_NAME'),
             "simpleCardContent" : randomFact,
             "bodyTemplateTitle" : this.t('GET_FACT_MESSAGE'),
             "bodyTemplateContent" : randomFact,
             "templateToken" : "factBodyTemplate",
             "askOrTell" : ":tell",
             "sessionAttributes": {}
          };
          renderTemplate.call(this, content);
        } else {
        // Just use a card if the device doesn't support a card.
          this.response.cardRenderer(this.t('SKILL_NAME'), randomFact);
          this.response.speak(speechOutput);
          this.emit(':responseReady');
        }
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = this.t('HELP_MESSAGE');
        const reprompt = this.t('HELP_MESSAGE');
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        const reprompt = this.t('STOP_MESSAGE');
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(this.t('STOP_MESSAGE'));
        this.emit(':responseReady');
    },
};

exports.handler = function (event, context) {
    const alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};


//==============================================================================
//=========================== Helper Functions  ================================
//==============================================================================

function supportsDisplay() {
  var hasDisplay =
    this.event.context &&
    this.event.context.System &&
    this.event.context.System.device &&
    this.event.context.System.device.supportedInterfaces &&
    this.event.context.System.device.supportedInterfaces.Display

  return hasDisplay;
}

function isSimulator() {
  var isSimulator = !this.event.context; //simulator doesn't send context
  return isSimulator;
}

function renderTemplate (content) {

  //create a template for each screen you want to display.
  //This example has one that I called "factBodyTemplate".
  //define your templates using one of several built in Display Templates
  //https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/display-interface-reference#display-template-reference


   switch(content.templateToken) {
       case "factBodyTemplate":
          // for reference, here's an example of the content object you'd
          // pass in for this template.
          //  var content = {
          //     "hasDisplaySpeechOutput" : "display "+speechOutput,
          //     "hasDisplayRepromptText" : randomFact,
          //     "simpleCardTitle" : this.t('SKILL_NAME'),
          //     "simpleCardContent" : randomFact,
          //     "bodyTemplateTitle" : this.t('GET_FACT_MESSAGE'),
          //     "bodyTemplateContent" : randomFact,
          //     "templateToken" : "factBodyTemplate",
          //     "sessionAttributes": {}
          //  };

           var response = {
             "version": "1.0",
             "response": {
               "directives": [
                 {
                   "type": "Display.RenderTemplate",
                   "template": {
                     "type": "BodyTemplate1",
                     "title": content.bodyTemplateTitle,
                     "token": content.templateToken,
                     "textContent": {
                       "primaryText": {
                         "type": "RichText",
                         "text": "<font size = '5'>"+content.bodyTemplateContent+"</font>"
                       }
                     },
                     "backButton": "HIDDEN"
                   }
                 }
               ],
               "outputSpeech": {
                 "type": "SSML",
                 "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
               },
               "reprompt": {
                 "outputSpeech": {
                   "type": "SSML",
                   "ssml": "<speak>"+content.hasDisplayRepromptText+"</speak>"
                 }
               },
               "shouldEndSession": content.askOrTell==":tell",
               "card": {
                 "type": "Simple",
                 "title": content.simpleCardTitle,
                 "content": content.simpleCardContent
               }
             },
             "sessionAttributes": content.sessionAttributes
           }
           this.context.succeed(response);
           break;

       default:
          this.response.speak("Thanks for chatting, goodbye");
          this.emit(':responseReady');
   }

}

//

Alexa ask vaccine buddy to create new schedule for Jemmy

Alexa ask vaccine buddy to create new vaccine schedule for amit for Hepatitis

Alexa ask vaccine buddy to show vaccine schedule 





Steps - 

Alexa start vaccine buddy

Create new schedule for Jemmy

Show vaccine schedule

yes please

//

// 1. Text strings =====================================================================================================
  //    Modify these strings and messages to change the behavior of your Lambda function

  const languageStrings = {
      'en': {
          'translation': {
              'WELCOME' : "Welcome to the Breakfast Sandwich Recipe skill. ",
              'TITLE'   : "Breakfast Sandwich",
              'HELP'    : "This skill will show you how to make a breakfast sandwich.  You can ask for the list of ingredients, or just say begin cooking if you are ready. Once you are cooking, just say Next to advance to the next step in the recipe. You can also pause the recipe at any time by saying Pause.",
              'STOP'    : "Okay, see you next time! "
          }
      }
      // , 'de-DE': { 'translation' : { 'WELCOME'   : "Guten Tag etc." } }
  };
  const data = {
    // TODO: Replace this data with your own.
      "ingredients" :
          [
              {"name": "bread",  "qty": 2, "units": "pieces of"},
              {"name": "egg",    "qty": 1, "units": ""  },
              {"name": "cheese", "qty": 1, "units": "slice of" }
          ],
      "steps" :
      [
          "Heat a frying pan on your stove over medium heat.",
          "Crack an egg in the skillet and heat until the egg becomes firm.",
          "Flip the egg with a spatula.",
          "Lay the cheese on top of the egg.",
          "Using a spatula, remove egg and cheese and place on one piece of bread.",
          "Place second piece of bread over the egg and cheese.",
          "Serve."
      ]
  };

  const welcomeCardImg = {
      smallImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_small.png',
      largeImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_large.png'
  };
  // 2. Skill Code =======================================================================================================

  const Alexa = require('alexa-sdk');
  const AWS = require('aws-sdk');  // this is defined to enable a DynamoDB connection from local testing
  const AWSregion = 'us-east-1';   // eu-west-1
  var persistenceEnabled;
  AWS.config.update({
      region: AWSregion
  });

  exports.handler = function(event, context, callback) {
      var alexa = Alexa.handler(event, context);
      // alexa.appId = 'amzn1.echo-sdk-ams.app.1234';
      alexa.dynamoDBTableName = 'RecipeSkillTable'; // creates new table for session.attributes
      if (alexa.dynamoDBTableName == 'RecipeSkillTable' ){
        persistenceEnabled=true;
      } else {
        persistenceEnabled=false;
      }
      alexa.resources = languageStrings;
      alexa.registerHandlers(handlers);
      alexa.execute();

  };

  const handlers = {
      'LaunchRequest': function () {
          if (!this.attributes['currentStep'] ) {

              var say = this.t('WELCOME') + ' ' + this.t('HELP');

              this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);

          } else {

              var say = 'Welcome back.  You were on step '
                  + this.attributes['currentStep']
                  + '. Say restart if you want to start over. '
                  + ' Ready to continue with step '
                  + (parseInt(this.attributes['currentStep']) + 1 ).toString() + '?';

              this.response.cardRenderer('Continue?', "\n" + say);
          }
          this.response.speak(say).listen(say);
          this.emit(':responseReady');
      },

      'IngredientsIntent': function () {

          var say = "";
          var list = [];
          for (var i = 0; i < data.ingredients.length; i++) {
              var item = data.ingredients[i];
              list.push(item.qty + ' ' + item.units + ' ' + item.name);
          }
          say += sayArray(list,'and');
          say = 'The ingredients you will need are, ' + say + '. Are you ready to cook? ';
          var reprompt = 'Say yes if you are ready to begin cooking the recipe.';

          var cardlist = list.toString().replace(/\,/g, '\n');

          this.response.cardRenderer(this.t('TITLE') + ' shopping list', cardlist);
          this.response.speak(say).listen(reprompt);

          this.emit(':responseReady');

      },
      'CookIntent': function () {
          this.emit('AMAZON.NextIntent');
      },
      'AMAZON.YesIntent': function () {
          this.emit('AMAZON.NextIntent');

      },
      'AMAZON.NoIntent': function () {
          this.response.speak('Okay, see you next time!');
          this.emit(':responseReady');
      },
      'AMAZON.PauseIntent': function () {

          var say = "If you pause, you'll lose your progress. Do you want to go to the next step?";
          var reprompt = "Do you want to go to the next step?";

          // cross-session persistence is enabled
          if (persistenceEnabled){
            say = 'Okay, you can come back to this skill to pick up where you left off.';
          }
          this.response.speak(say);
          this.emit(':responseReady');
      },

      'AMAZON.NextIntent': function () {
          var currentStep = incrementStep.call(this, 1);
          var say = 'Step ' + currentStep + ', ' + data.steps[currentStep - 1];
          var reprompt = 'You can say Pause, Stop, or Next.';
          var sayOnScreen = data.steps[currentStep - 1];

          if(currentStep == data.steps.length ) {

              delete this.attributes['currentStep'];

              say += '. <say-as interpret-as="interjection">bon appetit</say-as>';
              this.response.cardRenderer(this.t('TITLE'), 'Bon Appetit!', welcomeCardImg);

          } else {
              reprompt += currentStep;
              this.response.cardRenderer('Step ' + currentStep, sayOnScreen);
              this.response.listen(reprompt);
          }
          this.response.speak(say);
          this.emit(':responseReady');
      },
      'AMAZON.PreviousIntent': function () {
        // subtract 2 because we will add 1 in AMAZON.NextIntent
        // for a net decrease of 1 which gives us the previous step.
        incrementStep.call(this, -2);
        this.emit('AMAZON.NextIntent');
      },
      'AMAZON.RepeatIntent': function () {
          if (!this.attributes['currentStep'] ) {
              this.attributes['currentStep'] = 0;
          } else {
              this.attributes['currentStep'] = this.attributes['currentStep'] - 1;
          }
          this.emit('AMAZON.NextIntent');
      },
      'AMAZON.HelpIntent': function () {
          if (!this.attributes['currentStep']) {  // new session
              this.response.speak(this.t('HELP')).listen(this.t('HELP'));
          } else {
              var currentStep = this.attributes['currentStep'];
              var say = 'you are on step ' + currentStep + ' of the ' + this.t('TITLE') + ' recipe. ';
              var reprompt = 'Say Next to continue or Ingredients to hear the list of ingredients.';
              this.response.speak(say + reprompt).listen(reprompt);
          }
          this.emit(':responseReady');
      },
      'AMAZON.StartOverIntent': function () {
          delete this.attributes['currentStep'];
          this.emit('LaunchRequest');
      },
      'AMAZON.NoIntent': function () {
          this.emit('AMAZON.StopIntent');
      },
      'AMAZON.HelpIntent': function () {
          this.response.speak(this.t('HELP')).listen(this.t('HELP'));
          this.emit(':responseReady');
      },
      'AMAZON.CancelIntent': function () {
          this.response.speak(this.t('STOP'));
          this.emit(':responseReady');
      },
      'AMAZON.StopIntent': function () {
          this.emit('SessionEndedRequest');
      },
      'SessionEndedRequest': function () {
          console.log('session ended!');
          this.response.speak(this.t('STOP'));
          this.emit(':responseReady');
      }
  };

  //    END of Intent Handlers {} ========================================================================================
  // 3. Helper Function  =================================================================================================

  function incrementStep(increment){
    if (!this.attributes['currentStep'] ) {
        this.attributes['currentStep'] = 1;
    } else {
        this.attributes['currentStep'] = this.attributes['currentStep'] + increment;
        if (this.attributes['currentStep'] < 0) {
          this.attributes['currentStep']=0;
        }
    }
    return this.attributes['currentStep'];
  }


  function sayArray(myData, andor) {
      //say items in an array with commas and conjunctions.
      // the first argument is an array [] of items
      // the second argument is the list penultimate word; and/or/nor etc.

      var listString = '';

      if (myData.length == 1) {
          //just say the one item
          listString = myData[0];
      } else {
          if (myData.length == 2) {
              //add the conjuction between the two words
              listString = myData[0] + ' ' + andor + ' ' + myData[1];
          } else if (myData.length == 4 && andor=='and'){
              //read the four words in pairs when the conjuction is and
              listString=myData[0]+" and "+myData[1]+", as well as, "
                  + myData[2]+" and "+myData[3];

          }  else {
              //build an oxford comma separated list
              for (var i = 0; i < myData.length; i++) {
                  if (i < myData.length - 2) {
                      listString = listString + myData[i] + ', ';
                  } else if (i == myData.length - 2) {            //second to last
                      listString = listString + myData[i] + ', ' + andor + ' ';
                  } else {                                        //last
                      listString = listString + myData[i];
                  }
              }
          }
      }

      return(listString);
  }

  function randomArrayElement(array) {
      var i = 0;
      i = Math.floor(Math.random() * array.length);
      return(array[i]);
  }
  
  //'use strict';
const Alexa = require('alexa-sdk');
var persistenceEnabled;
 
  const welcomeCardImg = {
      smallImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_small.png',
      largeImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_large.png'
  };

  
  
const APP_ID = "amzn1.ask.skill.b52d5111-990a-4076-9e34-4d837a4d87ee";

function getSpeechDescription(item)
{
    let sentence = item.RiverName + " is the " + item.RankBasedOnLengthInMiles + "th longest river based on length,  It originates from " + item.OriginatesFrom + ", and ends in " + item.EndsIn + ". The Length in kilometer is " + item.LengthInMiles + ", and Benefitted Countries Or States are " + item.BenefittedCountriesOrStates + ". Which other river would you like to know about?";
    return sentence;
}

//This is the small version of the card image.  We use our data as the naming convention for our images so that we can dynamically
//generate the URL to the image.  The small image should be 720x400 in dimension.
function getSmallImage1() { return "https://s3.amazonaws.com/svdglobal/720x400.jpg"; }

//This is the large version of the card image.  It should be 1200x800 pixels in dimension.
function getLargeImage1() { return "https://s3.amazonaws.com/svdglobal/1200x800.jpg"; }

function getSpeechDescription1(item)
{       
    let sentence = NEW_SCHEDULE_SUCCESS_MESSAGE;
    return sentence;
}

function getSpeechDescription1(item)
{       
    let sentence = NEW_SCHEDULE_SUCCESS_MESSAGE;
    return sentence;
}

function getQuestion(counter, property, item)
{       
    switch(property)
    {
        case "RankBasedOnLengthInMiles":
            return "Here is your " + counter + "th question.  What is the rank based on length in kilometers of " + item.RiverName + " ?";
        break;
        case "OriginatesFrom":
            return "Here is your " + counter + "th question.  From where did " + item.RiverName + " River originate ?";
        break;
        case "EndsIn":
            return "Here is your " + counter + "th question.  Where does " + item.RiverName + " River end ?";
        break;
		case "LengthInMiles":
            return "Here is your " + counter + "th question.  What is the length in kilometers of " + item.RiverName + " River ?";
        break;
		case "BenefittedCountriesOrStates":
            return "Here is your " + counter + "th question.  Which are the benefitted countries or states from " + item.RiverName + " River ?";
        break;
        default:
            return "Here is your " + counter + "th question.  What is the " + formatCasing(property) + " of "  + item.RiverName + "?";
        break;
    }
    
}

function getAnswer(property, item)
{
    switch(property)
    {
        case "RankBasedOnLengthInMiles":
            return "The rank based on length in kilometers of " + item.RiverName + " is " + item[property] + ". "
        break;
		case "OriginatesFrom":
            return item.RiverName + " river originates from " + item[property] + ". "
        break;
		case "EndsIn":
            return item.RiverName + " river ends in " + item[property] + ". "
        break;
		case "LengthInMiles":
            return "The length in kilometers of " + item.RiverName + " is " + item[property] + ". "
        break;
		case "BenefittedCountriesOrStates":
            return "The benefitted countries or states from " + item.RiverName + " are " + item[property] + ". "
        break;
        default:
            return "The " + formatCasing(property) + " of " + item.RiverName + " is " + item[property] + ". "
        break;
    }
}
const speechConsCorrect = ["Booya", "All righty", "Bam", "Bazinga", "Bingo", "Boom", "Bravo", "Cha Ching", "Cheers", "Dynomite",
"Hip hip hooray", "Hurrah", "Hurray", "Huzzah", "Oh dear.  Just kidding.  Hurray", "Kaboom", "Kaching", "Oh snap", "Phew",
"Righto", "Way to go", "Well done", "Whee", "Woo hoo", "Yay", "Wowza", "Yowsa"];

const speechConsWrong = ["Argh", "Aw man", "Blarg", "Blast", "Boo", "Bummer", "Darn", "D'oh", "Dun dun dun", "Eek", "Honk", "Le sigh",
"Mamma mia", "Oh boy", "Oh dear", "Oof", "Ouch", "Ruh roh", "Shucks", "Uh oh", "Wah wah", "Whoops a daisy", "Yikes"];

const WELCOME_MESSAGE = "Welcome to Vaccine Buddy! You can ask me to create vaccine schedule, update vaccine schedule, show upcoming schedule or set reminder.  What would you like to do?";

const USE_IMAGES_FLAG = true;

const START_QUIZ_MESSAGE1 = "OK.  I will ask you 10 questions about the Rivers in India.";

const START_QUIZ_MESSAGE = "What is the nick name of kid ?";

const NEW_SCHEDULE_SUCCESS_MESSAGE = "Vaccine schedule has been created succcesfully for ";

const WHAT_CAN_I_DO =  "<break time='2s'/> What else you would you like to do?"

const SHOW_SCHEDULE_MESSAGE = "Hang on, here is vaccine schedule as per your request. <break time='2s'/> Do you want to set reminder ?  ";

const EXIT_SKILL_MESSAGE = "Thank you for playing the River Game!  Let's play again soon!";

const REPROMPT_SPEECH = "What other help do you want ?";

const REMINDER_SET_MESSAGE = "Hurrray, Reminder has set successfully.";

const HELP_MESSAGE = "I know lots of things about kids vaccination.  You can ask me to create vaccine schedule, update vaccine schedule, show upcoming schedule or set reminder.  What would you like to do?";

function getBadAnswer(item) { return "I'm sorry. " + item + " is not something I know very much about in this skill. " + HELP_MESSAGE; }

function getCurrentScore(score, counter) { return "Your current score is " + score + " out of " + counter + ". "; }

function getFinalScore(score, counter) { return "Your final score is " + score + " out of " + counter + ". "; }

const USE_CARDS_FLAG = false;

function getCardTitle(item) { return item.RiverName;}

function getSmallImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/720x400/" + item.Abbreviation + "._TTH_.png"; }

function getLargeImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/1200x800/" + item.Abbreviation + "._TTH_.png"; }

const data = [
{RankBasedOnLengthInMiles: 1, RiverName: "Indus",  OriginatesFrom: "In Tibet Kalish Range 5080 mts", EndsIn: "Arabian sea", LengthInMiles: 2900, BenefittedCountriesOrStates: "India and Pakistan"},
{RankBasedOnLengthInMiles: 2, RiverName: "Brahmaputra",  OriginatesFrom: "Lake Manasarovar", EndsIn: "Bay of Bengal River", LengthInMiles: 2900, BenefittedCountriesOrStates: "North Eastern state"},
{RankBasedOnLengthInMiles: 3, RiverName: "Ganga",  OriginatesFrom: "Gangothri", EndsIn: "Bay of Bengal", LengthInMiles: 2510, BenefittedCountriesOrStates: "Uttar Pradesh, Uttarakhand, Bihar, West Bengal"},
{RankBasedOnLengthInMiles: 4, RiverName: "Godavari",  OriginatesFrom: "Nasik Hills", EndsIn: "Bay of Bengal", LengthInMiles: 1450, BenefittedCountriesOrStates: "South-easterly part of Andhra Pradesh"},
{RankBasedOnLengthInMiles: 5, RiverName: "Narmada",  OriginatesFrom: "Amarkantak hill in Madhya Pradesh", EndsIn: "Arabian sea", LengthInMiles: 1290, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 6, RiverName: "Krishna",  OriginatesFrom: "Near Mahabaleshwar in Maharashtra", EndsIn: "Bay of Bengal", LengthInMiles: 1290, BenefittedCountriesOrStates: "Maharastra and Andhrapradesh"},
{RankBasedOnLengthInMiles: 7, RiverName: "Yamuna",  OriginatesFrom: "Garhwall in Yamunotri", EndsIn: "Bay of Bengal", LengthInMiles: 1211, BenefittedCountriesOrStates: "Delhi, Haryana and UP"},
{RankBasedOnLengthInMiles: 8, RiverName: "Mahanadi",  OriginatesFrom: "Amarkantak Plateau", EndsIn: "Bay of Bengal", LengthInMiles: 890, BenefittedCountriesOrStates: "Jharkhand, Chhattisgarh, Orissa"},
{RankBasedOnLengthInMiles: 9, RiverName: "Kaveri",  OriginatesFrom: "Hills of Coorg, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 760, BenefittedCountriesOrStates: "Karnataka and Tamilnadu"},
{RankBasedOnLengthInMiles: 10, RiverName: "Tapi",  OriginatesFrom: "Bettul", EndsIn: "Arabian sea", LengthInMiles: 724, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 11, RiverName: "Sone",  OriginatesFrom: "Amarkantak in Madhya Pradesh", EndsIn: "Ganges River", LengthInMiles: 784, BenefittedCountriesOrStates: "Madhya Pradesh, Uttar Pradesh,�Jharkhand, Bihar"},
{RankBasedOnLengthInMiles: 12, RiverName: "Kaveri",  OriginatesFrom: "Hills of Coorg, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 760, BenefittedCountriesOrStates: "Karnataka and Tamilnadu"},
{RankBasedOnLengthInMiles: 13, RiverName: "Tapi",  OriginatesFrom: "Bettul", EndsIn: "Arabian sea", LengthInMiles: 724, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 14, RiverName: "Manjira",  OriginatesFrom: "Balaghat range of hills near Ahmednagar", EndsIn: "Godavari River", LengthInMiles: 724, BenefittedCountriesOrStates: "Maharashtra, Karnataka, Telangana"},
{RankBasedOnLengthInMiles: 15, RiverName: "Pennar",  OriginatesFrom: "Nandi Hills, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 597, BenefittedCountriesOrStates: "Andhra Pradesh, Karnataka"},
{RankBasedOnLengthInMiles: 16, RiverName: "Damodar",  OriginatesFrom: "Chandwa, Latehar, Chota Nagpur Plateau,�Jharkhand", EndsIn: "Hooghly River,�Howrah district,�West Bengal", LengthInMiles: 592, BenefittedCountriesOrStates: "Bokaro,�Asansol,�Raniganj,�Durgapur,�Bardhaman"},
{RankBasedOnLengthInMiles: 17, RiverName: "Mahi",  OriginatesFrom: "Madhya pradesh, Vindhyas", EndsIn: "Arabian sea", LengthInMiles: 583, BenefittedCountriesOrStates: "Madhya Pradesh,Rajasthan,Gujarat"},
{RankBasedOnLengthInMiles: 18, RiverName: "Tungabhadra ",  OriginatesFrom: "Koodli, Bhadravathi, Karnataka", EndsIn: "Krishna River", LengthInMiles: 531, BenefittedCountriesOrStates: "Karnataka, Telangana, Andhra Pradesh"},
{RankBasedOnLengthInMiles: 19, RiverName: "Tungabhadra ",  OriginatesFrom: "Koodli, Bhadravathi, Karnataka", EndsIn: "Krishna River", LengthInMiles: 531, BenefittedCountriesOrStates: "Karnataka, Telangana, Andhra Pradesh"},
            ];
					
const vaccineSchedules = {       
      "two" :
      [
          "DTaP-HB-IPV-Hib",
          "Pneumococcal Conjugate",
          "Rotavirus",
          "Meningococcal C Conjugate"
      ]
};
						
const counter = 0;

const states = {
    START: "_START",
    QUIZ: "_QUIZ"
};

const handlers = {
     "LaunchRequest": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
     },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.emitWithState("Quiz");
    },
    "AnswerIntent": function() {
        this.handler.state = states.START;
        this.emitWithState("AnswerIntent");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
    }
};

const startHandlers = Alexa.CreateStateHandler(states.START,{
    "Start": function() {
        this.response.speak(WELCOME_MESSAGE).listen(HELP_MESSAGE);
		this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
        this.emit(":responseReady");
    },
    "AnswerIntent": function() {
        //let item = getItem(this.event.request.intent.slots);
		//let item = getYesNo(this.event.request.intent.slots);
		
		/*
        this.attributes["ageOfKid"] = 0;
        if (item && item[Object.getOwnPropertyNames(data[0])[0]] != undefined)
        {
          console.log("\nMEMO's TEST\n");
            if (USE_CARDS_FLAG)
            {
                let imageObj = {smallImageUrl: getSmallImage(item), largeImageUrl: getLargeImage(item)};

                this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
                this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);            }
            else
            {
                this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
            }
        }
        else
        {
            this.response.speak(getBadAnswer(item)).listen(getBadAnswer(item));

        }
		*/
        this.response.speak(REMINDER_SET_MESSAGE).listen(REPROMPT_SPEECH);
        this.emit(":responseReady");
    },
    "CreateScheduleIntent": function() {
        //this.handler.state = states.QUIZ;
        //this.emitWithState("Quiz");
		// One item with two properties: question_id and title.				
        
       if (this.attributes["nameOfKid"] == undefined)
        {   		    	
            this.attributes["nameOfKid"] = getKidName(this.event.request.intent.slots);
        }		
		this.attributes["defaultSchedule"] = "Yes";
		
		   var speechOutput = getSpeechDescription1() + this.attributes["nameOfKid"];
           const randomFact = "123456789";
		   
          if(false) {
          console.log("has display:"+ supportsDisplay.call(this));
          console.log("is simulator:"+isSimulator.call(this));
          var content = {
             "hasDisplaySpeechOutput" : speechOutput,
             "hasDisplayRepromptText" : randomFact,
             "simpleCardTitle" : "123",
             "simpleCardContent" : randomFact,
             "bodyTemplateTitle" : "456",
             "bodyTemplateContent" : randomFact,
             "templateToken" : "factBodyTemplate",
             "askOrTell" : ":tell",
             "sessionAttributes": {}
          };
          renderTemplate.call(this, content);
        } else {
        // Just use a card if the device doesn't support a card.
          //this.response.cardRenderer(this.t('SKILL_NAME'), randomFact);
          //this.response.speak(speechOutput);
          
		  this.attributes["creationDate"] = new Date();
		  this.response.speak(getSpeechDescription1() + this.attributes["nameOfKid"] + " " + WHAT_CAN_I_DO).listen(REPROMPT_SPEECH);
		  this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
		  this.emit(':responseReady');
		  }          

		  
		  //if (USE_CARDS_FLAG)
		 // {
                //let imageObj = {smallImageUrl: getSmallImage(item), largeImageUrl: getLargeImage(item)};

               // this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
                //this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);    
				//}
            //else
            //{
                //this.response.speak(getSpeechDescription1() + this.attributes["nameOfKid"]).listen(REPROMPT_SPEECH);
				//this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
            //}
		//this.emit(":responseReady");
		
    },	
    "ShowScheduleIntent": function() {
        //this.handler.state = states.QUIZ;
		//let sentence = this.attributes["nameOfKid"];	

		console.log("Answer Intent event: "+JSON.stringify(this.event));
        //var item = getItem(this.event.request.intent.slots);

        //if (item && item[Object.getOwnPropertyNames(data[0])[0]] !== undefined) {
            if (supportsDisplay.call(this)||isSimulator.call(this)) {
              //this device supports a display

              let content = { 
                    //"hasDisplaySpeechOutput" : getSpeechDescription(item),
					"hasDisplaySpeechOutput" : SHOW_SCHEDULE_MESSAGE,
                    "hasDisplayRepromptText" : REPROMPT_SPEECH,
                    //"noDisplaySpeechOutput" : getSpeechDescription(item),
					"noDisplaySpeechOutput" : SHOW_SCHEDULE_MESSAGE,
                    "noDisplayRepromptText" : REPROMPT_SPEECH,
                    //"simpleCardTitle" : getCardTitle(item),
					"simpleCardTitle" : "Jemmy's Vaccine Schedule",
                    "simpleCardContent" : getSchedule1(),
                    //"bodyTemplateTitle" : getCardTitle(item),
					"bodyTemplateTitle" : "Jemmy's Vaccine Schedule",
                    "bodyTemplateContent" : getSchedule1(),
                    "templateToken" : "ItemDetailsView",
                    "askOrTell": ":ask",
                    "sessionAttributes" : this.attributes
                };
                if (USE_IMAGES_FLAG) {
                  content["imageSmallUrl"]=getSmallImage1();
                  content["imageLargeUrl"]=getLargeImage1();
                }
                renderTemplate.call(this,content);



            } else {
              //this device does not support a display
              if (USE_IMAGES_FLAG) {
                //we have images so produce a card
                var imageObj = {smallImageUrl: getSmallImage1(), largeImageUrl: getLargeImage1()};
                //this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);
				this.response.cardRenderer("Amit's Vaccine Schedule", getSchedule1(), imageObj);
              }
              //this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
			  this.response.speak(SHOW_SCHEDULE_MESSAGE).listen(REPROMPT_SPEECH);
              this.emit(":responseReady");
            }
/*  
        } else {
            this.response.speak(getBadAnswer(item)).listen(getBadAnswer(item));
            this.emit(":responseReady");
        }
		
	*/	
		
		
		/*
        let response = "";		
		
		for (var i = 0; i < vaccineSchedules.two.length; i++) {
              var item = vaccineSchedules.two[i];
			  
               response += "<break time='1s'/>" + (i+1) + " <break time='1s'/>" + item + " ," ;
          }
		  response += "  and its recommended to take within " + " two " + " months. Do you want to set reminder ? " ; 
		
        this.response.speak(SHOW_SCHEDULE_MESSAGE + response).listen(REPROMPT_SPEECH);
		this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
		this.emit(':responseReady');
		*/
		
    },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.emitWithState("Quiz");
    },
    "AMAZON.PauseIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.emitWithState("Start");
    }
});


const quizHandlers = Alexa.CreateStateHandler(states.QUIZ,{
    "Quiz": function() {
        this.attributes["response"] = "";
		this.attributes["kidNickName"] = "";
        this.attributes["counter"] = 0;
        this.attributes["quizscore"] = 0;
        this.emitWithState("AskQuestion");
    },
    "AskQuestion": function() {
        if (this.attributes["kidNickName"] == "")
        {   
            this.attributes["response"] = START_QUIZ_MESSAGE + " ";
        }

        let random = getRandom(0, data.length-1);
        let item = data[random];

        let propertyArray = Object.getOwnPropertyNames(item);
        let property = propertyArray[getRandom(1, propertyArray.length-1)];

        this.attributes["quizitem"] = item;
        this.attributes["quizproperty"] = property;
        this.attributes["counter"]++;

        let question = getQuestion(this.attributes["counter"], property, item);
        //let speech = this.attributes["response"] + question;
		let speech = this.attributes["response"];

        this.emit(":ask", speech, question);
    },
    "AnswerIntent": function() {
        let response = "";
        let speechOutput = "";
        let item = this.attributes["quizitem"];
        let property = this.attributes["quizproperty"]

        let correct = compareSlots(this.event.request.intent.slots, item[property]);

        if (correct)
        {
            response = getSpeechCon(true);
            this.attributes["quizscore"]++;
        }
        else
        {
            response = getSpeechCon(false);
        }

        response += getAnswer(property, item);

        if (this.attributes["counter"] < 10)
        {
            response += getCurrentScore(this.attributes["quizscore"], this.attributes["counter"]);
            this.attributes["response"] = response;
            this.emitWithState("AskQuestion");
        }
        else
        {
            response += getFinalScore(this.attributes["quizscore"], this.attributes["counter"]);
            speechOutput = response + " " + EXIT_SKILL_MESSAGE;

            this.response.speak(speechOutput);
            this.emit(":responseReady");
        }
    },
    "AMAZON.RepeatIntent": function() {
        let question = getQuestion(this.attributes["counter"], this.attributes["quizproperty"], this.attributes["quizitem"]);
        this.response.speak(question).listen(question);
        this.emit(":responseReady");
    },
    "AMAZON.StartOverIntent": function() {
        this.emitWithState("Quiz");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.PauseIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.emitWithState("AnswerIntent");
    }
});

function getKidName(slots)
{ console.log("#########2 ");
    for (let slot in slots)
    {
	console.log("#########3 ");
        if (slots[slot].value != undefined)
        {	console.log("#########4 " + slots[slot].name.toString().toLowerCase());		
            if (slots[slot].name.toString().toLowerCase() == "nameofkid")
            {   
			console.log("#########5 ");			
                let nameOfKid = slots[slot].value.toString();
				return nameOfKid;
            }
        }
    }
    return "";
}

function getSchedule1()
{  

    var response = "";		
		
		for (var i = 0; i < vaccineSchedules.two.length; i++) {
              var item = vaccineSchedules.two[i];
			  
               response += item + "\n" ;
          }
		  response += "                   Expected Date : 31st-May-2018                Do you want to set reminder ?" ; 
   
   /*
    var text = "";

    for (var key in item)
    {
        text += formatCasing(key) + ": " + item[key] + "\n";
    }
	*/
    return response;
}


function getSchedule()
{  

    var response = "";		
		
		for (var i = 0; i < vaccineSchedules.two.length; i++) {
              var item = vaccineSchedules.two[i];
			  
               response += "<break time='1s'/>" + (i+1) + " <break time='1s'/>" + ": "+ item + "\n" ;
          }
		  response += "  and its recommended to take within " + " two " + " months. Do you want to set reminder ? " ; 
   
   /*
    var text = "";

    for (var key in item)
    {
        text += formatCasing(key) + ": " + item[key] + "\n";
    }
	*/
    return response;
}

function compareSlots(slots, value)
{
    for (let slot in slots)
    {
        if (slots[slot].value != undefined)
        {
			this.attributes["kidNickName"] = slots[slot].value.toString();
            if (slots[slot].value.toString().toLowerCase() == value.toString().toLowerCase())
            {
                return true;
            }
        }
    }
    return false;
}

function getRandom(min, max)
{
    return Math.floor(Math.random() * (max-min+1)+min);
}

function getRandomSymbolSpeech(symbol)
{
    return "<say-as interpret-as='spell-out'>" + symbol + "</say-as>";
}

function getYesNo(slots)
{
    let propertyArray = Object.getOwnPropertyNames(data[0]);
    let value;

    for (let slot in slots)
    {
        if (slots[slot].value !== undefined)
        {
            value = slots[slot].value;
            for (let property in propertyArray)
            {
                let item = data.filter(x => x[propertyArray[property]].toString().toLowerCase() === slots[slot].value.toString().toLowerCase());
                if (item.length > 0)
                {
                    return item[0];
                }
            }
        }
    }
    return value;
}

function getItem(slots)
{
    let propertyArray = Object.getOwnPropertyNames(data[0]);
    let value;

    for (let slot in slots)
    {
        if (slots[slot].value !== undefined)
        {
            value = slots[slot].value;
            for (let property in propertyArray)
            {
                let item = data.filter(x => x[propertyArray[property]].toString().toLowerCase() === slots[slot].value.toString().toLowerCase());
                if (item.length > 0)
                {
                    return item[0];
                }
            }
        }
    }
    return value;
}

function getSpeechCon(type)
{
    let speechCon = "";
    if (type) return "<say-as interpret-as='interjection'>" + speechConsCorrect[getRandom(0, speechConsCorrect.length-1)] + "! </say-as><break strength='strong'/>";
    else return "<say-as interpret-as='interjection'>" + speechConsWrong[getRandom(0, speechConsWrong.length-1)] + " </say-as><break strength='strong'/>";
}

function formatCasing(key)
{
    key = key.split(/(?=[A-Z])/).join(" ");
    return key;
}

function getTextDescription(item)
{
    let text = "";

    for (let key in item)
    {
        text += formatCasing(key) + ": " + item[key] + "\n";
    }
    return text;
}

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
	
	alexa.dynamoDBTableName = 'RecipeSkillTable'; // creates new table for session.attributes
      if (alexa.dynamoDBTableName == 'RecipeSkillTable' ){
        persistenceEnabled=true;
      } else {
        persistenceEnabled=false;
      }
	
    alexa.registerHandlers(handlers, startHandlers, quizHandlers);
    alexa.execute();
};

//==============================================================================
//===================== Echo Show Helper Functions  ============================
//==============================================================================


function supportsDisplay() {
  var hasDisplay =
    this.event.context &&
    this.event.context.System &&
    this.event.context.System.device &&
    this.event.context.System.device.supportedInterfaces &&
    this.event.context.System.device.supportedInterfaces.Display

  return hasDisplay;
}

function isSimulator() {
  var isSimulator = !this.event.context; //simulator doesn't send context
  return false;
}


function renderTemplate (content) {
   console.log("renderTemplate" + content.templateToken);
   //learn about the various templates
   //https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/display-interface-reference#display-template-reference
   //
   switch(content.templateToken) {
       case "WelcomeScreenView":
         //Send the response to Alexa
         this.context.succeed(response);
         break;
       case "FinalScoreView":
        //  "hasDisplaySpeechOutput" : response + " " + EXIT_SKILL_MESSAGE,
        //  "bodyTemplateContent" : getFinalScore(this.attributes["quizscore"], this.attributes["counter"]),
        //  "templateToken" : "FinalScoreView",
        //  "askOrTell": ":tell",
        //  "hint":"start a quiz",
        //  "sessionAttributes" : this.attributes
        //  "backgroundImageUrl"
        var response = {
          "version": "1.0",
          "response": {
            "directives": [
              {
                "type": "Display.RenderTemplate",
                "backButton": "HIDDEN",
                "template": {
                  "type": "BodyTemplate6",
                  //"title": content.bodyTemplateTitle,
                  "token": content.templateToken,
                  "textContent": {
                    "primaryText": {
                      "type": "RichText",
                      "text": "<font size = '7'>"+content.bodyTemplateContent+"</font>"
                    }
                  }
                }
              },{
                  "type": "Hint",
                  "hint": {
                    "type": "PlainText",
                    "text": content.hint
                  }
                }
            ],
            "outputSpeech": {
              "type": "SSML",
              "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
            },
            "reprompt": {
              "outputSpeech": {
                "type": "SSML",
                "ssml": ""
              }
            },
            "shouldEndSession": content.askOrTell== ":tell",

          },
          "sessionAttributes": content.sessionAttributes

        }

        if(content.backgroundImageUrl) {
          //when we have images, create a sources object

          let sources = [
            {
              "size": "SMALL",
              "url": content.backgroundImageUrl
            },
            {
              "size": "LARGE",
              "url": content.backgroundImageUrl
            }
          ];
          //add the image sources object to the response
          response["response"]["directives"][0]["template"]["backgroundImage"]={};
          response["response"]["directives"][0]["template"]["backgroundImage"]["sources"]=sources;
        }



         //Send the response to Alexa
         this.context.succeed(response);
         break;

       case "ItemDetailsView":
           var response = {
             "version": "1.0",
             "response": {
               "directives": [
                 {
                   "type": "Display.RenderTemplate",
                   "template": {
                     "type": "BodyTemplate3",
                     "title": content.bodyTemplateTitle,
                     "token": content.templateToken,
                     "textContent": {
                       "primaryText": {
                         "type": "RichText",
                         "text": "<font size = '5'>"+content.bodyTemplateContent+"</font>"
                       }
                     },
                     "backButton": "HIDDEN"
                   }
                 }
               ],
               "outputSpeech": {
                 "type": "SSML",
                 "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
               },
               "reprompt": {
                 "outputSpeech": {
                   "type": "SSML",
                   "ssml": "<speak>"+content.hasDisplayRepromptText+"</speak>"
                 }
               },
               "shouldEndSession": content.askOrTell== ":tell",
               "card": {
                 "type": "Simple",
                 "title": content.simpleCardTitle,
                 "content": content.simpleCardContent
               }
             },
             "sessionAttributes": content.sessionAttributes

         }

          if(content.imageSmallUrl && content.imageLargeUrl) {
            //when we have images, create a sources object
            //TODO switch template to one without picture?
            let sources = [
              {
                "size": "SMALL",
                "url": content.imageSmallUrl
              },
              {
                "size": "LARGE",
                "url": content.imageLargeUrl
              }
            ];
            //add the image sources object to the response
            response["response"]["directives"][0]["template"]["image"]={};
            response["response"]["directives"][0]["template"]["image"]["sources"]=sources;
          }
          //Send the response to Alexa
          console.log("ready to respond (ItemDetailsView): "+JSON.stringify(response));
           this.context.succeed(response);
           break;
       case "MultipleChoiceListView":
       console.log ("listItems "+JSON.stringify(content.listItems));
           var response = {
              "version": "1.0",
              "response": {
                "directives": [
                  {
                    "type": "Display.RenderTemplate",
                    "template": {
                      "type": "ListTemplate1",
                      "title": content.listTemplateTitle,
                      "token": content.templateToken,
                      "listItems":content.listItems,
                      "backgroundImage": {
                        "sources": [
                          {
                            "size": "SMALL",
                            "url": content.backgroundImageSmallUrl
                          },
                          {
                            "size": "LARGE",
                            "url": content.backgroundImageLargeUrl
                          }
                        ]
                      },
                      "backButton": "HIDDEN"
                    }
                  }
                ],
                "outputSpeech": {
                  "type": "SSML",
                  "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
                },
                "reprompt": {
                  "outputSpeech": {
                    "type": "SSML",
                    "ssml": "<speak>"+content.hasDisplayRepromptText+"</speak>"
                  }
                },
                "shouldEndSession": content.askOrTell== ":tell",
                "card": {
                  "type": "Simple",
                  "title": content.simpleCardTitle,
                  "content": content.simpleCardContent
                }
              },
                "sessionAttributes": content.sessionAttributes

          }

            if(content.backgroundImageLargeUrl) {
              //when we have images, create a sources object
              //TODO switch template to one without picture?
              let sources = [
                {
                  "size": "SMALL",
                  "url": content.backgroundImageLargeUrl
                },
                {
                  "size": "LARGE",
                  "url": content.backgroundImageLargeUrl
                }
              ];
              //add the image sources object to the response
              response["response"]["directives"][0]["template"]["backgroundImage"]={};
              response["response"]["directives"][0]["template"]["backgroundImage"]["sources"]=sources;
            }
            console.log("ready to respond (MultipleChoiceList): "+JSON.stringify(response));
           this.context.succeed(response);
           break;
       default:
          this.response.speak("Thanks for playing, goodbye");
          this.emit(':responseReady');
   }

}

//


Axa ask vaccine buddy to create new vaccination schedule 
Axa ask vaccine buddy to schedule Heppatitus vaccine

Axa ask vaccine buddy to show upcoming vaccine schedule
Axa ask vaccine buddy to show this weeks vaccine schedule
Axa ask vaccine buddy to show this weeks vaccine schedule
Axa ask vaccine buddy to show this months vaccine schedule

Axa ask vaccine buddy to mark hepatitus vaccine as done
Axa ask vaccine buddy to mark reschedule reminder of hepatitus to next Monday 

Axa ask vaccine buddy to update reminder settings
Axa ask vaccine buddy to update reminder email to xyz@gmail.com
Axa ask vaccine buddy to update reminder mobile number to 1234567890

//

// 1. Text strings =====================================================================================================
  //    Modify these strings and messages to change the behavior of your Lambda function

  const languageStrings = {
      'en': {
          'translation': {
              'WELCOME' : "Welcome to the Breakfast Sandwich Recipe skill. ",
              'TITLE'   : "Breakfast Sandwich",
              'HELP'    : "This skill will show you how to make a breakfast sandwich.  You can ask for the list of ingredients, or just say begin cooking if you are ready. Once you are cooking, just say Next to advance to the next step in the recipe. You can also pause the recipe at any time by saying Pause.",
              'STOP'    : "Okay, see you next time! "
          }
      }
      // , 'de-DE': { 'translation' : { 'WELCOME'   : "Guten Tag etc." } }
  };
  const data = {
    // TODO: Replace this data with your own.
      "ingredients" :
          [
              {"name": "bread",  "qty": 2, "units": "pieces of"},
              {"name": "egg",    "qty": 1, "units": ""  },
              {"name": "cheese", "qty": 1, "units": "slice of" }
          ],
      "steps" :
      [
          "Heat a frying pan on your stove over medium heat.",
          "Crack an egg in the skillet and heat until the egg becomes firm.",
          "Flip the egg with a spatula.",
          "Lay the cheese on top of the egg.",
          "Using a spatula, remove egg and cheese and place on one piece of bread.",
          "Place second piece of bread over the egg and cheese.",
          "Serve."
      ]
  };

  const welcomeCardImg = {
      smallImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_small.png',
      largeImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_large.png'
  };
  // 2. Skill Code =======================================================================================================

  const Alexa = require('alexa-sdk');
  const AWS = require('aws-sdk');  // this is defined to enable a DynamoDB connection from local testing
  const AWSregion = 'us-east-1';   // eu-west-1
  var persistenceEnabled;
  AWS.config.update({
      region: AWSregion
  });

  exports.handler = function(event, context, callback) {
      var alexa = Alexa.handler(event, context);
      // alexa.appId = 'amzn1.echo-sdk-ams.app.1234';
      // alexa.dynamoDBTableName = 'RecipeSkillTable'; // creates new table for session.attributes
      if (alexa.dynamoDBTableName == 'RecipeSkillTable' ){
        persistenceEnabled=true;
      } else {
        persistenceEnabled=false;
      }
      alexa.resources = languageStrings;
      alexa.registerHandlers(handlers);
      alexa.execute();

  };

  const handlers = {
      'LaunchRequest': function () {
          if (!this.attributes['currentStep'] ) {

              var say = this.t('WELCOME') + ' ' + this.t('HELP');

              this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);

          } else {

              var say = 'Welcome back.  You were on step '
                  + this.attributes['currentStep']
                  + '. Say restart if you want to start over. '
                  + ' Ready to continue with step '
                  + (parseInt(this.attributes['currentStep']) + 1 ).toString() + '?';

              this.response.cardRenderer('Continue?', "\n" + say);
          }
          this.response.speak(say).listen(say);
          this.emit(':responseReady');
      },

      'IngredientsIntent': function () {

          var say = "";
          var list = [];
          for (var i = 0; i < data.ingredients.length; i++) {
              var item = data.ingredients[i];
              list.push(item.qty + ' ' + item.units + ' ' + item.name);
          }
          say += sayArray(list,'and');
          say = 'The ingredients you will need are, ' + say + '. Are you ready to cook? ';
          var reprompt = 'Say yes if you are ready to begin cooking the recipe.';

          var cardlist = list.toString().replace(/\,/g, '\n');

          this.response.cardRenderer(this.t('TITLE') + ' shopping list', cardlist);
          this.response.speak(say).listen(reprompt);

          this.emit(':responseReady');

      },
      'CookIntent': function () {
          this.emit('AMAZON.NextIntent');
      },
      'AMAZON.YesIntent': function () {
          this.emit('AMAZON.NextIntent');

      },
      'AMAZON.NoIntent': function () {
          this.response.speak('Okay, see you next time!');
          this.emit(':responseReady');
      },
      'AMAZON.PauseIntent': function () {

          var say = "If you pause, you'll lose your progress. Do you want to go to the next step?";
          var reprompt = "Do you want to go to the next step?";

          // cross-session persistence is enabled
          if (persistenceEnabled){
            say = 'Okay, you can come back to this skill to pick up where you left off.';
          }
          this.response.speak(say);
          this.emit(':responseReady');
      },

      'AMAZON.NextIntent': function () {
          var currentStep = incrementStep.call(this, 1);
          var say = 'Step ' + currentStep + ', ' + data.steps[currentStep - 1];
          var reprompt = 'You can say Pause, Stop, or Next.';
          var sayOnScreen = data.steps[currentStep - 1];

          if(currentStep == data.steps.length ) {

              delete this.attributes['currentStep'];

              say += '. <say-as interpret-as="interjection">bon appetit</say-as>';
              this.response.cardRenderer(this.t('TITLE'), 'Bon Appetit!', welcomeCardImg);

          } else {
              reprompt += currentStep;
              this.response.cardRenderer('Step ' + currentStep, sayOnScreen);
              this.response.listen(reprompt);
          }
          this.response.speak(say);
          this.emit(':responseReady');
      },
      'AMAZON.PreviousIntent': function () {
        // subtract 2 because we will add 1 in AMAZON.NextIntent
        // for a net decrease of 1 which gives us the previous step.
        incrementStep.call(this, -2);
        this.emit('AMAZON.NextIntent');
      },
      'AMAZON.RepeatIntent': function () {
          if (!this.attributes['currentStep'] ) {
              this.attributes['currentStep'] = 0;
          } else {
              this.attributes['currentStep'] = this.attributes['currentStep'] - 1;
          }
          this.emit('AMAZON.NextIntent');
      },
      'AMAZON.HelpIntent': function () {
          if (!this.attributes['currentStep']) {  // new session
              this.response.speak(this.t('HELP')).listen(this.t('HELP'));
          } else {
              var currentStep = this.attributes['currentStep'];
              var say = 'you are on step ' + currentStep + ' of the ' + this.t('TITLE') + ' recipe. ';
              var reprompt = 'Say Next to continue or Ingredients to hear the list of ingredients.';
              this.response.speak(say + reprompt).listen(reprompt);
          }
          this.emit(':responseReady');
      },
      'AMAZON.StartOverIntent': function () {
          delete this.attributes['currentStep'];
          this.emit('LaunchRequest');
      },
      'AMAZON.NoIntent': function () {
          this.emit('AMAZON.StopIntent');
      },
      'AMAZON.HelpIntent': function () {
          this.response.speak(this.t('HELP')).listen(this.t('HELP'));
          this.emit(':responseReady');
      },
      'AMAZON.CancelIntent': function () {
          this.response.speak(this.t('STOP'));
          this.emit(':responseReady');
      },
      'AMAZON.StopIntent': function () {
          this.emit('SessionEndedRequest');
      },
      'SessionEndedRequest': function () {
          console.log('session ended!');
          this.response.speak(this.t('STOP'));
          this.emit(':responseReady');
      }
  };

  //    END of Intent Handlers {} ========================================================================================
  // 3. Helper Function  =================================================================================================

  function incrementStep(increment){
    if (!this.attributes['currentStep'] ) {
        this.attributes['currentStep'] = 1;
    } else {
        this.attributes['currentStep'] = this.attributes['currentStep'] + increment;
        if (this.attributes['currentStep'] < 0) {
          this.attributes['currentStep']=0;
        }
    }
    return this.attributes['currentStep'];
  }


  function sayArray(myData, andor) {
      //say items in an array with commas and conjunctions.
      // the first argument is an array [] of items
      // the second argument is the list penultimate word; and/or/nor etc.

      var listString = '';

      if (myData.length == 1) {
          //just say the one item
          listString = myData[0];
      } else {
          if (myData.length == 2) {
              //add the conjuction between the two words
              listString = myData[0] + ' ' + andor + ' ' + myData[1];
          } else if (myData.length == 4 && andor=='and'){
              //read the four words in pairs when the conjuction is and
              listString=myData[0]+" and "+myData[1]+", as well as, "
                  + myData[2]+" and "+myData[3];

          }  else {
              //build an oxford comma separated list
              for (var i = 0; i < myData.length; i++) {
                  if (i < myData.length - 2) {
                      listString = listString + myData[i] + ', ';
                  } else if (i == myData.length - 2) {            //second to last
                      listString = listString + myData[i] + ', ' + andor + ' ';
                  } else {                                        //last
                      listString = listString + myData[i];
                  }
              }
          }
      }

      return(listString);
  }

  function randomArrayElement(array) {
      var i = 0;
      i = Math.floor(Math.random() * array.length);
      return(array[i]);
}

//// 1. Text strings =====================================================================================================
  //    Modify these strings and messages to change the behavior of your Lambda function

  const languageStrings = {
      'en': {
          'translation': {
              'WELCOME' : "Welcome to the Breakfast Sandwich Recipe skill. ",
              'TITLE'   : "Breakfast Sandwich",
              'HELP'    : "This skill will show you how to make a breakfast sandwich.  You can ask for the list of ingredients, or just say begin cooking if you are ready. Once you are cooking, just say Next to advance to the next step in the recipe. You can also pause the recipe at any time by saying Pause.",
              'STOP'    : "Okay, see you next time! "
          }
      }
      // , 'de-DE': { 'translation' : { 'WELCOME'   : "Guten Tag etc." } }
  };
  const data = {
    // TODO: Replace this data with your own.
      "ingredients" :
          [
              {"name": "bread",  "qty": 2, "units": "pieces of"},
              {"name": "egg",    "qty": 1, "units": ""  },
              {"name": "cheese", "qty": 1, "units": "slice of" }
          ],
      "steps" :
      [
          "Heat a frying pan on your stove over medium heat.",
          "Crack an egg in the skillet and heat until the egg becomes firm.",
          "Flip the egg with a spatula.",
          "Lay the cheese on top of the egg.",
          "Using a spatula, remove egg and cheese and place on one piece of bread.",
          "Place second piece of bread over the egg and cheese.",
          "Serve."
      ]
  };

  const welcomeCardImg = {
      smallImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_small.png',
      largeImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_large.png'
  };
  // 2. Skill Code =======================================================================================================

  const Alexa = require('alexa-sdk');
  const AWS = require('aws-sdk');  // this is defined to enable a DynamoDB connection from local testing
  const AWSregion = 'us-east-1';   // eu-west-1
  var persistenceEnabled;
  AWS.config.update({
      region: AWSregion
  });

  exports.handler = function(event, context, callback) {
      var alexa = Alexa.handler(event, context);
      // alexa.appId = 'amzn1.echo-sdk-ams.app.1234';
      alexa.dynamoDBTableName = 'RecipeSkillTable'; // creates new table for session.attributes
      if (alexa.dynamoDBTableName == 'RecipeSkillTable' ){
        persistenceEnabled=true;
      } else {
        persistenceEnabled=false;
      }
      alexa.resources = languageStrings;
      alexa.registerHandlers(handlers);
      alexa.execute();

  };

  const handlers = {
      'LaunchRequest': function () {
          if (!this.attributes['currentStep'] ) {

              var say = this.t('WELCOME') + ' ' + this.t('HELP');

              this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);

          } else {

              var say = 'Welcome back.  You were on step '
                  + this.attributes['currentStep']
                  + '. Say restart if you want to start over. '
                  + ' Ready to continue with step '
                  + (parseInt(this.attributes['currentStep']) + 1 ).toString() + '?';

              this.response.cardRenderer('Continue?', "\n" + say);
          }
          this.response.speak(say).listen(say);
          this.emit(':responseReady');
      },

      'IngredientsIntent': function () {

          var say = "";
          var list = [];
          for (var i = 0; i < data.ingredients.length; i++) {
              var item = data.ingredients[i];
              list.push(item.qty + ' ' + item.units + ' ' + item.name);
          }
          say += sayArray(list,'and');
          say = 'The ingredients you will need are, ' + say + '. Are you ready to cook? ';
          var reprompt = 'Say yes if you are ready to begin cooking the recipe.';

          var cardlist = list.toString().replace(/\,/g, '\n');

          this.response.cardRenderer(this.t('TITLE') + ' shopping list', cardlist);
          this.response.speak(say).listen(reprompt);

          this.emit(':responseReady');

      },
      'CookIntent': function () {
          this.emit('AMAZON.NextIntent');
      },
      'AMAZON.YesIntent': function () {
          this.emit('AMAZON.NextIntent');

      },
      'AMAZON.NoIntent': function () {
          this.response.speak('Okay, see you next time!');
          this.emit(':responseReady');
      },
      'AMAZON.PauseIntent': function () {

          var say = "If you pause, you'll lose your progress. Do you want to go to the next step?";
          var reprompt = "Do you want to go to the next step?";

          // cross-session persistence is enabled
          if (persistenceEnabled){
            say = 'Okay, you can come back to this skill to pick up where you left off.';
          }
          this.response.speak(say);
          this.emit(':responseReady');
      },

      'AMAZON.NextIntent': function () {
          var currentStep = incrementStep.call(this, 1);
          var say = 'Step ' + currentStep + ', ' + data.steps[currentStep - 1];
          var reprompt = 'You can say Pause, Stop, or Next.';
          var sayOnScreen = data.steps[currentStep - 1];

          if(currentStep == data.steps.length ) {

              delete this.attributes['currentStep'];

              say += '. <say-as interpret-as="interjection">bon appetit</say-as>';
              this.response.cardRenderer(this.t('TITLE'), 'Bon Appetit!', welcomeCardImg);

          } else {
              reprompt += currentStep;
              this.response.cardRenderer('Step ' + currentStep, sayOnScreen);
              this.response.listen(reprompt);
          }
          this.response.speak(say);
          this.emit(':responseReady');
      },
      'AMAZON.PreviousIntent': function () {
        // subtract 2 because we will add 1 in AMAZON.NextIntent
        // for a net decrease of 1 which gives us the previous step.
        incrementStep.call(this, -2);
        this.emit('AMAZON.NextIntent');
      },
      'AMAZON.RepeatIntent': function () {
          if (!this.attributes['currentStep'] ) {
              this.attributes['currentStep'] = 0;
          } else {
              this.attributes['currentStep'] = this.attributes['currentStep'] - 1;
          }
          this.emit('AMAZON.NextIntent');
      },
      'AMAZON.HelpIntent': function () {
          if (!this.attributes['currentStep']) {  // new session
              this.response.speak(this.t('HELP')).listen(this.t('HELP'));
          } else {
              var currentStep = this.attributes['currentStep'];
              var say = 'you are on step ' + currentStep + ' of the ' + this.t('TITLE') + ' recipe. ';
              var reprompt = 'Say Next to continue or Ingredients to hear the list of ingredients.';
              this.response.speak(say + reprompt).listen(reprompt);
          }
          this.emit(':responseReady');
      },
      'AMAZON.StartOverIntent': function () {
          delete this.attributes['currentStep'];
          this.emit('LaunchRequest');
      },
      'AMAZON.NoIntent': function () {
          this.emit('AMAZON.StopIntent');
      },
      'AMAZON.HelpIntent': function () {
          this.response.speak(this.t('HELP')).listen(this.t('HELP'));
          this.emit(':responseReady');
      },
      'AMAZON.CancelIntent': function () {
          this.response.speak(this.t('STOP'));
          this.emit(':responseReady');
      },
      'AMAZON.StopIntent': function () {
          this.emit('SessionEndedRequest');
      },
      'SessionEndedRequest': function () {
          console.log('session ended!');
          this.response.speak(this.t('STOP'));
          this.emit(':responseReady');
      }
  };

  //    END of Intent Handlers {} ========================================================================================
  // 3. Helper Function  =================================================================================================

  function incrementStep(increment){
    if (!this.attributes['currentStep'] ) {
        this.attributes['currentStep'] = 1;
    } else {
        this.attributes['currentStep'] = this.attributes['currentStep'] + increment;
        if (this.attributes['currentStep'] < 0) {
          this.attributes['currentStep']=0;
        }
    }
    return this.attributes['currentStep'];
  }


  function sayArray(myData, andor) {
      //say items in an array with commas and conjunctions.
      // the first argument is an array [] of items
      // the second argument is the list penultimate word; and/or/nor etc.

      var listString = '';

      if (myData.length == 1) {
          //just say the one item
          listString = myData[0];
      } else {
          if (myData.length == 2) {
              //add the conjuction between the two words
              listString = myData[0] + ' ' + andor + ' ' + myData[1];
          } else if (myData.length == 4 && andor=='and'){
              //read the four words in pairs when the conjuction is and
              listString=myData[0]+" and "+myData[1]+", as well as, "
                  + myData[2]+" and "+myData[3];

          }  else {
              //build an oxford comma separated list
              for (var i = 0; i < myData.length; i++) {
                  if (i < myData.length - 2) {
                      listString = listString + myData[i] + ', ';
                  } else if (i == myData.length - 2) {            //second to last
                      listString = listString + myData[i] + ', ' + andor + ' ';
                  } else {                                        //last
                      listString = listString + myData[i];
                  }
              }
          }
      }

      return(listString);
  }

  function randomArrayElement(array) {
      var i = 0;
      i = Math.floor(Math.random() * array.length);
      return(array[i]);
  }
  
  //
  
  'use strict';
const Alexa = require('alexa-sdk');

//=========================================================================================================================================
//TODO: The items below this comment need your attention
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.
//Make sure to enclose your value in quotes, like this:  var APP_ID = "amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1";
const APP_ID = undefined;

//This function returns a descriptive sentence about your data.  Before a user starts a quiz, they can ask about a specific data element,
//like "Ohio."  The skill will speak the sentence from this function, pulling the data values from the appropriate record in your data.
function getSpeechDescription(item)
{
    var sentence = item.StateName + " is the " + item.StatehoodOrder + "th state, admitted to the Union in " + item.StatehoodYear + ".  The capital of " + item.StateName + " is " + item.Capital + ", and the abbreviation for " + item.StateName + " is <break strength='strong'/><say-as interpret-as='spell-out'>" + item.Abbreviation + "</say-as>.  I've added " + item.StateName + " to your Alexa app.  Which other state or capital would you like to know about?";
    return sentence;
}

//We have provided two ways to create your quiz questions.  The default way is to phrase all of your questions like: "What is X of Y?"
//If this approach doesn't work for your data, take a look at the commented code in this function.  You can write a different question
//structure for each property of your data.
function getQuestion(counter, property, item)
{
    return "Here is your " + counter + "th question.  What is the " + formatCasing(property) + " of "  + item.StateName + "?";

    /*
    switch(property)
    {
        case "City":
            return "Here is your " + counter + "th question.  In what city do the " + item.League + "'s "  + item.Mascot + " play?";
        break;
        case "Sport":
            return "Here is your " + counter + "th question.  What sport do the " + item.City + " " + item.Mascot + " play?";
        break;
        case "HeadCoach":
            return "Here is your " + counter + "th question.  Who is the head coach of the " + item.City + " " + item.Mascot + "?";
        break;
        default:
            return "Here is your " + counter + "th question.  What is the " + formatCasing(property) + " of the "  + item.Mascot + "?";
        break;
    }
    */
}

//This is the function that returns an answer to your user during the quiz.  Much like the "getQuestion" function above, you can use a
//switch() statement to create different responses for each property in your data.  For example, when this quiz has an answer that includes
//a state abbreviation, we add some SSML to make sure that Alexa spells that abbreviation out (instead of trying to pronounce it.)
function getAnswer(property, item)
{
    switch(property)
    {
        case "Abbreviation":
            return "The " + formatCasing(property) + " of " + item.StateName + " is <say-as interpret-as='spell-out'>" + item[property] + "</say-as>. ";
        break;
        default:
            return "The " + formatCasing(property) + " of " + item.StateName + " is " + item[property] + ". ";
        break;
    }
}

//This is a list of positive speechcons that this skill will use when a user gets a correct answer.  For a full list of supported
//speechcons, go here: https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/speechcon-reference
const speechConsCorrect = ["Booya", "All righty", "Bam", "Bazinga", "Bingo", "Boom", "Bravo", "Cha Ching", "Cheers", "Dynomite",
"Hip hip hooray", "Hurrah", "Hurray", "Huzzah", "Oh dear.  Just kidding.  Hurray", "Kaboom", "Kaching", "Oh snap", "Phew",
"Righto", "Way to go", "Well done", "Whee", "Woo hoo", "Yay", "Wowza", "Yowsa"];

//This is a list of negative speechcons that this skill will use when a user gets an incorrect answer.  For a full list of supported
//speechcons, go here: https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/speechcon-reference
const speechConsWrong = ["Argh", "Aw man", "Blarg", "Blast", "Boo", "Bummer", "Darn", "D'oh", "Dun dun dun", "Eek", "Honk", "Le sigh",
"Mamma mia", "Oh boy", "Oh dear", "Oof", "Ouch", "Ruh roh", "Shucks", "Uh oh", "Wah wah", "Whoops a daisy", "Yikes"];

//This is the welcome message for when a user starts the skill without a specific intent.
const WELCOME_MESSAGE = "Welcome to the United States Quiz Game!  You can ask me about any of the fifty states and their capitals, or you can ask me to start a quiz.  What would you like to do?";

//This is the message a user will hear when they start a quiz.
const START_QUIZ_MESSAGE = "OK.  I will ask you 10 questions about the United States.";

//This is the message a user will hear when they try to cancel or stop the skill, or when they finish a quiz.
const EXIT_SKILL_MESSAGE = "Thank you for playing the United States Quiz Game!  Let's play again soon!";

//This is the message a user will hear after they ask (and hear) about a specific data element.
const REPROMPT_SPEECH = "Which other state or capital would you like to know about?";

//This is the message a user will hear when they ask Alexa for help in your skill.
const HELP_MESSAGE = "I know lots of things about the United States.  You can ask me about a state or a capital, and I'll tell you what I know.  You can also test your knowledge by asking me to start a quiz.  What would you like to do?";


//This is the response a user will receive when they ask about something we weren't expecting.  For example, say "pizza" to your
//skill when it starts.  This is the response you will receive.
function getBadAnswer(item) { return "I'm sorry. " + item + " is not something I know very much about in this skill. " + HELP_MESSAGE; }

//This is the message a user will receive after each question of a quiz.  It reminds them of their current score.
function getCurrentScore(score, counter) { return "Your current score is " + score + " out of " + counter + ". "; }

//This is the message a user will receive after they complete a quiz.  It tells them their final score.
function getFinalScore(score, counter) { return "Your final score is " + score + " out of " + counter + ". "; }

//These next four values are for the Alexa cards that are created when a user asks about one of the data elements.
//This only happens outside of a quiz.

//If you don't want to use cards in your skill, set the USE_IMAGES_FLAG to false.  If you set it to true, you will need an image for each
//item in your data.
const USE_IMAGES_FLAG = true;

//This is what your card title will be.  For our example, we use the name of the state the user requested.
function getCardTitle(item) { return item.StateName;}

//This is the small version of the card image.  We use our data as the naming convention for our images so that we can dynamically
//generate the URL to the image.  The small image should be 720x400 in dimension.
function getSmallImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/720x400/" + item.Abbreviation + "._TTH_.png"; }

//This is the large version of the card image.  It should be 1200x800 pixels in dimension.
function getLargeImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/1200x800/" + item.Abbreviation + "._TTH_.png"; }

// backgroundImage for Echo Show body templates
function getBackgroundImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/1024x600/" + item.Abbreviation + "._TTH_.png"; }

//=========================================================================================================================================
//TODO: Replace this data with your own.
//=========================================================================================================================================
const data = [
                {StateName: "Alabama",        Abbreviation: "AL", Capital: "Montgomery",     StatehoodYear: 1819, StatehoodOrder: 22 },
                {StateName: "Alaska",         Abbreviation: "AK", Capital: "Juneau",         StatehoodYear: 1959, StatehoodOrder: 49 },
                {StateName: "Arizona",        Abbreviation: "AZ", Capital: "Phoenix",        StatehoodYear: 1912, StatehoodOrder: 48 },
                {StateName: "Arkansas",       Abbreviation: "AR", Capital: "Little Rock",    StatehoodYear: 1836, StatehoodOrder: 25 },
                {StateName: "California",     Abbreviation: "CA", Capital: "Sacramento",     StatehoodYear: 1850, StatehoodOrder: 31 },
                {StateName: "Colorado",       Abbreviation: "CO", Capital: "Denver",         StatehoodYear: 1876, StatehoodOrder: 38 },
                {StateName: "Connecticut",    Abbreviation: "CT", Capital: "Hartford",       StatehoodYear: 1788, StatehoodOrder: 5 },
                {StateName: "Delaware",       Abbreviation: "DE", Capital: "Dover",          StatehoodYear: 1787, StatehoodOrder: 1 },
                {StateName: "Florida",        Abbreviation: "FL", Capital: "Tallahassee",    StatehoodYear: 1845, StatehoodOrder: 27 },
                {StateName: "Georgia",        Abbreviation: "GA", Capital: "Atlanta",        StatehoodYear: 1788, StatehoodOrder: 4 },
                {StateName: "Hawaii",         Abbreviation: "HI", Capital: "Honolulu",       StatehoodYear: 1959, StatehoodOrder: 50 },
                {StateName: "Idaho",          Abbreviation: "ID", Capital: "Boise",          StatehoodYear: 1890, StatehoodOrder: 43 },
                {StateName: "Illinois",       Abbreviation: "IL", Capital: "Springfield",    StatehoodYear: 1818, StatehoodOrder: 21 },
                {StateName: "Indiana",        Abbreviation: "IN", Capital: "Indianapolis",   StatehoodYear: 1816, StatehoodOrder: 19 },
                {StateName: "Iowa",           Abbreviation: "IA", Capital: "Des Moines",     StatehoodYear: 1846, StatehoodOrder: 29 },
                {StateName: "Kansas",         Abbreviation: "KS", Capital: "Topeka",         StatehoodYear: 1861, StatehoodOrder: 34 },
                {StateName: "Kentucky",       Abbreviation: "KY", Capital: "Frankfort",      StatehoodYear: 1792, StatehoodOrder: 15 },
                {StateName: "Louisiana",      Abbreviation: "LA", Capital: "Baton Rouge",    StatehoodYear: 1812, StatehoodOrder: 18 },
                {StateName: "Maine",          Abbreviation: "ME", Capital: "Augusta",        StatehoodYear: 1820, StatehoodOrder: 23 },
                {StateName: "Maryland",       Abbreviation: "MD", Capital: "Annapolis",      StatehoodYear: 1788, StatehoodOrder: 7 },
                {StateName: "Massachusetts",  Abbreviation: "MA", Capital: "Boston",         StatehoodYear: 1788, StatehoodOrder: 6 },
                {StateName: "Michigan",       Abbreviation: "MI", Capital: "Lansing",        StatehoodYear: 1837, StatehoodOrder: 26 },
                {StateName: "Minnesota",      Abbreviation: "MN", Capital: "St. Paul",       StatehoodYear: 1858, StatehoodOrder: 32 },
                {StateName: "Mississippi",    Abbreviation: "MS", Capital: "Jackson",        StatehoodYear: 1817, StatehoodOrder: 20 },
                {StateName: "Missouri",       Abbreviation: "MO", Capital: "Jefferson City", StatehoodYear: 1821, StatehoodOrder: 24 },
                {StateName: "Montana",        Abbreviation: "MT", Capital: "Helena",         StatehoodYear: 1889, StatehoodOrder: 41 },
                {StateName: "Nebraska",       Abbreviation: "NE", Capital: "Lincoln",        StatehoodYear: 1867, StatehoodOrder: 37 },
                {StateName: "Nevada",         Abbreviation: "NV", Capital: "Carson City",    StatehoodYear: 1864, StatehoodOrder: 36 },
                {StateName: "New Hampshire",  Abbreviation: "NH", Capital: "Concord",        StatehoodYear: 1788, StatehoodOrder: 9 },
                {StateName: "New Jersey",     Abbreviation: "NJ", Capital: "Trenton",        StatehoodYear: 1787, StatehoodOrder: 3 },
                {StateName: "New Mexico",     Abbreviation: "NM", Capital: "Santa Fe",       StatehoodYear: 1912, StatehoodOrder: 47 },
                {StateName: "New York",       Abbreviation: "NY", Capital: "Albany",         StatehoodYear: 1788, StatehoodOrder: 11 },
                {StateName: "North Carolina", Abbreviation: "NC", Capital: "Raleigh",        StatehoodYear: 1789, StatehoodOrder: 12 },
                {StateName: "North Dakota",   Abbreviation: "ND", Capital: "Bismarck",       StatehoodYear: 1889, StatehoodOrder: 39 },
                {StateName: "Ohio",           Abbreviation: "OH", Capital: "Columbus",       StatehoodYear: 1803, StatehoodOrder: 17 },
                {StateName: "Oklahoma",       Abbreviation: "OK", Capital: "Oklahoma City",  StatehoodYear: 1907, StatehoodOrder: 46 },
                {StateName: "Oregon",         Abbreviation: "OR", Capital: "Salem",          StatehoodYear: 1859, StatehoodOrder: 33 },
                {StateName: "Pennsylvania",   Abbreviation: "PA", Capital: "Harrisburg",     StatehoodYear: 1787, StatehoodOrder: 2 },
                {StateName: "Rhode Island",   Abbreviation: "RI", Capital: "Providence",     StatehoodYear: 1790, StatehoodOrder: 13 },
                {StateName: "South Carolina", Abbreviation: "SC", Capital: "Columbia",       StatehoodYear: 1788, StatehoodOrder: 8 },
                {StateName: "South Dakota",   Abbreviation: "SD", Capital: "Pierre",         StatehoodYear: 1889, StatehoodOrder: 40 },
                {StateName: "Tennessee",      Abbreviation: "TN", Capital: "Nashville",      StatehoodYear: 1796, StatehoodOrder: 16 },
                {StateName: "Texas",          Abbreviation: "TX", Capital: "Austin",         StatehoodYear: 1845, StatehoodOrder: 28 },
                {StateName: "Utah",           Abbreviation: "UT", Capital: "Salt Lake City", StatehoodYear: 1896, StatehoodOrder: 45 },
                {StateName: "Vermont",        Abbreviation: "VT", Capital: "Montpelier",     StatehoodYear: 1791, StatehoodOrder: 14 },
                {StateName: "Virginia",       Abbreviation: "VA", Capital: "Richmond",       StatehoodYear: 1788, StatehoodOrder: 10 },
                {StateName: "Washington",     Abbreviation: "WA", Capital: "Olympia",        StatehoodYear: 1889, StatehoodOrder: 42 },
                {StateName: "West Virginia",  Abbreviation: "WV", Capital: "Charleston",     StatehoodYear: 1863, StatehoodOrder: 35 },
                {StateName: "Wisconsin",      Abbreviation: "WI", Capital: "Madison",        StatehoodYear: 1848, StatehoodOrder: 30 },
                {StateName: "Wyoming",        Abbreviation: "WY", Capital: "Cheyenne",       StatehoodYear: 1890, StatehoodOrder: 44 }
            ];

//=========================================================================================================================================
//Editing anything below this line might break your skill.
//=========================================================================================================================================

var counter = 0;

const states = {
    START: "_START",
    QUIZ: "_QUIZ"
};

const handlers = {
     "LaunchRequest": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
     },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.emitWithState("Quiz");
    },
    "AnswerIntent": function() {
        this.handler.state = states.START;
        this.emitWithState("AnswerIntent");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
    },
    "AMAZON.PreviousIntent": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
    },
    "AMAZON.NextIntent": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
    }
};

const startHandlers = Alexa.CreateStateHandler(states.START,{
    "Start": function() {
        this.response.speak(WELCOME_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "AnswerIntent": function() {
       console.log("Answer Intent event: "+JSON.stringify(this.event));
        var item = getItem(this.event.request.intent.slots);

        if (item && item[Object.getOwnPropertyNames(data[0])[0]] !== undefined) {
            if (supportsDisplay.call(this)||isSimulator.call(this)) {
              //this device supports a display

              let content = {
                    "hasDisplaySpeechOutput" : getSpeechDescription(item),
                    "hasDisplayRepromptText" : REPROMPT_SPEECH,
                    "noDisplaySpeechOutput" : getSpeechDescription(item),
                    "noDisplayRepromptText" : REPROMPT_SPEECH,
                    "simpleCardTitle" : getCardTitle(item),
                    "simpleCardContent" : getTextDescription(item),
                    "bodyTemplateTitle" : getCardTitle(item),
                    "bodyTemplateContent" : getTextDescription(item),
                    "templateToken" : "ItemDetailsView",
                    "askOrTell": ":ask",
                    "sessionAttributes" : this.attributes
                };
                if (USE_IMAGES_FLAG) {
                  content["imageSmallUrl"]=getSmallImage(item);
                  content["imageLargeUrl"]=getLargeImage(item);
                }
                renderTemplate.call(this,content);



            } else {
              //this device does not support a display
              if (USE_IMAGES_FLAG) {
                //we have images so produce a card
                var imageObj = {smallImageUrl: getSmallImage(item), largeImageUrl: getLargeImage(item)};
                this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);
              }
              this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
              this.emit(":responseReady");
            }

        } else {
            this.response.speak(getBadAnswer(item)).listen(getBadAnswer(item));
            this.emit(":responseReady");
        }
    },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.attributes['STATE'] = this.handler.state;
        console.log("IN QUIZ INTENT " + this.handler.state);
        console.log("IN QUIZ INTENT " + JSON.stringify(this.attributes));
        this.emitWithState("Quiz");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(':responseReady');
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(':responseReady');
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.PreviousIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.NextIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    }
});


const quizHandlers = Alexa.CreateStateHandler(states.QUIZ,{
    "Quiz": function() {
        this.attributes["response"] = "";
        this.attributes["counter"] = 0;
        this.attributes["quizscore"] = 0;
        this.emitWithState("AskQuestion");
    },
    "AskQuestion": function() {
        console.log("in askQuestion: "+JSON.stringify(this.attributes));
        if (this.attributes["counter"] == 0)
        {
            this.attributes["response"] = START_QUIZ_MESSAGE + " ";
        }

        var random = getRandom(0, data.length-1);
        var item = data[random];

        var propertyArray = Object.getOwnPropertyNames(item);
        var property = propertyArray[getRandom(1, propertyArray.length-1)];

        // store correct answers in session attributes
        this.attributes["quizitem"] = item;
        this.attributes["quizproperty"] = property;
        this.attributes["counter"]++;

        // Create list of possible answers to display on Echo Show (3 wrong, 1 right).

        var answerList = [];
        answerList.push(item[property]);
        for (var i = 0; i < 2; i++) {
          var randomItem = data[getRandom(0, data.length-1)];
          answerList.push(randomItem[property]);
          //TODO could push same the same item more than once
        }
        //console.log("answerList: "+JSON.stringify(answerList));

        var question = getQuestion(this.attributes["counter"], property, item);
        var speech = this.attributes["response"] + question;


        if (USE_IMAGES_FLAG) {

        //TODO if (this.event.context.System.device.supportedInterfaces.Display) {
              var shuffledMultipleChoiceList = shuffle(answerList);

              let listItems = shuffledMultipleChoiceList.map((x) => {
                return { "token" : x,
                  "textContent" : {
                    "primaryText":
                    {
                      "text": x,
                      "type": "PlainText"
                    }
                  }
                }
              })



              let content = {
                    "hasDisplaySpeechOutput" : speech,
                    "hasDisplayRepromptText" : question,
                    "noDisplaySpeechOutput" : speech,
                    "noDisplayRepromptText" : question,
                    "simpleCardTitle" : getCardTitle(item),
                    "simpleCardContent" : getTextDescription(item),
                    "listTemplateTitle" : this.attributes["quizscore"]+" / "+this.attributes["counter"]+": "+getCardTitle(item),
                    //"listTemplateContent" : getTextDescription(item),
                    "templateToken" : "MultipleChoiceListView",
                    "askOrTell": ":ask",
                    "listItems" : listItems,
                    "hint" : "Add a hint here",
                    "sessionAttributes" : this.attributes
                };

                if (USE_IMAGES_FLAG) {
                  content["backgroundImageLargeUrl"]=getBackgroundImage(item);
                }
                console.log("ASK Question event: "+JSON.stringify(this.event));

                renderTemplate.call(this,content);



        } else {
            this.response.speak(speech).listen(question);
            this.emit(":responseReady");
        }

    },
    "ElementSelected" : function() {
      // We will look for the value in this.event.request.token in the AnswerIntent call to compareSlots
      console.log("in ElementSelected QUIZ state");
      this.emitWithState("AnswerIntent");
    },
    "AnswerIntent": function() {
        var response = "";
        var item = this.attributes["quizitem"];
        var property = this.attributes["quizproperty"];

        var correct = compareSlots.call(this, item[property]);

        if (correct)
        {
            response = getSpeechCon(true);
            this.attributes["quizscore"]++;
        }
        else
        {
            response = getSpeechCon(false);
        }

        response += getAnswer(property, item);

        if (this.attributes["counter"] < 10)
        {
            response += getCurrentScore(this.attributes["quizscore"], this.attributes["counter"]);
            this.attributes["response"] = response;
            this.emitWithState("AskQuestion");
        }
        else
        {
          response += getFinalScore(this.attributes["quizscore"], this.attributes["counter"]);
          if (supportsDisplay.call(this)||isSimulator.call(this)) {
            //this device supports a display

            let content = {
                  "hasDisplaySpeechOutput" : response + " " + EXIT_SKILL_MESSAGE,
                  "bodyTemplateContent" : getFinalScore(this.attributes["quizscore"], this.attributes["counter"]),
                  "templateToken" : "FinalScoreView",
                  "askOrTell": ":tell",
                  "sessionAttributes" : this.attributes
              };
              if (USE_IMAGES_FLAG) {
                content["backgroundImageUrl"]=getBackgroundImage(item);
              }
              renderTemplate.call(this,content);



          } else {

            this.response.speak(response + " " + EXIT_SKILL_MESSAGE);
            this.emit(":responseReady");
          }
        }
    },
    "AMAZON.StartOverIntent": function() {
        this.emitWithState("Quiz");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.emitWithState("AnswerIntent");
    },
    "AMAZON.PreviousIntent": function() {
          this.emitWithState("AnswerIntent");
    },
    "AMAZON.NextIntent": function() {
          this.emitWithState("AnswerIntent");
    }
});

function compareSlots(value) {
  //are there slots
  var isSlot=
    this.event.request &&
    this.event.request.intent &&
    this.event.request.intent.slots;

  //are there tokens
  var isToken=
    this.event.request &&
    this.event.request.token;

  if(isSlot){
  let slots=this.event.request.intent.slots;
    for (var slot in slots){
        if (slots[slot].value != undefined){
            if (slots[slot].value.toString().toLowerCase() == value.toString().toLowerCase()) return true;
        }
    }
  }
  if(isToken){
    if (this.event.request.token.toString().toLowerCase() == value.toString().toLowerCase()) return true;
    console.log(this.event.request.token.toString().toLowerCase());
  }
    return false;
}

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

function getRandom(min, max)
{
    return Math.floor(Math.random() * (max-min+1)+min);
}

function getRandomSymbolSpeech(symbol)
{
    return "<say-as interpret-as='spell-out'>" + symbol + "</say-as>";
}

function getItem(slots)
{
    var propertyArray = Object.getOwnPropertyNames(data[0]);
    var value;

    for (var slot in slots)
    {
        if (slots[slot].value !== undefined)
        {
            value = slots[slot].value;
            for (var property in propertyArray)
            {
                var item = data.filter(x => x[propertyArray[property]].toString().toLowerCase() === slots[slot].value.toString().toLowerCase());
                if (item.length > 0)
                {
                    return item[0];
                }
            }
        }
    }
    return value;
}

function getSpeechCon(type)
{
    var speechCon = "";
    if (type) return "<say-as interpret-as='interjection'>" + speechConsCorrect[getRandom(0, speechConsCorrect.length-1)] + "! </say-as><break strength='strong'/>";
    else return "<say-as interpret-as='interjection'>" + speechConsWrong[getRandom(0, speechConsWrong.length-1)] + " </say-as><break strength='strong'/>";
}

function formatCasing(key)
{
    key = key.split(/(?=[A-Z])/).join(" ");
    return key;
}

function getTextDescription(item)
{
    var text = "";

    for (var key in item)
    {
        text += formatCasing(key) + ": " + item[key] + "\n";
    }
    return text;
}

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    alexa.registerHandlers(handlers, startHandlers, quizHandlers);
    alexa.execute();
};

//==============================================================================
//===================== Echo Show Helper Functions  ============================
//==============================================================================


function supportsDisplay() {
  var hasDisplay =
    this.event.context &&
    this.event.context.System &&
    this.event.context.System.device &&
    this.event.context.System.device.supportedInterfaces &&
    this.event.context.System.device.supportedInterfaces.Display

  return hasDisplay;
}

function isSimulator() {
  var isSimulator = !this.event.context; //simulator doesn't send context
  return false;
}


function renderTemplate (content) {
   console.log("renderTemplate" + content.templateToken);
   //learn about the various templates
   //https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/display-interface-reference#display-template-reference
   //
   switch(content.templateToken) {
       case "WelcomeScreenView":
         //Send the response to Alexa
         this.context.succeed(response);
         break;
       case "FinalScoreView":
        //  "hasDisplaySpeechOutput" : response + " " + EXIT_SKILL_MESSAGE,
        //  "bodyTemplateContent" : getFinalScore(this.attributes["quizscore"], this.attributes["counter"]),
        //  "templateToken" : "FinalScoreView",
        //  "askOrTell": ":tell",
        //  "hint":"start a quiz",
        //  "sessionAttributes" : this.attributes
        //  "backgroundImageUrl"
        var response = {
          "version": "1.0",
          "response": {
            "directives": [
              {
                "type": "Display.RenderTemplate",
                "backButton": "HIDDEN",
                "template": {
                  "type": "BodyTemplate6",
                  //"title": content.bodyTemplateTitle,
                  "token": content.templateToken,
                  "textContent": {
                    "primaryText": {
                      "type": "RichText",
                      "text": "<font size = '7'>"+content.bodyTemplateContent+"</font>"
                    }
                  }
                }
              },{
                  "type": "Hint",
                  "hint": {
                    "type": "PlainText",
                    "text": content.hint
                  }
                }
            ],
            "outputSpeech": {
              "type": "SSML",
              "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
            },
            "reprompt": {
              "outputSpeech": {
                "type": "SSML",
                "ssml": ""
              }
            },
            "shouldEndSession": content.askOrTell== ":tell",

          },
          "sessionAttributes": content.sessionAttributes

        }

        if(content.backgroundImageUrl) {
          //when we have images, create a sources object

          let sources = [
            {
              "size": "SMALL",
              "url": content.backgroundImageUrl
            },
            {
              "size": "LARGE",
              "url": content.backgroundImageUrl
            }
          ];
          //add the image sources object to the response
          response["response"]["directives"][0]["template"]["backgroundImage"]={};
          response["response"]["directives"][0]["template"]["backgroundImage"]["sources"]=sources;
        }



         //Send the response to Alexa
         this.context.succeed(response);
         break;

       case "ItemDetailsView":
           var response = {
             "version": "1.0",
             "response": {
               "directives": [
                 {
                   "type": "Display.RenderTemplate",
                   "template": {
                     "type": "BodyTemplate3",
                     "title": content.bodyTemplateTitle,
                     "token": content.templateToken,
                     "textContent": {
                       "primaryText": {
                         "type": "RichText",
                         "text": "<font size = '5'>"+content.bodyTemplateContent+"</font>"
                       }
                     },
                     "backButton": "HIDDEN"
                   }
                 }
               ],
               "outputSpeech": {
                 "type": "SSML",
                 "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
               },
               "reprompt": {
                 "outputSpeech": {
                   "type": "SSML",
                   "ssml": "<speak>"+content.hasDisplayRepromptText+"</speak>"
                 }
               },
               "shouldEndSession": content.askOrTell== ":tell",
               "card": {
                 "type": "Simple",
                 "title": content.simpleCardTitle,
                 "content": content.simpleCardContent
               }
             },
             "sessionAttributes": content.sessionAttributes

         }

          if(content.imageSmallUrl && content.imageLargeUrl) {
            //when we have images, create a sources object
            //TODO switch template to one without picture?
            let sources = [
              {
                "size": "SMALL",
                "url": content.imageSmallUrl
              },
              {
                "size": "LARGE",
                "url": content.imageLargeUrl
              }
            ];
            //add the image sources object to the response
            response["response"]["directives"][0]["template"]["image"]={};
            response["response"]["directives"][0]["template"]["image"]["sources"]=sources;
          }
          //Send the response to Alexa
          console.log("ready to respond (ItemDetailsView): "+JSON.stringify(response));
           this.context.succeed(response);
           break;
       case "MultipleChoiceListView":
       console.log ("listItems "+JSON.stringify(content.listItems));
           var response = {
              "version": "1.0",
              "response": {
                "directives": [
                  {
                    "type": "Display.RenderTemplate",
                    "template": {
                      "type": "ListTemplate1",
                      "title": content.listTemplateTitle,
                      "token": content.templateToken,
                      "listItems":content.listItems,
                      "backgroundImage": {
                        "sources": [
                          {
                            "size": "SMALL",
                            "url": content.backgroundImageSmallUrl
                          },
                          {
                            "size": "LARGE",
                            "url": content.backgroundImageLargeUrl
                          }
                        ]
                      },
                      "backButton": "HIDDEN"
                    }
                  }
                ],
                "outputSpeech": {
                  "type": "SSML",
                  "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
                },
                "reprompt": {
                  "outputSpeech": {
                    "type": "SSML",
                    "ssml": "<speak>"+content.hasDisplayRepromptText+"</speak>"
                  }
                },
                "shouldEndSession": content.askOrTell== ":tell",
                "card": {
                  "type": "Simple",
                  "title": content.simpleCardTitle,
                  "content": content.simpleCardContent
                }
              },
                "sessionAttributes": content.sessionAttributes

          }

            if(content.backgroundImageLargeUrl) {
              //when we have images, create a sources object
              //TODO switch template to one without picture?
              let sources = [
                {
                  "size": "SMALL",
                  "url": content.backgroundImageLargeUrl
                },
                {
                  "size": "LARGE",
                  "url": content.backgroundImageLargeUrl
                }
              ];
              //add the image sources object to the response
              response["response"]["directives"][0]["template"]["backgroundImage"]={};
              response["response"]["directives"][0]["template"]["backgroundImage"]["sources"]=sources;
            }
            console.log("ready to respond (MultipleChoiceList): "+JSON.stringify(response));
           this.context.succeed(response);
           break;
       default:
          this.response.speak("Thanks for playing, goodbye");
          this.emit(':responseReady');
   }

}

//
'use strict';
const Alexa = require('alexa-sdk');
var persistenceEnabled;
 
  const welcomeCardImg = {
      smallImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_small.png',
      largeImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_large.png'
  };

  
  
const APP_ID = "amzn1.ask.skill.b52d5111-990a-4076-9e34-4d837a4d87ee";

function getSpeechDescription(item)
{
    let sentence = item.RiverName + " is the " + item.RankBasedOnLengthInMiles + "th longest river based on length,  It originates from " + item.OriginatesFrom + ", and ends in " + item.EndsIn + ". The Length in kilometer is " + item.LengthInMiles + ", and Benefitted Countries Or States are " + item.BenefittedCountriesOrStates + ". Which other river would you like to know about?";
    return sentence;
}

function getSpeechDescription1(item)
{       
    let sentence = NEW_SCHEDULE_SUCCESS_MESSAGE;
    return sentence;
}

function getSpeechDescription1(item)
{       
    let sentence = NEW_SCHEDULE_SUCCESS_MESSAGE;
    return sentence;
}

function getQuestion(counter, property, item)
{       
    switch(property)
    {
        case "RankBasedOnLengthInMiles":
            return "Here is your " + counter + "th question.  What is the rank based on length in kilometers of " + item.RiverName + " ?";
        break;
        case "OriginatesFrom":
            return "Here is your " + counter + "th question.  From where did " + item.RiverName + " River originate ?";
        break;
        case "EndsIn":
            return "Here is your " + counter + "th question.  Where does " + item.RiverName + " River end ?";
        break;
		case "LengthInMiles":
            return "Here is your " + counter + "th question.  What is the length in kilometers of " + item.RiverName + " River ?";
        break;
		case "BenefittedCountriesOrStates":
            return "Here is your " + counter + "th question.  Which are the benefitted countries or states from " + item.RiverName + " River ?";
        break;
        default:
            return "Here is your " + counter + "th question.  What is the " + formatCasing(property) + " of "  + item.RiverName + "?";
        break;
    }
    
}

function getAnswer(property, item)
{
    switch(property)
    {
        case "RankBasedOnLengthInMiles":
            return "The rank based on length in kilometers of " + item.RiverName + " is " + item[property] + ". "
        break;
		case "OriginatesFrom":
            return item.RiverName + " river originates from " + item[property] + ". "
        break;
		case "EndsIn":
            return item.RiverName + " river ends in " + item[property] + ". "
        break;
		case "LengthInMiles":
            return "The length in kilometers of " + item.RiverName + " is " + item[property] + ". "
        break;
		case "BenefittedCountriesOrStates":
            return "The benefitted countries or states from " + item.RiverName + " are " + item[property] + ". "
        break;
        default:
            return "The " + formatCasing(property) + " of " + item.RiverName + " is " + item[property] + ". "
        break;
    }
}
const speechConsCorrect = ["Booya", "All righty", "Bam", "Bazinga", "Bingo", "Boom", "Bravo", "Cha Ching", "Cheers", "Dynomite",
"Hip hip hooray", "Hurrah", "Hurray", "Huzzah", "Oh dear.  Just kidding.  Hurray", "Kaboom", "Kaching", "Oh snap", "Phew",
"Righto", "Way to go", "Well done", "Whee", "Woo hoo", "Yay", "Wowza", "Yowsa"];

const speechConsWrong = ["Argh", "Aw man", "Blarg", "Blast", "Boo", "Bummer", "Darn", "D'oh", "Dun dun dun", "Eek", "Honk", "Le sigh",
"Mamma mia", "Oh boy", "Oh dear", "Oof", "Ouch", "Ruh roh", "Shucks", "Uh oh", "Wah wah", "Whoops a daisy", "Yikes"];

const WELCOME_MESSAGE = "Welcome to Vaccine Buddy! You can ask me to create vaccine schedule, update vaccine schedule, show upcoming schedule or set reminder.  What would you like to do?";

const START_QUIZ_MESSAGE1 = "OK.  I will ask you 10 questions about the Rivers in India.";

const START_QUIZ_MESSAGE = "What is the nick name of kid ?";

const NEW_SCHEDULE_SUCCESS_MESSAGE = "Vaccine schedule has been created succcesfully for ";

const SHOW_SCHEDULE_MESSAGE = "Hang on, here is vaccine schedule as per your request  ";

const EXIT_SKILL_MESSAGE = "Thank you for playing the River Game!  Let's play again soon!";

const REPROMPT_SPEECH = "What other help do you want ?";

const REMINDER_SET_MESSAGE = "Hurrray, Reminder has set successfully";

const HELP_MESSAGE = "I know lots of things about kids vaccination.  You can ask me to create vaccine schedule, update vaccine schedule, show upcoming schedule or set reminder.  What would you like to do?";

function getBadAnswer(item) { return "I'm sorry. " + item + " is not something I know very much about in this skill. " + HELP_MESSAGE; }

function getCurrentScore(score, counter) { return "Your current score is " + score + " out of " + counter + ". "; }

function getFinalScore(score, counter) { return "Your final score is " + score + " out of " + counter + ". "; }

const USE_CARDS_FLAG = false;

function getCardTitle(item) { return item.RiverName;}

function getSmallImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/720x400/" + item.Abbreviation + "._TTH_.png"; }

function getLargeImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/1200x800/" + item.Abbreviation + "._TTH_.png"; }

const data = [
{RankBasedOnLengthInMiles: 1, RiverName: "Indus",  OriginatesFrom: "In Tibet Kalish Range 5080 mts", EndsIn: "Arabian sea", LengthInMiles: 2900, BenefittedCountriesOrStates: "India and Pakistan"},
{RankBasedOnLengthInMiles: 2, RiverName: "Brahmaputra",  OriginatesFrom: "Lake Manasarovar", EndsIn: "Bay of Bengal River", LengthInMiles: 2900, BenefittedCountriesOrStates: "North Eastern state"},
{RankBasedOnLengthInMiles: 3, RiverName: "Ganga",  OriginatesFrom: "Gangothri", EndsIn: "Bay of Bengal", LengthInMiles: 2510, BenefittedCountriesOrStates: "Uttar Pradesh, Uttarakhand, Bihar, West Bengal"},
{RankBasedOnLengthInMiles: 4, RiverName: "Godavari",  OriginatesFrom: "Nasik Hills", EndsIn: "Bay of Bengal", LengthInMiles: 1450, BenefittedCountriesOrStates: "South-easterly part of Andhra Pradesh"},
{RankBasedOnLengthInMiles: 5, RiverName: "Narmada",  OriginatesFrom: "Amarkantak hill in Madhya Pradesh", EndsIn: "Arabian sea", LengthInMiles: 1290, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 6, RiverName: "Krishna",  OriginatesFrom: "Near Mahabaleshwar in Maharashtra", EndsIn: "Bay of Bengal", LengthInMiles: 1290, BenefittedCountriesOrStates: "Maharastra and Andhrapradesh"},
{RankBasedOnLengthInMiles: 7, RiverName: "Yamuna",  OriginatesFrom: "Garhwall in Yamunotri", EndsIn: "Bay of Bengal", LengthInMiles: 1211, BenefittedCountriesOrStates: "Delhi, Haryana and UP"},
{RankBasedOnLengthInMiles: 8, RiverName: "Mahanadi",  OriginatesFrom: "Amarkantak Plateau", EndsIn: "Bay of Bengal", LengthInMiles: 890, BenefittedCountriesOrStates: "Jharkhand, Chhattisgarh, Orissa"},
{RankBasedOnLengthInMiles: 9, RiverName: "Kaveri",  OriginatesFrom: "Hills of Coorg, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 760, BenefittedCountriesOrStates: "Karnataka and Tamilnadu"},
{RankBasedOnLengthInMiles: 10, RiverName: "Tapi",  OriginatesFrom: "Bettul", EndsIn: "Arabian sea", LengthInMiles: 724, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 11, RiverName: "Sone",  OriginatesFrom: "Amarkantak in Madhya Pradesh", EndsIn: "Ganges River", LengthInMiles: 784, BenefittedCountriesOrStates: "Madhya Pradesh, Uttar Pradesh,�Jharkhand, Bihar"},
{RankBasedOnLengthInMiles: 12, RiverName: "Kaveri",  OriginatesFrom: "Hills of Coorg, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 760, BenefittedCountriesOrStates: "Karnataka and Tamilnadu"},
{RankBasedOnLengthInMiles: 13, RiverName: "Tapi",  OriginatesFrom: "Bettul", EndsIn: "Arabian sea", LengthInMiles: 724, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 14, RiverName: "Manjira",  OriginatesFrom: "Balaghat range of hills near Ahmednagar", EndsIn: "Godavari River", LengthInMiles: 724, BenefittedCountriesOrStates: "Maharashtra, Karnataka, Telangana"},
{RankBasedOnLengthInMiles: 15, RiverName: "Pennar",  OriginatesFrom: "Nandi Hills, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 597, BenefittedCountriesOrStates: "Andhra Pradesh, Karnataka"},
{RankBasedOnLengthInMiles: 16, RiverName: "Damodar",  OriginatesFrom: "Chandwa, Latehar, Chota Nagpur Plateau,�Jharkhand", EndsIn: "Hooghly River,�Howrah district,�West Bengal", LengthInMiles: 592, BenefittedCountriesOrStates: "Bokaro,�Asansol,�Raniganj,�Durgapur,�Bardhaman"},
{RankBasedOnLengthInMiles: 17, RiverName: "Mahi",  OriginatesFrom: "Madhya pradesh, Vindhyas", EndsIn: "Arabian sea", LengthInMiles: 583, BenefittedCountriesOrStates: "Madhya Pradesh,Rajasthan,Gujarat"},
{RankBasedOnLengthInMiles: 18, RiverName: "Tungabhadra ",  OriginatesFrom: "Koodli, Bhadravathi, Karnataka", EndsIn: "Krishna River", LengthInMiles: 531, BenefittedCountriesOrStates: "Karnataka, Telangana, Andhra Pradesh"},
{RankBasedOnLengthInMiles: 19, RiverName: "Tungabhadra ",  OriginatesFrom: "Koodli, Bhadravathi, Karnataka", EndsIn: "Krishna River", LengthInMiles: 531, BenefittedCountriesOrStates: "Karnataka, Telangana, Andhra Pradesh"},
            ];
					
const vaccineSchedules = {       
      "two" :
      [
          "DTaP-HB-IPV-Hib",
          "Pneumococcal Conjugate",
          "Rotavirus",
          "Meningococcal C Conjugate"
      ]
};
						
const counter = 0;

const states = {
    START: "_START",
    QUIZ: "_QUIZ"
};

const handlers = {
     "LaunchRequest": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
     },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.emitWithState("Quiz");
    },
    "AnswerIntent": function() {
        this.handler.state = states.START;
        this.emitWithState("AnswerIntent");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
    }
};

const startHandlers = Alexa.CreateStateHandler(states.START,{
    "Start": function() {
        this.response.speak(WELCOME_MESSAGE).listen(HELP_MESSAGE);
		this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
        this.emit(":responseReady");
    },
    "AnswerIntent": function() {
        //let item = getItem(this.event.request.intent.slots);
		//let item = getYesNo(this.event.request.intent.slots);
		
		/*
        this.attributes["ageOfKid"] = 0;
        if (item && item[Object.getOwnPropertyNames(data[0])[0]] != undefined)
        {
          console.log("\nMEMO's TEST\n");
            if (USE_CARDS_FLAG)
            {
                let imageObj = {smallImageUrl: getSmallImage(item), largeImageUrl: getLargeImage(item)};

                this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
                this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);            }
            else
            {
                this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
            }
        }
        else
        {
            this.response.speak(getBadAnswer(item)).listen(getBadAnswer(item));

        }
		*/
        this.response.speak(REMINDER_SET_MESSAGE).listen(REPROMPT_SPEECH);
        this.emit(":responseReady");
    },
    "CreateScheduleIntent": function() {
        //this.handler.state = states.QUIZ;
        //this.emitWithState("Quiz");
		// One item with two properties: question_id and title.				
        
       if (this.attributes["nameOfKid"] == undefined)
        {   		    	
            this.attributes["nameOfKid"] = getKidName(this.event.request.intent.slots);
        }		
		this.attributes["defaultSchedule"] = "Yes";
		
		   var speechOutput = getSpeechDescription1() + this.attributes["nameOfKid"];
           const randomFact = "123456789";
		   
          if(false) {
          console.log("has display:"+ supportsDisplay.call(this));
          console.log("is simulator:"+isSimulator.call(this));
          var content = {
             "hasDisplaySpeechOutput" : speechOutput,
             "hasDisplayRepromptText" : randomFact,
             "simpleCardTitle" : "123",
             "simpleCardContent" : randomFact,
             "bodyTemplateTitle" : "456",
             "bodyTemplateContent" : randomFact,
             "templateToken" : "factBodyTemplate",
             "askOrTell" : ":tell",
             "sessionAttributes": {}
          };
          renderTemplate.call(this, content);
        } else {
        // Just use a card if the device doesn't support a card.
          //this.response.cardRenderer(this.t('SKILL_NAME'), randomFact);
          //this.response.speak(speechOutput);
          
		  this.attributes["creationDate"] = new Date();
		  this.response.speak(getSpeechDescription1() + this.attributes["nameOfKid"]).listen(REPROMPT_SPEECH);
		  this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
		  this.emit(':responseReady');
		  }          

		  
		  //if (USE_CARDS_FLAG)
		 // {
                //let imageObj = {smallImageUrl: getSmallImage(item), largeImageUrl: getLargeImage(item)};

               // this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
                //this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);    
				//}
            //else
            //{
                //this.response.speak(getSpeechDescription1() + this.attributes["nameOfKid"]).listen(REPROMPT_SPEECH);
				//this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
            //}
		//this.emit(":responseReady");
		
    },	
    "ShowScheduleIntent": function() {
        //this.handler.state = states.QUIZ;
		//let sentence = this.attributes["nameOfKid"];	

        let response = "";
		//const ctr = 0;
		
		for (var i = 0; i < vaccineSchedules.two.length; i++) {
              var item = vaccineSchedules.two[i];
			  
               response += "<break time='1s'/>" + (i+1) + " <break time='1s'/>" + item + " ," ;
          }
		  response += "  and its recommended to take within " + " two " + " months. Do you want to set reminder ? " ; 
		
        this.response.speak(SHOW_SCHEDULE_MESSAGE + response).listen(REPROMPT_SPEECH);
		this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
		this.emit(':responseReady');
    },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.emitWithState("Quiz");
    },
    "AMAZON.PauseIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.emitWithState("Start");
    }
});


const quizHandlers = Alexa.CreateStateHandler(states.QUIZ,{
    "Quiz": function() {
        this.attributes["response"] = "";
		this.attributes["kidNickName"] = "";
        this.attributes["counter"] = 0;
        this.attributes["quizscore"] = 0;
        this.emitWithState("AskQuestion");
    },
    "AskQuestion": function() {
        if (this.attributes["kidNickName"] == "")
        {   
            this.attributes["response"] = START_QUIZ_MESSAGE + " ";
        }

        let random = getRandom(0, data.length-1);
        let item = data[random];

        let propertyArray = Object.getOwnPropertyNames(item);
        let property = propertyArray[getRandom(1, propertyArray.length-1)];

        this.attributes["quizitem"] = item;
        this.attributes["quizproperty"] = property;
        this.attributes["counter"]++;

        let question = getQuestion(this.attributes["counter"], property, item);
        //let speech = this.attributes["response"] + question;
		let speech = this.attributes["response"];

        this.emit(":ask", speech, question);
    },
    "AnswerIntent": function() {
        let response = "";
        let speechOutput = "";
        let item = this.attributes["quizitem"];
        let property = this.attributes["quizproperty"]

        let correct = compareSlots(this.event.request.intent.slots, item[property]);

        if (correct)
        {
            response = getSpeechCon(true);
            this.attributes["quizscore"]++;
        }
        else
        {
            response = getSpeechCon(false);
        }

        response += getAnswer(property, item);

        if (this.attributes["counter"] < 10)
        {
            response += getCurrentScore(this.attributes["quizscore"], this.attributes["counter"]);
            this.attributes["response"] = response;
            this.emitWithState("AskQuestion");
        }
        else
        {
            response += getFinalScore(this.attributes["quizscore"], this.attributes["counter"]);
            speechOutput = response + " " + EXIT_SKILL_MESSAGE;

            this.response.speak(speechOutput);
            this.emit(":responseReady");
        }
    },
    "AMAZON.RepeatIntent": function() {
        let question = getQuestion(this.attributes["counter"], this.attributes["quizproperty"], this.attributes["quizitem"]);
        this.response.speak(question).listen(question);
        this.emit(":responseReady");
    },
    "AMAZON.StartOverIntent": function() {
        this.emitWithState("Quiz");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.PauseIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.emitWithState("AnswerIntent");
    }
});

function getKidName(slots)
{ console.log("#########2 ");
    for (let slot in slots)
    {
	console.log("#########3 ");
        if (slots[slot].value != undefined)
        {	console.log("#########4 " + slots[slot].name.toString().toLowerCase());		
            if (slots[slot].name.toString().toLowerCase() == "nameofkid")
            {   
			console.log("#########5 ");			
                let nameOfKid = slots[slot].value.toString();
				return nameOfKid;
            }
        }
    }
    return "";
}

function compareSlots(slots, value)
{
    for (let slot in slots)
    {
        if (slots[slot].value != undefined)
        {
			this.attributes["kidNickName"] = slots[slot].value.toString();
            if (slots[slot].value.toString().toLowerCase() == value.toString().toLowerCase())
            {
                return true;
            }
        }
    }
    return false;
}

function getRandom(min, max)
{
    return Math.floor(Math.random() * (max-min+1)+min);
}

function getRandomSymbolSpeech(symbol)
{
    return "<say-as interpret-as='spell-out'>" + symbol + "</say-as>";
}

function getYesNo(slots)
{
    let propertyArray = Object.getOwnPropertyNames(data[0]);
    let value;

    for (let slot in slots)
    {
        if (slots[slot].value !== undefined)
        {
            value = slots[slot].value;
            for (let property in propertyArray)
            {
                let item = data.filter(x => x[propertyArray[property]].toString().toLowerCase() === slots[slot].value.toString().toLowerCase());
                if (item.length > 0)
                {
                    return item[0];
                }
            }
        }
    }
    return value;
}

function getItem(slots)
{
    let propertyArray = Object.getOwnPropertyNames(data[0]);
    let value;

    for (let slot in slots)
    {
        if (slots[slot].value !== undefined)
        {
            value = slots[slot].value;
            for (let property in propertyArray)
            {
                let item = data.filter(x => x[propertyArray[property]].toString().toLowerCase() === slots[slot].value.toString().toLowerCase());
                if (item.length > 0)
                {
                    return item[0];
                }
            }
        }
    }
    return value;
}

function getSpeechCon(type)
{
    let speechCon = "";
    if (type) return "<say-as interpret-as='interjection'>" + speechConsCorrect[getRandom(0, speechConsCorrect.length-1)] + "! </say-as><break strength='strong'/>";
    else return "<say-as interpret-as='interjection'>" + speechConsWrong[getRandom(0, speechConsWrong.length-1)] + " </say-as><break strength='strong'/>";
}

function formatCasing(key)
{
    key = key.split(/(?=[A-Z])/).join(" ");
    return key;
}

function getTextDescription(item)
{
    let text = "";

    for (let key in item)
    {
        text += formatCasing(key) + ": " + item[key] + "\n";
    }
    return text;
}

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
	
	alexa.dynamoDBTableName = 'RecipeSkillTable'; // creates new table for session.attributes
      if (alexa.dynamoDBTableName == 'RecipeSkillTable' ){
        persistenceEnabled=true;
      } else {
        persistenceEnabled=false;
      }
	
    alexa.registerHandlers(handlers, startHandlers, quizHandlers);
    alexa.execute();
};

//==============================================================================
//=========================== Helper Functions  ================================
//==============================================================================

function supportsDisplay() {
  var hasDisplay =
    this.event.context &&
    this.event.context.System &&
    this.event.context.System.device &&
    this.event.context.System.device.supportedInterfaces &&
    this.event.context.System.device.supportedInterfaces.Display

  return hasDisplay;
}

function isSimulator() {
  var isSimulator = !this.event.context; //simulator doesn't send context
  return isSimulator;
}

function renderTemplate (content) {

  //create a template for each screen you want to display.
  //This example has one that I called "factBodyTemplate".
  //define your templates using one of several built in Display Templates
  //https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/display-interface-reference#display-template-reference


   switch(content.templateToken) {
       case "factBodyTemplate":
          // for reference, here's an example of the content object you'd
          // pass in for this template.
          //  var content = {
          //     "hasDisplaySpeechOutput" : "display "+speechOutput,
          //     "hasDisplayRepromptText" : randomFact,
          //     "simpleCardTitle" : this.t('SKILL_NAME'),
          //     "simpleCardContent" : randomFact,
          //     "bodyTemplateTitle" : this.t('GET_FACT_MESSAGE'),
          //     "bodyTemplateContent" : randomFact,
          //     "templateToken" : "factBodyTemplate",
          //     "sessionAttributes": {}
          //  };

           var response = {
             "version": "1.0",
             "response": {
               "directives": [
                 {
                   "type": "Display.RenderTemplate",
                   "template": {
                     "type": "BodyTemplate1",
                     "title": content.bodyTemplateTitle,
                     "token": content.templateToken,
                     "textContent": {
                       "primaryText": {
                         "type": "RichText",
                         "text": "<font size = '5'>"+content.bodyTemplateContent+"</font>"
                       }
                     },
                     "backButton": "HIDDEN"
                   }
                 }
               ],
               "outputSpeech": {
                 "type": "SSML",
                 "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
               },
               "reprompt": {
                 "outputSpeech": {
                   "type": "SSML",
                   "ssml": "<speak>"+content.hasDisplayRepromptText+"</speak>"
                 }
               },
               "shouldEndSession": content.askOrTell==":tell",
               "card": {
                 "type": "Simple",
                 "title": content.simpleCardTitle,
                 "content": content.simpleCardContent
               }
             },
             "sessionAttributes": content.sessionAttributes
           }
           this.context.succeed(response);
           break;

       default:
          this.response.speak("Thanks for chatting, goodbye");
          this.emit(':responseReady');
   }

}

//

'use strict';
const Alexa = require('alexa-sdk');
var persistenceEnabled;
 
  const welcomeCardImg = {
      smallImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_small.png',
      largeImageUrl: 'https://s3.amazonaws.com/webappvui/img/breakfast_sandwich_large.png'
  };

  
  
const APP_ID = "amzn1.ask.skill.b52d5111-990a-4076-9e34-4d837a4d87ee";

function getSpeechDescription(item)
{
    let sentence = item.RiverName + " is the " + item.RankBasedOnLengthInMiles + "th longest river based on length,  It originates from " + item.OriginatesFrom + ", and ends in " + item.EndsIn + ". The Length in kilometer is " + item.LengthInMiles + ", and Benefitted Countries Or States are " + item.BenefittedCountriesOrStates + ". Which other river would you like to know about?";
    return sentence;
}

function getSpeechDescription1(item)
{       
    let sentence = NEW_SCHEDULE_SUCCESS_MESSAGE;
    return sentence;
}

function getSpeechDescription1(item)
{       
    let sentence = NEW_SCHEDULE_SUCCESS_MESSAGE;
    return sentence;
}

function getQuestion(counter, property, item)
{       
    switch(property)
    {
        case "RankBasedOnLengthInMiles":
            return "Here is your " + counter + "th question.  What is the rank based on length in kilometers of " + item.RiverName + " ?";
        break;
        case "OriginatesFrom":
            return "Here is your " + counter + "th question.  From where did " + item.RiverName + " River originate ?";
        break;
        case "EndsIn":
            return "Here is your " + counter + "th question.  Where does " + item.RiverName + " River end ?";
        break;
		case "LengthInMiles":
            return "Here is your " + counter + "th question.  What is the length in kilometers of " + item.RiverName + " River ?";
        break;
		case "BenefittedCountriesOrStates":
            return "Here is your " + counter + "th question.  Which are the benefitted countries or states from " + item.RiverName + " River ?";
        break;
        default:
            return "Here is your " + counter + "th question.  What is the " + formatCasing(property) + " of "  + item.RiverName + "?";
        break;
    }
    
}

function getAnswer(property, item)
{
    switch(property)
    {
        case "RankBasedOnLengthInMiles":
            return "The rank based on length in kilometers of " + item.RiverName + " is " + item[property] + ". "
        break;
		case "OriginatesFrom":
            return item.RiverName + " river originates from " + item[property] + ". "
        break;
		case "EndsIn":
            return item.RiverName + " river ends in " + item[property] + ". "
        break;
		case "LengthInMiles":
            return "The length in kilometers of " + item.RiverName + " is " + item[property] + ". "
        break;
		case "BenefittedCountriesOrStates":
            return "The benefitted countries or states from " + item.RiverName + " are " + item[property] + ". "
        break;
        default:
            return "The " + formatCasing(property) + " of " + item.RiverName + " is " + item[property] + ". "
        break;
    }
}
const speechConsCorrect = ["Booya", "All righty", "Bam", "Bazinga", "Bingo", "Boom", "Bravo", "Cha Ching", "Cheers", "Dynomite",
"Hip hip hooray", "Hurrah", "Hurray", "Huzzah", "Oh dear.  Just kidding.  Hurray", "Kaboom", "Kaching", "Oh snap", "Phew",
"Righto", "Way to go", "Well done", "Whee", "Woo hoo", "Yay", "Wowza", "Yowsa"];

const speechConsWrong = ["Argh", "Aw man", "Blarg", "Blast", "Boo", "Bummer", "Darn", "D'oh", "Dun dun dun", "Eek", "Honk", "Le sigh",
"Mamma mia", "Oh boy", "Oh dear", "Oof", "Ouch", "Ruh roh", "Shucks", "Uh oh", "Wah wah", "Whoops a daisy", "Yikes"];

const WELCOME_MESSAGE = "Welcome to Vaccine Buddy! You can ask me to create vaccine schedule, update vaccine schedule, show upcoming schedule or set reminder.  What would you like to do?";

const START_QUIZ_MESSAGE1 = "OK.  I will ask you 10 questions about the Rivers in India.";

const START_QUIZ_MESSAGE = "What is the nick name of kid ?";

const NEW_SCHEDULE_SUCCESS_MESSAGE = "Vaccine schedule has been created succcesfully for ";

const SHOW_SCHEDULE_MESSAGE = "Hang on, here is vaccine schedule as per your request  ";

const EXIT_SKILL_MESSAGE = "Thank you for playing the River Game!  Let's play again soon!";

const REPROMPT_SPEECH = "What other help do you want ?";

const REMINDER_SET_MESSAGE = "Hurrray, Reminder has set successfully !!";

const HELP_MESSAGE = "I know lots of things about kids vaccination.  You can ask me to create vaccine schedule, update vaccine schedule, show upcoming schedule or set reminder.  What would you like to do?";

function getBadAnswer(item) { return "I'm sorry. " + item + " is not something I know very much about in this skill. " + HELP_MESSAGE; }

function getCurrentScore(score, counter) { return "Your current score is " + score + " out of " + counter + ". "; }

function getFinalScore(score, counter) { return "Your final score is " + score + " out of " + counter + ". "; }

const USE_CARDS_FLAG = false;

function getCardTitle(item) { return item.RiverName;}

function getSmallImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/720x400/" + item.Abbreviation + "._TTH_.png"; }

function getLargeImage(item) { return "https://m.media-amazon.com/images/G/01/mobile-apps/dex/alexa/alexa-skills-kit/tutorials/quiz-game/state_flag/1200x800/" + item.Abbreviation + "._TTH_.png"; }

const data = [
{RankBasedOnLengthInMiles: 1, RiverName: "Indus",  OriginatesFrom: "In Tibet Kalish Range 5080 mts", EndsIn: "Arabian sea", LengthInMiles: 2900, BenefittedCountriesOrStates: "India and Pakistan"},
{RankBasedOnLengthInMiles: 2, RiverName: "Brahmaputra",  OriginatesFrom: "Lake Manasarovar", EndsIn: "Bay of Bengal River", LengthInMiles: 2900, BenefittedCountriesOrStates: "North Eastern state"},
{RankBasedOnLengthInMiles: 3, RiverName: "Ganga",  OriginatesFrom: "Gangothri", EndsIn: "Bay of Bengal", LengthInMiles: 2510, BenefittedCountriesOrStates: "Uttar Pradesh, Uttarakhand, Bihar, West Bengal"},
{RankBasedOnLengthInMiles: 4, RiverName: "Godavari",  OriginatesFrom: "Nasik Hills", EndsIn: "Bay of Bengal", LengthInMiles: 1450, BenefittedCountriesOrStates: "South-easterly part of Andhra Pradesh"},
{RankBasedOnLengthInMiles: 5, RiverName: "Narmada",  OriginatesFrom: "Amarkantak hill in Madhya Pradesh", EndsIn: "Arabian sea", LengthInMiles: 1290, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 6, RiverName: "Krishna",  OriginatesFrom: "Near Mahabaleshwar in Maharashtra", EndsIn: "Bay of Bengal", LengthInMiles: 1290, BenefittedCountriesOrStates: "Maharastra and Andhrapradesh"},
{RankBasedOnLengthInMiles: 7, RiverName: "Yamuna",  OriginatesFrom: "Garhwall in Yamunotri", EndsIn: "Bay of Bengal", LengthInMiles: 1211, BenefittedCountriesOrStates: "Delhi, Haryana and UP"},
{RankBasedOnLengthInMiles: 8, RiverName: "Mahanadi",  OriginatesFrom: "Amarkantak Plateau", EndsIn: "Bay of Bengal", LengthInMiles: 890, BenefittedCountriesOrStates: "Jharkhand, Chhattisgarh, Orissa"},
{RankBasedOnLengthInMiles: 9, RiverName: "Kaveri",  OriginatesFrom: "Hills of Coorg, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 760, BenefittedCountriesOrStates: "Karnataka and Tamilnadu"},
{RankBasedOnLengthInMiles: 10, RiverName: "Tapi",  OriginatesFrom: "Bettul", EndsIn: "Arabian sea", LengthInMiles: 724, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 11, RiverName: "Sone",  OriginatesFrom: "Amarkantak in Madhya Pradesh", EndsIn: "Ganges River", LengthInMiles: 784, BenefittedCountriesOrStates: "Madhya Pradesh, Uttar Pradesh,�Jharkhand, Bihar"},
{RankBasedOnLengthInMiles: 12, RiverName: "Kaveri",  OriginatesFrom: "Hills of Coorg, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 760, BenefittedCountriesOrStates: "Karnataka and Tamilnadu"},
{RankBasedOnLengthInMiles: 13, RiverName: "Tapi",  OriginatesFrom: "Bettul", EndsIn: "Arabian sea", LengthInMiles: 724, BenefittedCountriesOrStates: "Madhya Pradesh and Maharashtra"},
{RankBasedOnLengthInMiles: 14, RiverName: "Manjira",  OriginatesFrom: "Balaghat range of hills near Ahmednagar", EndsIn: "Godavari River", LengthInMiles: 724, BenefittedCountriesOrStates: "Maharashtra, Karnataka, Telangana"},
{RankBasedOnLengthInMiles: 15, RiverName: "Pennar",  OriginatesFrom: "Nandi Hills, Karnataka", EndsIn: "Bay of Bengal", LengthInMiles: 597, BenefittedCountriesOrStates: "Andhra Pradesh, Karnataka"},
{RankBasedOnLengthInMiles: 16, RiverName: "Damodar",  OriginatesFrom: "Chandwa, Latehar, Chota Nagpur Plateau,�Jharkhand", EndsIn: "Hooghly River,�Howrah district,�West Bengal", LengthInMiles: 592, BenefittedCountriesOrStates: "Bokaro,�Asansol,�Raniganj,�Durgapur,�Bardhaman"},
{RankBasedOnLengthInMiles: 17, RiverName: "Mahi",  OriginatesFrom: "Madhya pradesh, Vindhyas", EndsIn: "Arabian sea", LengthInMiles: 583, BenefittedCountriesOrStates: "Madhya Pradesh,Rajasthan,Gujarat"},
{RankBasedOnLengthInMiles: 18, RiverName: "Tungabhadra ",  OriginatesFrom: "Koodli, Bhadravathi, Karnataka", EndsIn: "Krishna River", LengthInMiles: 531, BenefittedCountriesOrStates: "Karnataka, Telangana, Andhra Pradesh"},
{RankBasedOnLengthInMiles: 19, RiverName: "Tungabhadra ",  OriginatesFrom: "Koodli, Bhadravathi, Karnataka", EndsIn: "Krishna River", LengthInMiles: 531, BenefittedCountriesOrStates: "Karnataka, Telangana, Andhra Pradesh"},
            ];
					
const vaccineSchedules = {       
      "two" :
      [
          "DTaP-HB-IPV-Hib",
          "Pneumococcal Conjugate",
          "Rotavirus",
          "Meningococcal C Conjugate"
      ]
};
						
const counter = 0;

const states = {
    START: "_START",
    QUIZ: "_QUIZ"
};

const handlers = {
     "LaunchRequest": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
     },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.emitWithState("Quiz");
    },
    "AnswerIntent": function() {
        this.handler.state = states.START;
        this.emitWithState("AnswerIntent");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.handler.state = states.START;
        this.emitWithState("Start");
    }
};

const startHandlers = Alexa.CreateStateHandler(states.START,{
    "Start": function() {
        this.response.speak(WELCOME_MESSAGE).listen(HELP_MESSAGE);
		this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
        this.emit(":responseReady");
    },
    "AnswerIntent": function() {
        //let item = getItem(this.event.request.intent.slots);
		let item = getYesNo(this.event.request.intent.slots);
		
		/*
        this.attributes["ageOfKid"] = 0;
        if (item && item[Object.getOwnPropertyNames(data[0])[0]] != undefined)
        {
          console.log("\nMEMO's TEST\n");
            if (USE_CARDS_FLAG)
            {
                let imageObj = {smallImageUrl: getSmallImage(item), largeImageUrl: getLargeImage(item)};

                this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
                this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);            }
            else
            {
                this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
            }
        }
        else
        {
            this.response.speak(getBadAnswer(item)).listen(getBadAnswer(item));

        }
		*/
        this.response.speak(REMINDER_SET_MESSAGE).listen(REPROMPT_SPEECH);
        this.emit(":responseReady");
    },
    "CreateScheduleIntent": function() {
        //this.handler.state = states.QUIZ;
        //this.emitWithState("Quiz");
		// One item with two properties: question_id and title.				
        
       if (this.attributes["nameOfKid"] == undefined)
        {   		    	
            this.attributes["nameOfKid"] = getKidName(this.event.request.intent.slots);
        }		
		this.attributes["defaultSchedule"] = "Yes";
		
		   var speechOutput = getSpeechDescription1() + this.attributes["nameOfKid"];
           const randomFact = "123456789";
		   
          if(false) {
          console.log("has display:"+ supportsDisplay.call(this));
          console.log("is simulator:"+isSimulator.call(this));
          var content = {
             "hasDisplaySpeechOutput" : speechOutput,
             "hasDisplayRepromptText" : randomFact,
             "simpleCardTitle" : "123",
             "simpleCardContent" : randomFact,
             "bodyTemplateTitle" : "456",
             "bodyTemplateContent" : randomFact,
             "templateToken" : "factBodyTemplate",
             "askOrTell" : ":tell",
             "sessionAttributes": {}
          };
          renderTemplate.call(this, content);
        } else {
        // Just use a card if the device doesn't support a card.
          //this.response.cardRenderer(this.t('SKILL_NAME'), randomFact);
          //this.response.speak(speechOutput);
          
		  this.attributes["creationDate"] = new Date();
		  this.response.speak(getSpeechDescription1() + this.attributes["nameOfKid"]).listen(REPROMPT_SPEECH);
		  this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
		  this.emit(':responseReady');
		  }          

		  
		  //if (USE_CARDS_FLAG)
		 // {
                //let imageObj = {smallImageUrl: getSmallImage(item), largeImageUrl: getLargeImage(item)};

               // this.response.speak(getSpeechDescription(item)).listen(REPROMPT_SPEECH);
                //this.response.cardRenderer(getCardTitle(item), getTextDescription(item), imageObj);    
				//}
            //else
            //{
                //this.response.speak(getSpeechDescription1() + this.attributes["nameOfKid"]).listen(REPROMPT_SPEECH);
				//this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
            //}
		//this.emit(":responseReady");
		
    },	
    "ShowScheduleIntent": function() {
        //this.handler.state = states.QUIZ;
		//let sentence = this.attributes["nameOfKid"];	

        let response = "";
		//const ctr = 0;
		
		for (var i = 0; i < vaccineSchedules.two.length; i++) {
              var item = vaccineSchedules.two[i];
			  
               response += "<break time='1s'/>" + (i+1) + " <break time='1s'/>" + item + " ," ;
          }
		  response += "  and its recommended to take within " + " two " + " months. Do you want to set reminder ? " ; 
		
        this.response.speak(SHOW_SCHEDULE_MESSAGE + response).listen(REPROMPT_SPEECH);
		this.response.cardRenderer(this.t('TITLE'), this.t('WELCOME'), welcomeCardImg);
		this.emit(':responseReady');
    },
    "QuizIntent": function() {
        this.handler.state = states.QUIZ;
        this.emitWithState("Quiz");
    },
    "AMAZON.PauseIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.emitWithState("Start");
    }
});


const quizHandlers = Alexa.CreateStateHandler(states.QUIZ,{
    "Quiz": function() {
        this.attributes["response"] = "";
		this.attributes["kidNickName"] = "";
        this.attributes["counter"] = 0;
        this.attributes["quizscore"] = 0;
        this.emitWithState("AskQuestion");
    },
    "AskQuestion": function() {
        if (this.attributes["kidNickName"] == "")
        {   
            this.attributes["response"] = START_QUIZ_MESSAGE + " ";
        }

        let random = getRandom(0, data.length-1);
        let item = data[random];

        let propertyArray = Object.getOwnPropertyNames(item);
        let property = propertyArray[getRandom(1, propertyArray.length-1)];

        this.attributes["quizitem"] = item;
        this.attributes["quizproperty"] = property;
        this.attributes["counter"]++;

        let question = getQuestion(this.attributes["counter"], property, item);
        //let speech = this.attributes["response"] + question;
		let speech = this.attributes["response"];

        this.emit(":ask", speech, question);
    },
    "AnswerIntent": function() {
        let response = "";
        let speechOutput = "";
        let item = this.attributes["quizitem"];
        let property = this.attributes["quizproperty"]

        let correct = compareSlots(this.event.request.intent.slots, item[property]);

        if (correct)
        {
            response = getSpeechCon(true);
            this.attributes["quizscore"]++;
        }
        else
        {
            response = getSpeechCon(false);
        }

        response += getAnswer(property, item);

        if (this.attributes["counter"] < 10)
        {
            response += getCurrentScore(this.attributes["quizscore"], this.attributes["counter"]);
            this.attributes["response"] = response;
            this.emitWithState("AskQuestion");
        }
        else
        {
            response += getFinalScore(this.attributes["quizscore"], this.attributes["counter"]);
            speechOutput = response + " " + EXIT_SKILL_MESSAGE;

            this.response.speak(speechOutput);
            this.emit(":responseReady");
        }
    },
    "AMAZON.RepeatIntent": function() {
        let question = getQuestion(this.attributes["counter"], this.attributes["quizproperty"], this.attributes["quizitem"]);
        this.response.speak(question).listen(question);
        this.emit(":responseReady");
    },
    "AMAZON.StartOverIntent": function() {
        this.emitWithState("Quiz");
    },
    "AMAZON.StopIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.PauseIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak(EXIT_SKILL_MESSAGE);
        this.emit(":responseReady");
    },
    "AMAZON.HelpIntent": function() {
        this.response.speak(HELP_MESSAGE).listen(HELP_MESSAGE);
        this.emit(":responseReady");
    },
    "Unhandled": function() {
        this.emitWithState("AnswerIntent");
    }
});

function getKidName(slots)
{ console.log("#########2 ");
    for (let slot in slots)
    {
	console.log("#########3 ");
        if (slots[slot].value != undefined)
        {	console.log("#########4 " + slots[slot].name.toString().toLowerCase());		
            if (slots[slot].name.toString().toLowerCase() == "nameofkid")
            {   
			console.log("#########5 ");			
                let nameOfKid = slots[slot].value.toString();
				return nameOfKid;
            }
        }
    }
    return "";
}

function compareSlots(slots, value)
{
    for (let slot in slots)
    {
        if (slots[slot].value != undefined)
        {
			this.attributes["kidNickName"] = slots[slot].value.toString();
            if (slots[slot].value.toString().toLowerCase() == value.toString().toLowerCase())
            {
                return true;
            }
        }
    }
    return false;
}

function getRandom(min, max)
{
    return Math.floor(Math.random() * (max-min+1)+min);
}

function getRandomSymbolSpeech(symbol)
{
    return "<say-as interpret-as='spell-out'>" + symbol + "</say-as>";
}

function getYesNo(slots)
{
    let propertyArray = Object.getOwnPropertyNames(data[0]);
    let value;

    for (let slot in slots)
    {
        if (slots[slot].value !== undefined)
        {
            value = slots[slot].value;
            for (let property in propertyArray)
            {
                let item = data.filter(x => x[propertyArray[property]].toString().toLowerCase() === slots[slot].value.toString().toLowerCase());
                if (item.length > 0)
                {
                    return item[0];
                }
            }
        }
    }
    return value;
}

function getItem(slots)
{
    let propertyArray = Object.getOwnPropertyNames(data[0]);
    let value;

    for (let slot in slots)
    {
        if (slots[slot].value !== undefined)
        {
            value = slots[slot].value;
            for (let property in propertyArray)
            {
                let item = data.filter(x => x[propertyArray[property]].toString().toLowerCase() === slots[slot].value.toString().toLowerCase());
                if (item.length > 0)
                {
                    return item[0];
                }
            }
        }
    }
    return value;
}

function getSpeechCon(type)
{
    let speechCon = "";
    if (type) return "<say-as interpret-as='interjection'>" + speechConsCorrect[getRandom(0, speechConsCorrect.length-1)] + "! </say-as><break strength='strong'/>";
    else return "<say-as interpret-as='interjection'>" + speechConsWrong[getRandom(0, speechConsWrong.length-1)] + " </say-as><break strength='strong'/>";
}

function formatCasing(key)
{
    key = key.split(/(?=[A-Z])/).join(" ");
    return key;
}

function getTextDescription(item)
{
    let text = "";

    for (let key in item)
    {
        text += formatCasing(key) + ": " + item[key] + "\n";
    }
    return text;
}

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
	
	alexa.dynamoDBTableName = 'RecipeSkillTable'; // creates new table for session.attributes
      if (alexa.dynamoDBTableName == 'RecipeSkillTable' ){
        persistenceEnabled=true;
      } else {
        persistenceEnabled=false;
      }
	
    alexa.registerHandlers(handlers, startHandlers, quizHandlers);
    alexa.execute();
};

//==============================================================================
//=========================== Helper Functions  ================================
//==============================================================================

function supportsDisplay() {
  var hasDisplay =
    this.event.context &&
    this.event.context.System &&
    this.event.context.System.device &&
    this.event.context.System.device.supportedInterfaces &&
    this.event.context.System.device.supportedInterfaces.Display

  return hasDisplay;
}

function isSimulator() {
  var isSimulator = !this.event.context; //simulator doesn't send context
  return isSimulator;
}

function renderTemplate (content) {

  //create a template for each screen you want to display.
  //This example has one that I called "factBodyTemplate".
  //define your templates using one of several built in Display Templates
  //https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/display-interface-reference#display-template-reference


   switch(content.templateToken) {
       case "factBodyTemplate":
          // for reference, here's an example of the content object you'd
          // pass in for this template.
          //  var content = {
          //     "hasDisplaySpeechOutput" : "display "+speechOutput,
          //     "hasDisplayRepromptText" : randomFact,
          //     "simpleCardTitle" : this.t('SKILL_NAME'),
          //     "simpleCardContent" : randomFact,
          //     "bodyTemplateTitle" : this.t('GET_FACT_MESSAGE'),
          //     "bodyTemplateContent" : randomFact,
          //     "templateToken" : "factBodyTemplate",
          //     "sessionAttributes": {}
          //  };

           var response = {
             "version": "1.0",
             "response": {
               "directives": [
                 {
                   "type": "Display.RenderTemplate",
                   "template": {
                     "type": "BodyTemplate1",
                     "title": content.bodyTemplateTitle,
                     "token": content.templateToken,
                     "textContent": {
                       "primaryText": {
                         "type": "RichText",
                         "text": "<font size = '5'>"+content.bodyTemplateContent+"</font>"
                       }
                     },
                     "backButton": "HIDDEN"
                   }
                 }
               ],
               "outputSpeech": {
                 "type": "SSML",
                 "ssml": "<speak>"+content.hasDisplaySpeechOutput+"</speak>"
               },
               "reprompt": {
                 "outputSpeech": {
                   "type": "SSML",
                   "ssml": "<speak>"+content.hasDisplayRepromptText+"</speak>"
                 }
               },
               "shouldEndSession": content.askOrTell==":tell",
               "card": {
                 "type": "Simple",
                 "title": content.simpleCardTitle,
                 "content": content.simpleCardContent
               }
             },
             "sessionAttributes": content.sessionAttributes
           }
           this.context.succeed(response);
           break;

       default:
          this.response.speak("Thanks for chatting, goodbye");
          this.emit(':responseReady');
   }

}
