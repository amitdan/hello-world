MarkAsDoneIntent
C - Alexa, mark as done 
A - Hang on, looks like vaccine xyx sceduled this week/month, Should I mark it as done ?
C - yes please   
A-  What else would you like to do ?


SetReminderIntent
C- Could you please set reminder ?
A - Hang on, What is your mobile number ?
C - 1234567890
A - Please confirm
C-  yes
A - How many days prior you want to recive reminder ?





getActiveVaccines(ageFromString)