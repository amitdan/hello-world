import java.io.File;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.watson.developer_cloud.document_conversion.v1.DocumentConversion;
import com.ibm.watson.developer_cloud.document_conversion.v1.model.Answers;
import com.ibm.watson.developer_cloud.service.exception.BadRequestException;
import com.ibm.watson.developer_cloud.service.exception.InternalServerErrorException;
import com.ibm.watson.developer_cloud.service.exception.UnauthorizedException;

public class PdfToText {
	
	public static void main(String[] args) {
		
	
try
{
	DocumentConversion service = new DocumentConversion("2015-12-15");
	service.setUsernameAndPassword("akanshabbv09@gmail.com", "Akanksha@09");

	File doc = new File("C:/Users/akankshat/Documents/my.doc");

	// Use a custom configuration.
	String configAsString = "{"+ "\"word\":{" + "\"heading\":{"+ "\"fonts\":["+ "{\"level\":1,\"min_size\":24},"+ "{\"level\":2,\"min_size\":16,\"max_size\":24}"+ "]}}}";

	JsonParser jsonParser = new JsonParser();
	JsonObject customConfig = jsonParser.parse(configAsString).getAsJsonObject();

	Answers response = service.convertDocumentToAnswer(doc, null, customConfig).execute();

	System.out.println(response);
	
   }catch (IllegalArgumentException e1) {
	  System.out.println(e1);
	} catch (BadRequestException e2) {
	  System.out.println(e2);
	} catch (UnauthorizedException e3) {
	 System.out.println(e3);
	} catch (InternalServerErrorException e4) {
		 System.out.println(e4);
	}
}
}

